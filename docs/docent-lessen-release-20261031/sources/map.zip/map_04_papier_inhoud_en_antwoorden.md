# Klink+docent — MAP — Negen afdrukproducten en correctiemodel

Dit document is de bewerkbare semantische bron voor de negen A4-PDF-proeven. Cursistenpagina’s hebben uitsluitend een neutrale titel zonder Alfa A/B/C of Steun/Basis/Plus. De drie observatiebladen blijven privé.

## Woord: werkblad

- Titel: DE MAP.

- Toon lettervolgorde m, a, p en drie lege vakken.

- Afzonderlijk leesobject: map (zonder foto of audio tijdens echte eigen leesbeurt).

- Optioneel woord overschrijven: twee brede schrijflijnen. Geen verplichte lange leestekst.

- Antwoorden: m - a - p; map.

## Woord: kaartjes

- Drie grootformaat knipkaarten: m, a, p. Los woordkaartje: map.

## Woord: privé-observatie

- Betekenis, nazeggen, klanken, bouwen, eigen lezen, mondelinge toepassing. Bij ieder: zelfstandig / met hulp / nog niet waargenomen. Geen score.

## Zin: werkblad

- Titel DE MAP met doelzin: De map ligt op de tafel.

- Zes lege kaartvakken om de zin op te bouwen, één lijn voor onderstreping van de plaatswoorden en ruimte om te tekenen/schrijven.

- Antwoord plaatsgroep: op de tafel.

## Zin: kaartjes

- Exact zes losse kaartjes: De | map | ligt | op | de | tafel.

## Zin: privé-observatie

- Voorwerpsbegrip, plaatsrelatie, zes kaartjes, zinslezen zonder direct model, transfer en type hulp.

## Tekst: werkblad

- Titel DE MAP; drie zinnen:

  De map ligt op de tafel.

  Ik zoek een brief.

  Ik doe de brief in de map.

- Drie betekenisvragen met antwoordruimte:

  Waar ligt de map? (Antwoord: Op de tafel.)

  Wat zoekt iemand? (Antwoord: Een brief.)

  Waar gaat de brief heen? (Antwoord: In de map.)

- Zeven lege kaartvakken en twee lijnen voor een eigen korte uiting.

## Tekst: kaartjes

- Exact zeven kaartjes in te knippen volgorde: Ik | doe | de | brief | in | de | map.

## Tekst: privé-observatie

- Begrip van drie zinnen, de drie tekstvragen, kaartvolgorde, eigen tekstlezen, handeling en vrije uiting. Iedere observatie met hulpstatus.

## Druk-/uitvoeringscontrole

- A4 één pagina per uitvoer, zwart-wit en marges; PDF wordt lokaal gerenderd en de tekst en paginering gecontroleerd.

- De cursistenbladen bevatten geen niveauaanduiding; docentobservatie niet projecteren.

- Bestaande Klink-beeldbronnen en officiële logo-assets zijn niet in deze losse PDF-proeven ingebed, omdat de menselijke media-/rechtenreview openstaat. Toon beeld in de bordles of neem echte voorwerpen mee.

- Fysieke print en menselijke didactische beoordeling staan nog open.
