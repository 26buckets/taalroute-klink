# Klink+docent — MAP — contentkaart, softwarekaart en toets-/reviewregister

Status contentbron v1.0, geen code- of deploymentbewijs. 28 oktober 2026.

**Productlocatie:** Klink > Docentomgeving > Klink+docent > woordkeuze MAP (toekomstige lesselectie; route in bestaande app nog te bouwen/verifiëren).

**Lexiconbron:** `klink-woord-map`. **Geregistreerde afbeelding:** `/package-media/cp001/aa-cp001-map-context-02.webp`. **Helewoordaudio:** `/package-audio/taalroute/klink-woord-map.mp3`. Review OPEN.

**Doelwoord:** `map`. **Fonemen:** m, a, p (korte a /ɑ/). **Artikel:** de.

**Doel:** betekenis, fonemische koppeling, woordbouw, eerste onafhankelijk leesbewijs (formatief, niet gescoord), zinsrelatie, samenhangend tekstbegrip en persoonlijke transfer.

**Rollen:** docent regisseert het geprojecteerde bord; cursisten reageren zonder eigen login; docentmateriaal en observatie zijn strikt privé.

**Schermtypes:** woordkeuze, gedeelde bordles, privé-docentinformatie, lesgerelateerd printoverzicht, vijf tijdelijke hulpoverlays, verwijzing naar bestaande cursistenoefening.

**Interacties:** toon/verberg foto en schrift; klik/drag/touch woord-/letterkaartjes; afzonderlijke foneem-play; answer reveal op docentactie; eigen tekst niet bewaren; vorige/volgende binnen en over 3 stappen; hulpmiddel terug zonder statusschade.

**Prompttypen:** mondelinge vraag, hoor-en-wijs, klankidentificatie, lettertegel, zinskaartvolgorde, tekstbegripsvraag, handelingenscène, zelfstandig lezen, vrije korte reactie.

**Dataopslag:** content als versioned JSON via bestaande lezer; UI-sessie zonder leerlingnamen, scores of observaties; papieren formatieve docentnotitie buiten projectie. De gewijzigde werkelijke componentlogica moet nog worden geïntegreerd in Work.

**Werkbrug:** Papieren ordenen voor een afspraak of bij het werk: je zoekt een brief en doet hem in een map.

**Rapportagewaarde:** enkel ontwikkelinformatie in privé-docentobservatie; geen formeel dossier zonder apart besluit.

**Status:** ontwerpcontent gereed voor technische mapping; printproef uit ReportLab; menselijke mediamarkering OPEN; publicatie NIET toegestaan zonder nieuw besluit.

**Toetsgrens:** geen certificerende of summatieve Alfa-uitspraak; geen automatisch oordeel over zelfstandig lezen of schrijven.

## 24 inhoudsobjecten, elk met scherm, rol, prompt, feedback en observatie

- `map-01-01` | Stap Woord, fase Kijken | oral+action | tijdindicatie 2 min | bouwdoel: Aanwijzen of betekenis benoemen; woord hoeft nog niet gelezen te worden.

- `map-01-02` | Stap Woord, fase Luisteren | oral+action | tijdindicatie 2 min | bouwdoel: Het woord horen en nazeggen; daarna eventueel zelfstandig benoemen.

- `map-01-03` | Stap Woord, fase Klanken | mixed | tijdindicatie 3 min | bouwdoel: De deelnemer wijst m-a-p in volgorde aan en voegt fonemen mondeling samen tot map.

- `map-01-04` | Stap Woord, fase Bouwen | mixed | tijdindicatie 4 min | bouwdoel: m-a-p in drie vakken; de volgorde is m, a, p.

- `map-01-05` | Stap Woord, fase Lezen | reading | tijdindicatie 4 min | bouwdoel: map zelfstandig of met expliciete klankhulp uit het woordbeeld afleiden.

- `map-01-06` | Stap Woord, fase Gebruiken | oral+action | tijdindicatie 4 min | bouwdoel: Handeling of eenvoudig mondeling antwoord in vertrouwde volwassen situatie.

- `map-01-07` | Stap Woord, fase Op papier | mixed | tijdindicatie 5 min | bouwdoel: Schrijft/legt m-a-p; leest map met passende hulp; schrijft alleen indien motorisch haalbaar.

- `map-01-08` | Stap Woord, fase Nog een keer | mixed | tijdindicatie 3 min | bouwdoel: Vernieuwde lees- en betekenisbeurt met eventueel minder hulp.

- `map-02-01` | Stap Zin, fase Kijken | oral+action | tijdindicatie 2 min | bouwdoel: Aanwijzen of de plaats mondeling benoemen.

- `map-02-02` | Stap Zin, fase Luisteren | oral+action | tijdindicatie 2 min | bouwdoel: Betekenis globaal uitleggen of handeling uitvoeren.

- `map-02-03` | Stap Zin, fase Begrijpen | mixed | tijdindicatie 3 min | bouwdoel: De map. / Op de tafel.

- `map-02-04` | Stap Zin, fase Bouwen | mixed | tijdindicatie 4 min | bouwdoel: Exact: De map ligt op de tafel.

- `map-02-05` | Stap Zin, fase Lezen | reading | tijdindicatie 4 min | bouwdoel: Eigen leesbeurt; betekenis van op de tafel benoemen.

- `map-02-06` | Stap Zin, fase Gebruiken | oral+action | tijdindicatie 4 min | bouwdoel: Mondeling een nieuwe plaats beschrijven; geen niet-voorbereide zin verplicht laten schrijven.

- `map-02-07` | Stap Zin, fase Op papier | mixed | tijdindicatie 5 min | bouwdoel: Correcte kaarten: De / map / ligt / op / de / tafel.. Plaatsgroep: op de tafel.

- `map-02-08` | Stap Zin, fase Nog een keer | mixed | tijdindicatie 3 min | bouwdoel: Passende nieuwe leesbeurt en handeling.

- `map-03-01` | Stap Tekst, fase Kijken | oral+action | tijdindicatie 2 min | bouwdoel: Handeling herkennen of mondeling beschrijven zonder drie geschreven zinnen.

- `map-03-02` | Stap Tekst, fase Luisteren | oral+action | tijdindicatie 2 min | bouwdoel: Globale betekenis of passende handeling.

- `map-03-03` | Stap Tekst, fase Begrijpen | mixed | tijdindicatie 3 min | bouwdoel: 1. Op de tafel. 2. Een brief. 3. In de map.

- `map-03-04` | Stap Tekst, fase Bouwen | mixed | tijdindicatie 4 min | bouwdoel: Doelzin: Ik doe de brief in de map.

- `map-03-05` | Stap Tekst, fase Lezen | reading | tijdindicatie 4 min | bouwdoel: Eigen leesbeurt en samenhang van handelingen aantonen.

- `map-03-06` | Stap Tekst, fase Gebruiken | oral+action | tijdindicatie 4 min | bouwdoel: Passende zin koppelen aan handeling, daarna mondeling variëren.

- `map-03-07` | Stap Tekst, fase Zelf maken | mixed | tijdindicatie 5 min | bouwdoel: Voorbeeld (niet verplicht): Ik doe de brief in de map. Andere betekenisvolle antwoorden zijn goed.

- `map-03-08` | Stap Tekst, fase Nog een keer | mixed | tijdindicatie 3 min | bouwdoel: Navertelling of nieuwe leesbeurt met minder hulp.

## Technisch datacontract (beoordelen tegen actuele code)

```json
{
  "lessonId": "klink-plus-map-001",
  "wordRef": "klink-woord-map",
  "segmentation": ["m", "a", "p"],
  "media": {"image": "/package-media/cp001/aa-cp001-map-context-02.webp", "wholeWord": "/package-audio/taalroute/klink-woord-map.mp3", "review": "open"},
  "phonemeAudio": {"m": null, "a": null, "p": null},
  "steps": ["Woord", "Zin", "Tekst"],
  "cardsSentence": ["De", "map", "ligt", "op", "de", "tafel."],
  "cardsText": ["Ik", "doe", "de", "brief", "in", "de", "map."],
  "selfStudyLessonId": null,
  "publication": "not-published"
}
```

Het JSON-bestand in deze map bevat de feitelijke volledige 24-faseninhoud; bovenstaande is alleen een adapter-schets. De huidige mat-component heeft hardcoded `matWord`, `matUnits` en `matExercises`: verander dit in een lesgebaseerde resolver, niet in een kopie van alle componenten. Preserve mat en bestaande Klink-sessies; migreer/zorg bij leswissel dat status per lessonId is geïsoleerd.

## Kwaliteits- en acceptatiepoorten voor toekomstige appbouw

- T01: bestaand woordRef, echte foto-/audio-ref en correct artikel tonen; geen nieuw lemma of fake-ID.
- T02: hoofdafbeelding bij eerste kijken zonder geschreven woord; docent kan later onthullen.
- T03: alle drie losse fonemen met eigen bron; ontbrekende bron = klein rood kruisje, geen TTS of woordaudio-fallback.
- T04: woordbouw heeft 3 letters en correcte volgorde; docent kan fout herstellen zonder schaamte.
- T05: zelfstandig lezen zonder beeld/autoplay; modelbeurt apart te observeren.
- T06: zin heeft exacte 6 woordkaartjes en correcte, eigen betekenisvraag.
- T07: tekst heeft exact 3 samenhangende zinnen en 7 focus-woordkaartjes; drie vragen met onderbouwde antwoorden.
- T08: tekst vrije formulering niet automatisch scoren; geen persoons- of tekstopslag in browser.
- T09: alle 3×8 fasen met docenthandeling, hulp, feedback en observatie uit data laden.
- T10: vijf tools bereikbaar in elke stap; terugkeer bewaart onderbrekingsstatus.
- T11: één geprojecteerd scherm, geen niveau-/docentlabels of notities in DOM, UI, fouten, printdialoog.
- T12: geen verplichte voorbereiding; les start in Woord; vervolgt Zin → Tekst; geen herintroductie van Bericht.
- T13: negen afzonderlijke A4-PDFs met neutrale cursistkop, geen afsnijding of alfalabels; fysieke printerproef nog open.
- T14: gehele woord-zelfstudie alleen via echt gevonden bestaande exerciseId; geen claim dat zinnen/tekst al als oefening bestaan.
- T15: switching mat/tas/map reset les-specifieke kaartvolgordes, behoudt privacy en breekt bestaande cursistenlessen niet.
- T16: bouw, types, lint, keyboard, touch, browser en regressie daadwerkelijk uitvoeren; bewijs per testcase en commit opslaan.
- T17: expliciete menselijke beeld-/audio-/rechtenreview, onafhankelijke didactische review en fysieke klas-/bordproef nog niet voltooid.
- T18: branch/PR, geen livepublicatie zonder apart akkoord; opslagsucces op Drive pas na teruglezing melden.

## Bronstatus / open controles

- Het complete actuele `data/klink-curriculum.json` kon via de beschikbare GitHub-readaction niet volledig worden uitgelezen; exacte eerste leesstap, groepsroute en alle `guidedExerciseIds` voor dit woord moeten in Work opnieuw tegen de actuele JSON worden vastgesteld. Behandel de semantische bronref en mediapaden als geverifieerd, maar curriculumroute en oefening-IDs als nog OPEN.

- Bronafbeelding moet als foto daadwerkelijk worden bekeken; semantische objectherkenning en beeldrechten zijn nog niet menselijk afgetekend.

- Deze tekst is een CONTENTDOOS, geen werkende lesmotor of goedgekeurde geluidsopname.

## Overdracht in Work

Lees deze contentkaart, het volledige lesdossier en de 9 PDFproeven voor `map` in deze Drive-map. Bouw dan pas de generieke lessonId-resolver en bordles binnen de bestaande Klink+docent-conceptbranch of een reviewbare opvolger. Bewaar actueel mat-gedrag en de realistische leenvoorwaarden. Test en lever PR/bewijs afzonderlijk; niets publiceren zonder besluit.
