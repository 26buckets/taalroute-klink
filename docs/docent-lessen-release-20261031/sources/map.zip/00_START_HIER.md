# Klink+docent — MAP — START HIER

Inhoudelijke productie v1.0, 28 oktober 2026. Volgorde: eerst Tas, daarna Map.

Alleen lesCONTENT en tekst-/printproducten. **Niet geïmplementeerd in de Klink-app, niet gemerged of live gepubliceerd.** De huidige PR voor MAT is de technische referentie en bevat de laatst vastgestelde drie stappen **Woord, Zin, Tekst**, elk acht fasen; niet de verouderde berichttaak.

- Canoniek doelwoord: `klink-woord-map`; foto `/package-media/cp001/aa-cp001-map-context-02.webp`; helewoordaudio `/package-audio/taalroute/klink-woord-map.mp3`; menselijke review OPEN.
- Nieuwe zin: **De map ligt op de tafel.**
- Driezinnentekst: **De map ligt op de tafel. Ik zoek een brief. Ik doe de brief in de map.**
- 24 faseobjecten in `map_lessen_content_v1.json`; ook leesbaar in `map_01_volledig_lesdossier.md`.
- Software- en contentkaart, P0/P1-acceptatie en status in `map_02_softwarekaart_acceptatie.md`.
- Exact negen proefdrukken: woord/zin/tekst × werkblad/kaartjes/docentobservatie. Op leerlingpagina's geen Alfa A/B/C of Steun/Basis/Plus. Docentobservatie NIET projecteren.
- Voor de opdracht op papier gebruikt de docent een echt voorwerp of Klink-afbeelding op het bord; er worden geen onbeoordeelde beelden ingebed in het PDF. Dit is functioneel proefmateriaal, géén volledige persklare drukset.

**Open:** echte lesmotorintegratie, controle van de exacte curriculumplaatsing/zelfstudie-IDs, individuele foneemaudio, menselijke beeld-/audio-/rechtenreview, onafhankelijke didactische review, fysieke afdruk-/bordproef en klasvalidatie.

Dit materiaal kan veilig in de bestaande Drive-map worden opgeslagen en later door een afzonderlijke Work-chat worden geïmplementeerd zonder Mat te overschrijven.
