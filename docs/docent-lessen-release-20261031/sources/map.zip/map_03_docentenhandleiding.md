# Klink+docent — MAP — Docentenhandleiding en antwoordmodel

Versie 1.0, 28 oktober 2026. Alleen docent; niet projecteren.

## Lesorganisatie en voorbereiding

- Neem een echte documentenmap en een neutrale brief op papier mee. Gebruik de geregistreerde foto op het digibord alleen na betekenis- en rechtencontrole.

- De les start direct met **Les openen**; er is geen verplichte voorcheck of routekeuze. Hier staan alleen adviezen voor didactische voorbereiding.

- Alle deelnemers starten met het woord. De docent kan binnen één les later naar Zin en Tekst bewegen. Geef onbekende woorden voldoende mondelinge en schriftelijke voorbereiding voor je onafhankelijk lezen vraagt.

- Voordoen, Samen doen, Zelfstandig zijn werkvormen en geen publiek zichtbare route- of cursistlabels.

- Klankbord, woordbord, leesplank, spiegelbord en leeg schrijfbord zijn tijdelijke, geprojecteerde tools. Verberg persoonlijke observaties.

## Stap 1 — Woord

Doelwoord: **map**. Artikel: **de map**. Uitspraak: **/mɑp/**. Segmenteer in **m + a + p**; de a is kort /ɑ/.

Correcte tegels: **m – a – p**. Alternatieve tegelvolgorde aan het begin: **p – a – m**.

Docent zegt bij afbeelding: ‘Wat zie je? Wijs het aan.’ Na mondelinge kennismaking pas schrift tonen.

Luister- en nazegopdracht: speel het hele woord af als bron technisch werkt; voor fonemen bestaan apart toetsbare knoppen. Ontbreekt foneemopname, dan verschijnt een klein rood kruisje en spreekt de docent zelf voor.

Laat voor het eigen leesmoment alle afbeelding en automatisch geluid weg. Observeer of de cursist het geschreven woord zelfstandig, met klankhulp of slechts na een model leest.

**Werkblad Woord:** correcte eerste/tweede/derde letter zoals hierboven. Overtekenen of schrijven is optioneel; een deelnemer kan op papierkaartjes bouwen zonder schrijfdwang.

## Stap 2 — Zin

Doelzin: **De map ligt op de tafel.**

Zes unieke fysieke kaartjes (inclusief de twee afzonderlijke lidwoorden): **De | map | ligt | op | de | tafel.**.

Betekenisvraag 1: Wat ligt op de tafel? → **De map.**

Betekenisvraag 2: Waar ligt de map? → **Op de tafel.**

Plaatsgroep om te onderstrepen: **op de tafel**. Plaatshandeling: Leg een echte papieren map op de tafel; vraag waar de map ligt. De bestaande foto hoeft geen tafel te bevatten.

Er is geen nieuwe bewezen zinopname: docentspraak is de betrouwbare fallback, niet het herhalen van helewoordaudio.

Bij zelfstandige zinslezing eerst alleen het schrift en geen onmiddellijke audio of beeld. Benodigde woordbouw en alfabetiseringsvoorwaarden blijven docentobservaties.

**Werkblad Zin:** juiste kaartvolgorde is de volledige doelzin, onderstreep de plaatsgroep, laat een simpele tekening of eigen plek beschrijven.

## Stap 3 — Tekst

Lees deze drie zinnen als één samenhangende tekst:

> De map ligt op de tafel.

> Ik zoek een brief.

> Ik doe de brief in de map.

**Bouwopdracht met zeven woordkaartjes:** Ik | doe | de | brief | in | de | map.

Begripsvraag 1: Waar ligt de map? → **Op de tafel.**

Begripsvraag 2: Wat zoekt iemand? → **Een brief.**

Begripsvraag 3: Waar gaat de brief heen? → **In de map.**

**Handeling:** Leg een papieren brief op tafel, laat zoeken en stop hem daarna in de map. Gebruik geen echte persoonsgegevens op papier.

**Zelf maken:** Wat doe jij in een map? Zeg of schrijf één eigen begrijpelijke zin. Goed model: Ik doe de brief in de map.

Ook een eigen, passende formulering is goed; grammatica- en spellingfeedback mogen later volgen. Een eigen zin is geen automatische toets.

**Werkblad Tekst:** drie zinbegripsvragen, zeven kaartvakken, schrijfregels. Gebruik geen persoonlijke gegevens in voorbeeldbrief, tasinhoud of op het digibord.

## Antwoord- en observatiegrenzen

Formatieve onderscheidingen: begrijpen van beeld, begrijpen van gehoorde woorden, letter-klankkoppeling, woordbouw, eigen leesbeurt, zinsbegrip, samenhangend tekstlezen, mondelinge transfer, schriftelijke uiting. Geen totaalcijfer of automatisch niveauoordeel.

Bij een fout volgt hulp in stappen: eerst opnieuw aanwijzen/voorwerp tonen, dan eerste klank/woordgroep, dan samen voordoen. Daarna opnieuw proberen. Hulpvolgorde als observatie markeren.

Geen onbekende contrastwoorden als afleiders. Gebruik tas en map niet automatisch als elkaar al bekende woorden: eerst beide in een echte les introduceren.

## Media- en licentiegrens

Woordaudio en afbeelding zijn geregistreerd met reviewstatus open. Losse m, korte /ɑ/, p-opnamen niet aangenomen; kruisje bij ontbrekende bron, géén woordaudio/letternaam als fallback.

Geen nieuwe zin-/tekstopnamen en geen afgegeven menselijke mediagoedkeuring.

## Open productiepunten

Controleer de werkelijke bestaande Klink-les en guidedExerciseIds voor klink-woord-map bij integratie; koppel geen fictieve oefening.

De definitieve integratiecode, audio-opnamen, beeldreview, fysieke printercontrole en klasproef worden afzonderlijk in Work geverifieerd. Niets live zonder toestemming.
