# Klink+docent — TAS — Docentenhandleiding en antwoordmodel

Versie 1.0, 28 oktober 2026. Alleen docent; niet projecteren.

## Lesorganisatie en voorbereiding

- Neem een echte tas; desgewenst lunchbox of trommel mee. Gebruik de geregistreerde foto op het digibord alleen na betekenis- en rechtencontrole.

- De les start direct met **Les openen**; er is geen verplichte voorcheck of routekeuze. Hier staan alleen adviezen voor didactische voorbereiding.

- Alle deelnemers starten met het woord. De docent kan binnen één les later naar Zin en Tekst bewegen. Geef onbekende woorden voldoende mondelinge en schriftelijke voorbereiding voor je onafhankelijk lezen vraagt.

- Voordoen, Samen doen, Zelfstandig zijn werkvormen en geen publiek zichtbare route- of cursistlabels.

- Klankbord, woordbord, leesplank, spiegelbord en leeg schrijfbord zijn tijdelijke, geprojecteerde tools. Verberg persoonlijke observaties.

## Stap 1 — Woord

Doelwoord: **tas**. Artikel: **de tas**. Uitspraak: **/tɑs/**. Segmenteer in **t + a + s**; de a is kort /ɑ/.

Correcte tegels: **t – a – s**. Alternatieve tegelvolgorde aan het begin: **s – a – t**.

Docent zegt bij afbeelding: ‘Wat zie je? Wijs het aan.’ Na mondelinge kennismaking pas schrift tonen.

Luister- en nazegopdracht: speel het hele woord af als bron technisch werkt; voor fonemen bestaan apart toetsbare knoppen. Ontbreekt foneemopname, dan verschijnt een klein rood kruisje en spreekt de docent zelf voor.

Laat voor het eigen leesmoment alle afbeelding en automatisch geluid weg. Observeer of de cursist het geschreven woord zelfstandig, met klankhulp of slechts na een model leest.

**Werkblad Woord:** correcte eerste/tweede/derde letter zoals hierboven. Overtekenen of schrijven is optioneel; een deelnemer kan op papierkaartjes bouwen zonder schrijfdwang.

## Stap 2 — Zin

Doelzin: **De tas staat bij de deur.**

Zes unieke fysieke kaartjes (inclusief de twee afzonderlijke lidwoorden): **De | tas | staat | bij | de | deur.**.

Betekenisvraag 1: Wat staat bij de deur? → **De tas.**

Betekenisvraag 2: Waar staat de tas? → **Bij de deur.**

Plaatsgroep om te onderstrepen: **bij de deur**. Plaatshandeling: Zet de echte tas bij de deur of wijs een deur aan; de bronfoto hoeft geen deur te tonen.

Er is geen nieuwe bewezen zinopname: docentspraak is de betrouwbare fallback, niet het herhalen van helewoordaudio.

Bij zelfstandige zinslezing eerst alleen het schrift en geen onmiddellijke audio of beeld. Benodigde woordbouw en alfabetiseringsvoorwaarden blijven docentobservaties.

**Werkblad Zin:** juiste kaartvolgorde is de volledige doelzin, onderstreep de plaatsgroep, laat een simpele tekening of eigen plek beschrijven.

## Stap 3 — Tekst

Lees deze drie zinnen als één samenhangende tekst:

> De tas staat bij de deur.

> Ik doe mijn lunch in de tas.

> Ik neem de tas mee naar mijn werk.

**Bouwopdracht met zeven woordkaartjes:** Ik | doe | mijn | lunch | in | de | tas.

Begripsvraag 1: Waar staat de tas? → **Bij de deur.**

Begripsvraag 2: Wat gaat in de tas? → **De lunch.**

Begripsvraag 3: Waar gaat de tas naartoe? → **Naar het werk.**

**Handeling:** Doe een lunchbox in de tas en neem de tas daarna mee; het woord lunch mag eerst mondeling worden geïntroduceerd.

**Zelf maken:** Wat doe jij in je tas? Zeg of schrijf één eigen begrijpelijke zin. Goed model: Ik doe mijn lunch in de tas.

Ook een eigen, passende formulering is goed; grammatica- en spellingfeedback mogen later volgen. Een eigen zin is geen automatische toets.

**Werkblad Tekst:** drie zinbegripsvragen, zeven kaartvakken, schrijfregels. Gebruik geen persoonlijke gegevens in voorbeeldbrief, tasinhoud of op het digibord.

## Antwoord- en observatiegrenzen

Formatieve onderscheidingen: begrijpen van beeld, begrijpen van gehoorde woorden, letter-klankkoppeling, woordbouw, eigen leesbeurt, zinsbegrip, samenhangend tekstlezen, mondelinge transfer, schriftelijke uiting. Geen totaalcijfer of automatisch niveauoordeel.

Bij een fout volgt hulp in stappen: eerst opnieuw aanwijzen/voorwerp tonen, dan eerste klank/woordgroep, dan samen voordoen. Daarna opnieuw proberen. Hulpvolgorde als observatie markeren.

Geen onbekende contrastwoorden als afleiders. Gebruik tas en map niet automatisch als elkaar al bekende woorden: eerst beide in een echte les introduceren.

## Media- en licentiegrens

Woordaudio en beeld hebben reviewstatus open. Losse klanken t, korte /ɑ/, s moeten apart geverifieerd/opgenomen worden; geen vervangen door woordaudio of alfabetnamen.

Geen nieuwe zin-/tekstopnamen en geen afgegeven menselijke mediagoedkeuring.

## Open productiepunten

Controleer de werkelijke bestaande Klink-les en guidedExerciseIds voor klink-woord-tas bij integratie; koppel geen fictieve oefening.

De definitieve integratiecode, audio-opnamen, beeldreview, fysieke printercontrole en klasproef worden afzonderlijk in Work geverifieerd. Niets live zonder toestemming.
