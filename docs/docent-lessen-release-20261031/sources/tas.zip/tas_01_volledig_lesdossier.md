# Klink+docent | TAS | Volledige inhoudelijke les

**Editie:** 1.0 — 28 oktober 2026. **Status:** productierijpe INHOUDSBRON voor Work, NIET ingebouwd of live gepubliceerd. 


**Bronwoord:** `klink-woord-tas` — *de tas*, uitspraak /tɑs/; fonemen: t · a · s.

**Bestaande afbeelding:** `/package-media/artsmart-20261025/k341.webp`; **bestaande woordaudio:** `/package-audio/taalroute/klink-woord-tas.wav`. Beide in mediaregister met **review open**; daadwerkelijke menselijke goedkeuring ontbreekt.

**Betekenis:** tas (draag-/boodschappentas), niet een willekeurige tas als abstract icoon. **Scène:** Van huis naar werk: iemand zet een tas klaar, doet er lunch in en neemt hem mee..

**Product:** Klink+docent binnen de bestaande Klink-app; één digibord, direct Les openen, drie zichtbare stappen Woord → Zin → Tekst, ieder acht fasen; vijf tools met statusbehoud. Geen publieke Alfa A/B/C of privédocentnotities. Geen H5P-technologie.


## Leerdoelen en leergrenzen

- **Woord:** betekenis herkennen, hele woord horen en zeggen, afzonderlijke klanken koppelen, doelwoord bouwen, eerste zelfstandige leesbeurt zonder audio/foto, functioneel mondeling gebruiken.

- **Zin:** voorwerp en plaatsrelatie begrijpen; exact zes woordkaartjes geordend leggen, een voorbereide zin onafhankelijk lezen en toepassen.

- **Tekst:** drie samenhangende zinnen lezen en begrijpen, antwoord uit de tekst onderbouwen, een relevante handelingszin met zeven losse kaartjes bouwen, mondeling of schriftelijk een eigen begrijpelijke reactie formuleren.

- **Geen schijndoelen:** nazeggen = niet lezen; correct slepen = niet zelfstandig decoderen; korte tekst = geen volledig Alfa C. Geen individuele score of dossier in bordles.

### Voorkennis en docentinterventie

- Woord: Letters t, korte a en s met hun klanken vóór de onafhankelijke leesbeurt; de s is geen vanzelfsprekend reeds aangeleerde letter.

- Zin: Begrip tas/deur en betekenis van staat en bij; woordbeelden de, tas, staat, bij, deur; hoofdletter, spaties en punt. Canonieke beschikbaarheid betekent niet dat cursist dit beheerst.

- Tekst: Betekenis en woordherkenning van doe, mijn, lunch, in, neem, mee, naar, werk, ik; drie zinnen, tijdsvolgorde en handelingen; niet als bekend aannemen.

- Dit zijn **docentnotities**, GEEN verplichte softwarechecklist of prestartpoort. Onbekende woorden kunnen tijdens les worden voorgedaan en besproken. Dat betekent niet dat zelfstandig lezen daarna automatisch is aangetoond.

### Leerstof

- Stap 1 Woord: **tas** — **de tas**.

- Stap 2 Zin: **De tas staat bij de deur.**

- Stap 3 Tekst:
  De tas staat bij de deur.
  Ik doe mijn lunch in de tas.
  Ik neem de tas mee naar mijn werk.

- Zinskaartjes: De | tas | staat | bij | de | deur.

- Tekstkaartjes (focuszin): Ik | doe | mijn | lunch | in | de | tas.

### Volledige achtfasenuitwerking per stap


## STAP 1: WOORD

### 1. Kijken (2 actieve minuten, richtwaarde)

- **Digibord:** Toon het bestaande beeld van de tas eerst zonder woord. Haal het echte voorwerp erbij indien de foto niet duidelijk is.

- **Docentprompt en handeling:** ‘Wat zie je? Wijs de tas aan.’ Geef daarna mondeling het woord, met artikel.

- **Verwachte leerhandeling:** Aanwijzen of betekenis benoemen; woord hoeft nog niet gelezen te worden.

- **Hulp / differentiatie:** Wijs de belangrijkste vorm aan; laat een echte tas/map zien.

- **Feedback en antwoord:** ‘Ja, dit is de tas.’

- **Observatie:** Onderscheid beeldherkenning, mondeling woordgebruik en lezen.

### 2. Luisteren (2 actieve minuten, richtwaarde)

- **Digibord:** Toon de tas en een losse knop voor bestaande helewoordaudio (/package-audio/taalroute/klink-woord-tas.wav); voorkom autoplay.

- **Docentprompt en handeling:** ‘Luister naar tas. Zeg daarna tas.’ Herhaal met een korte beurt zonder model.

- **Verwachte leerhandeling:** Het woord horen en nazeggen; daarna eventueel zelfstandig benoemen.

- **Hulp / differentiatie:** Docent spreekt voor als audio technisch niet werkt; registreer de mediareview apart.

- **Feedback en antwoord:** ‘Je zegt het woord. Dat is luisteren en spreken; straks proberen we te lezen.’

- **Observatie:** Nazeggen is geen bewijs van decoderen; label hulp.

### 3. Klanken (3 actieve minuten, richtwaarde)

- **Digibord:** Laat de drie letters t – a – s elk met een eigen geluidsknop zien. Bij ontbrekende geïsoleerde audio klein rood kruisje naast precies die knop.

- **Docentprompt en handeling:** ‘Luister naar de klanken: t, a, s.’ Zeg de klanken fonetisch /tɑs/ gesegmenteerd; bij a de korte /ɑ/.

- **Verwachte leerhandeling:** De deelnemer wijst t-a-s in volgorde aan en voegt fonemen mondeling samen tot tas.

- **Hulp / differentiatie:** Gebruik de eigen stem voor ontbrekende foneemopnamen; niet de letterNAAM of helewoordaudio.

- **Feedback en antwoord:** ‘Je hoort t-a-s; samen is dat tas.’

- **Observatie:** Kunnen klanken aangewezen en samengevoegd worden, met welke hulp?

### 4. Bouwen (4 actieve minuten, richtwaarde)

- **Digibord:** Drie lege vakken; tegelset s, a, t in een andere volgorde dan de oplossing. Grote touch- en toetsenbordactie.

- **Docentprompt en handeling:** ‘Maak het woord tas. Welke letter komt eerst?’ Laat één deelnemer leggen en de klas meedenken.

- **Verwachte leerhandeling:** t-a-s in drie vakken; de volgorde is t, a, s.

- **Hulp / differentiatie:** Bied alleen eerste letter of één vak aan; bij fout horen we de eerste klank opnieuw.

- **Feedback en antwoord:** ‘Ja, je legt t-a-s. Probeer het woord nu te zeggen.’

- **Observatie:** Legt cursist na voorbeeld of met eigen klankanalyse? Niet automatisch leesbewijs.

### 5. Lezen (4 actieve minuten, richtwaarde)

- **Digibord:** Verberg foto en schakel autoplay uit; toon alleen ‘tas’. Na de leesbeurt pas foto/woordaudio onthullen.

- **Docentprompt en handeling:** ‘Probeer dit woord zelf te lezen. Kijk van links naar rechts.’ Wacht op eigen poging.

- **Verwachte leerhandeling:** tas zelfstandig of met expliciete klankhulp uit het woordbeeld afleiden.

- **Hulp / differentiatie:** Vraag welke klank vooraan staat; laat klank voor klank aan elkaar verbinden. Geen onmiddellijke oplossing.

- **Feedback en antwoord:** ‘Je leest tas.’ (of: ‘Met klankhulp lees je tas.’)

- **Observatie:** Onafhankelijk lezen en geholpen lezen apart vastleggen.

### 6. Gebruiken (4 actieve minuten, richtwaarde)

- **Digibord:** Toon de tas in een realistische situatie. Werk met een echt voorwerp en een eenvoudige aanwijstaak.

- **Docentprompt en handeling:** ‘Waar gebruik je de tas? Wat doe je ermee?’ Laat de deelnemer kort mondeling reageren.

- **Verwachte leerhandeling:** Handeling of eenvoudig mondeling antwoord in vertrouwde volwassen situatie.

- **Hulp / differentiatie:** Bied keuzebeeld/aanwijzen of beginzin, niet een te moeilijke geschreven opdracht.

- **Feedback en antwoord:** ‘Dat is een plek waar je dit voorwerp gebruikt.’

- **Observatie:** Betekenistransfer is nog geen bewijs van zinslezen.

### 7. Op papier (5 actieve minuten, richtwaarde)

- **Digibord:** De klas ziet alleen de neutrale melding ‘Werk op papier’; de drie afzonderlijke printbladen worden niet als niveaus getoond.

- **Docentprompt en handeling:** Geef het Woord-werkblad: klanken aanwijzen, letters leggen en woord zelfstandig proberen te lezen.

- **Verwachte leerhandeling:** Schrijft/legt t-a-s; leest tas met passende hulp; schrijft alleen indien motorisch haalbaar.

- **Hulp / differentiatie:** Leg fysieke letterkaartjes klaar; als schrijven nog niet past: leg of wijs.

- **Feedback en antwoord:** ‘Controleer je eerste letter, dan de rest.’

- **Observatie:** Noteer apart letterkennis, leggen, lezen, schrijven.

### 8. Nog een keer (3 actieve minuten, richtwaarde)

- **Digibord:** Toon na korte onderbreking ‘tas’ zonder beeld en verbind bij afsluiting uitsluitend met geverifieerde bestaande Klink-oefeningen.

- **Docentprompt en handeling:** ‘Lees nog één keer. Wat is dit? Waar zie je het?’ Plan herhaling in volgende les.

- **Verwachte leerhandeling:** Vernieuwde lees- en betekenisbeurt met eventueel minder hulp.

- **Hulp / differentiatie:** Geen fictieve zelfstudieknop; als bestaande doelroute nog niet gecontroleerd is: ‘Docent zoekt passende oefening’.

- **Feedback en antwoord:** ‘Je probeerde het woord nog een keer te lezen.’

- **Observatie:** Herhaling/terugkoppeling, geen formeel niveauoordeel.

## STAP 2: ZIN

### 1. Kijken (2 actieve minuten, richtwaarde)

- **Digibord:** Toon de concrete situatie: Zet de echte tas bij de deur of wijs een deur aan; de bronfoto hoeft geen deur te tonen.

- **Docentprompt en handeling:** ‘Kijk. Waar is de tas?’

- **Verwachte leerhandeling:** Aanwijzen of de plaats mondeling benoemen.

- **Hulp / differentiatie:** Laat eerst het voorwerp en de plaats aanwijzen zonder geschreven zin.

- **Feedback en antwoord:** ‘Bij de deur.’

- **Observatie:** Begrip van plaatsrelatie los van lezen.

### 2. Luisteren (2 actieve minuten, richtwaarde)

- **Digibord:** Toon zo nodig de situatie en laat de docent zelf de zin zeggen: ‘De tas staat bij de deur.’ Er is geen geverifieerde zinopname.

- **Docentprompt en handeling:** ‘Luister: De tas staat bij de deur.’ Vraag: ‘Wat hoor je?’

- **Verwachte leerhandeling:** Betekenis globaal uitleggen of handeling uitvoeren.

- **Hulp / differentiatie:** Doe de plaatsing voor. Spreek de zin niet automatisch bij zelfstandig lezen.

- **Feedback en antwoord:** ‘Je begrijpt nu waar het voorwerp is.’

- **Observatie:** Voorgelezen-zinbegrip is geen zelfstandig zinslezen.

### 3. Begrijpen (3 actieve minuten, richtwaarde)

- **Digibord:** Toon zin en voorwerpsituatie. Markeer op verzoek ‘de tas’ en ‘bij de deur’ als losse betekenisgroepen.

- **Docentprompt en handeling:** Stel twee vragen: ‘Wat staat bij de deur?’ en ‘Waar staat de tas?’

- **Verwachte leerhandeling:** De tas. / Bij de deur.

- **Hulp / differentiatie:** Laat de cursist de woorden die plaats aangeven aanwijzen, eerst mondeling.

- **Feedback en antwoord:** ‘Je hebt het voorwerp en de plaats gevonden.’

- **Observatie:** Juiste plaatsbetekenis, herkenning van woorden en lezen niet gelijkstellen.

### 4. Bouwen (4 actieve minuten, richtwaarde)

- **Digibord:** Zes zelfstandige woordkaartjes: De | tas | staat | bij | de | deur.. Toon zes lege vakken en gemengde kaartjes.

- **Docentprompt en handeling:** ‘Maak de zin. Begin met de hoofdletter. Lees terug.’

- **Verwachte leerhandeling:** Exact: De tas staat bij de deur.

- **Hulp / differentiatie:** Begin desgewenst met de eerste kaart, of laat de plaatsgroep pas als tweede leggen.

- **Feedback en antwoord:** ‘Nu staat de zin in de goede volgorde. Lees hem terug.’

- **Observatie:** Reconstructie met of zonder model, leest cursist alle woorden zelf?

### 5. Lezen (4 actieve minuten, richtwaarde)

- **Digibord:** Toon uitsluitend de hele zin ‘De tas staat bij de deur.’, zonder foto en zonder vooraf afgespeelde/voorgelezen versie.

- **Docentprompt en handeling:** ‘Lees de zin. Vertel daarna wat je hebt gelezen.’

- **Verwachte leerhandeling:** Eigen leesbeurt; betekenis van bij de deur benoemen.

- **Hulp / differentiatie:** Vraag het laatste woord of laat woordgrenzen aanwijzen, alleen bij vastlopen.

- **Feedback en antwoord:** ‘Je leest waar het voorwerp is.’

- **Observatie:** Onafhankelijkheid, tempo en hulp bij zinslezen kort noteren.

### 6. Gebruiken (4 actieve minuten, richtwaarde)

- **Digibord:** Twee deelnemers: één verplaatst het echte voorwerp, de ander zegt/leest waar het staat of ligt.

- **Docentprompt en handeling:** ‘Leg/zet het voorwerp nu ergens anders. Wat moet de zin zeggen?’ Gebruik mondeling nieuwe plek.

- **Verwachte leerhandeling:** Mondeling een nieuwe plaats beschrijven; geen niet-voorbereide zin verplicht laten schrijven.

- **Hulp / differentiatie:** Docent geeft beginzin. Laat oefenen met echte ruimte.

- **Feedback en antwoord:** ‘Je zegt waar het voorwerp is.’

- **Observatie:** Transfer van relatie; niet als nieuw leesbewijs registreren.

### 7. Op papier (5 actieve minuten, richtwaarde)

- **Digibord:** Neutraal zinblad: ‘De tas staat bij de deur.’, zes kaartvakken, markering van de plaatsgroep, één schrijflijn.

- **Docentprompt en handeling:** ‘Leg eerst de kaartjes. Onderstreep daarna de woorden die de plaats zeggen.’

- **Verwachte leerhandeling:** Correcte kaarten: De / tas / staat / bij / de / deur.. Plaatsgroep: bij de deur.

- **Hulp / differentiatie:** Hulp: mondeling ‘Waar?’ en wijzen naar de echte plek.

- **Feedback en antwoord:** ‘Je ziet waar de tas/map is.’

- **Observatie:** Begrijpen, bouwen en schrijven apart observeren.

### 8. Nog een keer (3 actieve minuten, richtwaarde)

- **Digibord:** Na korte wissel één nieuwe leesbeurt van ‘De tas staat bij de deur.’ zonder zichtbare foto.

- **Docentprompt en handeling:** ‘Lees de zin nog eens. Wijs daarna naar de juiste plek.’

- **Verwachte leerhandeling:** Passende nieuwe leesbeurt en handeling.

- **Hulp / differentiatie:** Als de zin nog te lastig is, beperk tot voorbereide woordgroepen en noteer hulp.

- **Feedback en antwoord:** ‘Lees en controleer of de voorwerpplek klopt.’

- **Observatie:** Één zin zegt niets over compleet Alfa B.

## STAP 3: TEKST

### 1. Kijken (2 actieve minuten, richtwaarde)

- **Digibord:** Kleine realistische situatie met bestaand woordbeeld plus echte attributen: Doe een lunchbox in de tas en neem de tas daarna mee; het woord lunch mag eerst mondeling worden geïntroduceerd.

- **Docentprompt en handeling:** ‘Wat zie je gebeuren? Wat doen we eerst?’ Maak de handeling voor.

- **Verwachte leerhandeling:** Handeling herkennen of mondeling beschrijven zonder drie geschreven zinnen.

- **Hulp / differentiatie:** Gebruik voorwerpen en gebaren; de geregistreerde woordfoto hoeft de volledige tekst niet uit te beelden.

- **Feedback en antwoord:** ‘We gaan een korte tekst lezen over dit voorwerp.’

- **Observatie:** Begrijpt cursist de handelingen en context?

### 2. Luisteren (2 actieve minuten, richtwaarde)

- **Digibord:** Toon de drie zinnen gefaseerd; docent leest indien passend: De tas staat bij de deur. Ik doe mijn lunch in de tas. Ik neem de tas mee naar mijn werk.

- **Docentprompt en handeling:** ‘Luister één keer. Vertel daarna in je eigen woorden wat er gebeurt.’

- **Verwachte leerhandeling:** Globale betekenis of passende handeling.

- **Hulp / differentiatie:** Lees één zin per keer wanneer nodig; noteer of cursist de tekst vooraf gehoord heeft.

- **Feedback en antwoord:** ‘Je vertelt wat er gebeurt.’

- **Observatie:** Een voorgelezen tekst telt niet als onafhankelijk tekstlezen.

### 3. Begrijpen (3 actieve minuten, richtwaarde)

- **Digibord:** Drie plaats- en handelingvragen met antwoordzinnen op verzoek onthulbaar: Waar staat de tas? / Wat gaat in de tas? / Waar gaat de tas naartoe?

- **Docentprompt en handeling:** Laat eerst aanwijzen of antwoorden; toon dan de passende regel en laat die kiezen.

- **Verwachte leerhandeling:** 1. Bij de deur. 2. De lunch. 3. Naar het werk.

- **Hulp / differentiatie:** Terug naar de zin die het antwoord geeft; niet uit de afbeelding laten raden wat er niet op staat.

- **Feedback en antwoord:** ‘Je vindt het antwoord in de juiste zin.’

- **Observatie:** Leesbegrip per vraag en het type benodigde hulp.

### 4. Bouwen (4 actieve minuten, richtwaarde)

- **Digibord:** Zeven woordkaartjes voor de handelingszin: Ik | doe | mijn | lunch | in | de | tas.. Mix kaartjes op het bord.

- **Docentprompt en handeling:** ‘Maak de zin met de kaartjes en lees hem terug.’ Focus op de handeling in de tekst.

- **Verwachte leerhandeling:** Doelzin: Ik doe mijn lunch in de tas.

- **Hulp / differentiatie:** Begin met ‘Ik’ en laat de laatste groep in de juiste volgorde leggen; voorkom dat de docent al het antwoord weggeeft.

- **Feedback en antwoord:** ‘Deze volgorde maakt een duidelijke zin.’

- **Observatie:** Zinsbouw, woordvolgorde en betekenis apart observeren.

### 5. Lezen (4 actieve minuten, richtwaarde)

- **Digibord:** Toon de volledige drie zinnen zonder ondersteunende foto of autoplay: De tas staat bij de deur. Ik doe mijn lunch in de tas. Ik neem de tas mee naar mijn werk.

- **Docentprompt en handeling:** ‘Lees de tekst. Wat is eerst? Wat gebeurt daarna?’

- **Verwachte leerhandeling:** Eigen leesbeurt en samenhang van handelingen aantonen.

- **Hulp / differentiatie:** Eventueel terug naar de eerste zin of één moeilijk contextwoord; markeer als geholpen.

- **Feedback en antwoord:** ‘Je gebruikt de hele tekst om te begrijpen wat er gebeurt.’

- **Observatie:** Onafhankelijk tekstlezen is een apart observatiepunt; één tekst ≠ volledig Alfa C.

### 6. Gebruiken (4 actieve minuten, richtwaarde)

- **Digibord:** Rolwissel: één cursist voert een handeling uit met echte voorwerpen. Doe een lunchbox in de tas en neem de tas daarna mee; het woord lunch mag eerst mondeling worden geïntroduceerd.

- **Docentprompt en handeling:** ‘Wat doe je? Welke zin past bij de handeling?’ Laat klas aanwijzen en rollen wisselen.

- **Verwachte leerhandeling:** Passende zin koppelen aan handeling, daarna mondeling variëren.

- **Hulp / differentiatie:** Doe eerst samen voor en kies dan twee zinnen; respecteer dat beeld niet alle handelingen toont.

- **Feedback en antwoord:** ‘Je kiest een zin die bij de handeling past.’

- **Observatie:** Transfer, niet automatisering van onbekende spelling.

### 7. Zelf maken (5 actieve minuten, richtwaarde)

- **Digibord:** Korte vrije uiting, optioneel schrijven: Wat doe jij in je tas? Zeg of schrijf één eigen begrijpelijke zin. Er is ruimte voor één eigen zin.

- **Docentprompt en handeling:** Laat deelnemer eerst zelf formuleren, daarna eventueel opschrijven; mondelinge reactie mag.

- **Verwachte leerhandeling:** Voorbeeld (niet verplicht): Ik doe mijn lunch in de tas. Andere betekenisvolle antwoorden zijn goed.

- **Hulp / differentiatie:** Bied één beginwoord of een mondeling model pas na eigen poging; geen automatische goed/foutscore.

- **Feedback en antwoord:** ‘Is voor een ander duidelijk wat je bedoelt?’

- **Observatie:** Eigen formulering en schrijven apart observeren; privacy: geen namen/persoonsgegevens.

### 8. Nog een keer (3 actieve minuten, richtwaarde)

- **Digibord:** Dek tekst af; laat de handeling of de volgorde navertellen. Toon daarna de drie zinnen ter controle: De tas staat bij de deur. Ik doe mijn lunch in de tas. Ik neem de tas mee naar mijn werk.

- **Docentprompt en handeling:** ‘Wat gebeurde eerst? Wat daarna? Lees de tekst nog eens en kijk of het klopt.’

- **Verwachte leerhandeling:** Navertelling of nieuwe leesbeurt met minder hulp.

- **Hulp / differentiatie:** De docent herhaalt alleen de noodzakelijke zin en plant later een andere tekst.

- **Feedback en antwoord:** ‘Je controleert je eigen verhaal met de tekst.’

- **Observatie:** Reflectie op gebruik; niet als formele niveauvaststelling.

## Differentiatie, onderliggende route versus zichtbare les

- Alle cursisten beginnen gezamenlijk bij Woord. De docent kan eerdere/latere stappen of fasen kiezen zonder dat er niveauaanduidingen worden geprojecteerd. Er is geen verplichte Alfa-routekeuze.

- **Voordoen:** docent benoemt/legt voor, geeft één model en laat deelnemers volgen. **Samen doen:** begeleide beurt met vraag en één hint. **Zelfstandig:** nieuwe beurt zonder direct model/foto/audio, met expliciete feedback na afloop. Ondersteuningsvorm is niet hetzelfde als didactische route.

- Volwassenen kunnen op Woord aanwijzen, bij Zin een voorbereide zin lezen en bij Tekst handelen en zelf formuleren. Eén kaartje mag geen automatisch niveau-oordeel bepalen.

## Audio en beelden

Woordaudio en beeld hebben reviewstatus open. Losse klanken t, korte /ɑ/, s moeten apart geverifieerd/opgenomen worden; geen vervangen door woordaudio of alfabetnamen.

- Woordaudio is een hélewoordbron; zin- en tekstaudio zijn niet als beschikbare bronnen geverifieerd. Doe voor waar nodig. Nooit het hele woord gebruiken als isolatie van een foneem.

- Bij individuele klank ontbreekt technisch of inhoudelijk een geldige opname: klein rood kruisje naast die klank; les gaat door. Nieuwe bron werkt later data-gedreven na mediacontrole.

- Het beeld mag betekenis geven, maar bewijst geen locatie of handeling die er niet zichtbaar op staat. Voor die handelingen gebruikt de docent echte voorwerpen en mondelinge instructie. Geen onbeoordeelde AI-foto als substituut.

## Acht-fasenregie en vijf tools

Faseknoppen Kijken/Luisteren/Klanken-of-Begrijpen/Bouwen/Lezen/Gebruiken/Op papier-of-Zelf maken/Nog een keer. Bij het woord lezen wordt foto/audio eerst afgedekt. Bij toolgebruik blijft stap, fase, tegelvolgorde, onthulstatus en vrije tekst tot de huidige sessie intact. Tools: Klankbord, Woordbord, Leesplank, Spiegelbord en Leeg schrijfbord. Een nieuwe les ruimt bordnotities op; herladen herstelt de actuele stap volgens de huidige Klink+docent-basis.

## Papieren materialen

Negen aparte proefdrukken: voor iedere stap één neutraal werkblad, één kaartvel en één privé-docentobservatie. Cursistenbladen bevatten geen Alfa A/B/C, Steun/Basis/Plus, persoonsgegevens of docentnotities. Alle instructies kunnen mondeling gegeven worden. Er is geen foto in de losse afdrukken; de docent gebruikt het bestaande Klink-beeld op het bord of het echte voorwerp. Printplaatjes mogen pas uit de goedgekeurde mediabron worden ingebed na de beeldrechtenreview.

## Zelfstudie en werkbrug

Controleer de werkelijke bestaande Klink-les en guidedExerciseIds voor klink-woord-tas bij integratie; koppel geen fictieve oefening.

- De bestaande Klink-woordoefening is geschikt als herhaling van een woordenles zodra de echte route is bevestigd. Zij bewijst niet dat de nieuwe Zin- of Tekststap zelfstandig in de cursistenapp is gerealiseerd.

## Releasegrenzen

Deze uitwerking is inhoud voor verdere integratie. Geen nieuwe appcode, GitHub-PR, geverifieerde audioklanken, menselijke mediareview, onafhankelijke didactische review, fysieke digibordtest, fysieke printertest, klasproef of livepublicatie wordt hiermee geclaimd. Zie de aparte softwarekaart en reviewpunten.
