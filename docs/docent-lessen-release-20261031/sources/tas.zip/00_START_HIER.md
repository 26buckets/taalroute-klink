# Klink+docent — TAS — START HIER

Inhoudelijke productie v1.0, 28 oktober 2026. Volgorde: eerst Tas, daarna Map.

Alleen lesCONTENT en tekst-/printproducten. **Niet geïmplementeerd in de Klink-app, niet gemerged of live gepubliceerd.** De huidige PR voor MAT is de technische referentie en bevat de laatst vastgestelde drie stappen **Woord, Zin, Tekst**, elk acht fasen; niet de verouderde berichttaak.

- Canoniek doelwoord: `klink-woord-tas`; foto `/package-media/artsmart-20261025/k341.webp`; helewoordaudio `/package-audio/taalroute/klink-woord-tas.wav`; menselijke review OPEN.
- Nieuwe zin: **De tas staat bij de deur.**
- Driezinnentekst: **De tas staat bij de deur. Ik doe mijn lunch in de tas. Ik neem de tas mee naar mijn werk.**
- 24 faseobjecten in `tas_lessen_content_v1.json`; ook leesbaar in `tas_01_volledig_lesdossier.md`.
- Software- en contentkaart, P0/P1-acceptatie en status in `tas_02_softwarekaart_acceptatie.md`.
- Exact negen proefdrukken: woord/zin/tekst × werkblad/kaartjes/docentobservatie. Op leerlingpagina's geen Alfa A/B/C of Steun/Basis/Plus. Docentobservatie NIET projecteren.
- Voor de opdracht op papier gebruikt de docent een echt voorwerp of Klink-afbeelding op het bord; er worden geen onbeoordeelde beelden ingebed in het PDF. Dit is functioneel proefmateriaal, géén volledige persklare drukset.

**Open:** echte lesmotorintegratie, controle van de exacte curriculumplaatsing/zelfstudie-IDs, individuele foneemaudio, menselijke beeld-/audio-/rechtenreview, onafhankelijke didactische review, fysieke afdruk-/bordproef en klasvalidatie.

Dit materiaal kan veilig in de bestaande Drive-map worden opgeslagen en later door een afzonderlijke Work-chat worden geïmplementeerd zonder Mat te overschrijven.
