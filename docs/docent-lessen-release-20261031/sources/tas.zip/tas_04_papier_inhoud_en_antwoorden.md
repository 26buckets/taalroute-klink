# Klink+docent — TAS — Negen afdrukproducten en correctiemodel

Dit document is de bewerkbare semantische bron voor de negen A4-PDF-proeven. Cursistenpagina’s hebben uitsluitend een neutrale titel zonder Alfa A/B/C of Steun/Basis/Plus. De drie observatiebladen blijven privé.

## Woord: werkblad

- Titel: DE TAS.

- Toon lettervolgorde t, a, s en drie lege vakken.

- Afzonderlijk leesobject: tas (zonder foto of audio tijdens echte eigen leesbeurt).

- Optioneel woord overschrijven: twee brede schrijflijnen. Geen verplichte lange leestekst.

- Antwoorden: t - a - s; tas.

## Woord: kaartjes

- Drie grootformaat knipkaarten: t, a, s. Los woordkaartje: tas.

## Woord: privé-observatie

- Betekenis, nazeggen, klanken, bouwen, eigen lezen, mondelinge toepassing. Bij ieder: zelfstandig / met hulp / nog niet waargenomen. Geen score.

## Zin: werkblad

- Titel DE TAS met doelzin: De tas staat bij de deur.

- Zes lege kaartvakken om de zin op te bouwen, één lijn voor onderstreping van de plaatswoorden en ruimte om te tekenen/schrijven.

- Antwoord plaatsgroep: bij de deur.

## Zin: kaartjes

- Exact zes losse kaartjes: De | tas | staat | bij | de | deur.

## Zin: privé-observatie

- Voorwerpsbegrip, plaatsrelatie, zes kaartjes, zinslezen zonder direct model, transfer en type hulp.

## Tekst: werkblad

- Titel DE TAS; drie zinnen:

  De tas staat bij de deur.

  Ik doe mijn lunch in de tas.

  Ik neem de tas mee naar mijn werk.

- Drie betekenisvragen met antwoordruimte:

  Waar staat de tas? (Antwoord: Bij de deur.)

  Wat gaat in de tas? (Antwoord: De lunch.)

  Waar gaat de tas naartoe? (Antwoord: Naar het werk.)

- Zeven lege kaartvakken en twee lijnen voor een eigen korte uiting.

## Tekst: kaartjes

- Exact zeven kaartjes in te knippen volgorde: Ik | doe | mijn | lunch | in | de | tas.

## Tekst: privé-observatie

- Begrip van drie zinnen, de drie tekstvragen, kaartvolgorde, eigen tekstlezen, handeling en vrije uiting. Iedere observatie met hulpstatus.

## Druk-/uitvoeringscontrole

- A4 één pagina per uitvoer, zwart-wit en marges; PDF wordt lokaal gerenderd en de tekst en paginering gecontroleerd.

- De cursistenbladen bevatten geen niveauaanduiding; docentobservatie niet projecteren.

- Bestaande Klink-beeldbronnen en officiële logo-assets zijn niet in deze losse PDF-proeven ingebed, omdat de menselijke media-/rechtenreview openstaat. Toon beeld in de bordles of neem echte voorwerpen mee.

- Fysieke print en menselijke didactische beoordeling staan nog open.
