# KLINK Luisteren | V0.4 | A2

20 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-A2-understand-001 | Veranderd werkrooster

**Oefenvorm:** Luister en kies
**Gesproken bron:** Je dienst begint donderdag een halfuur eerder: om half acht.
**Vraag:** Hoe laat begint de dienst donderdag?

- **A** Om half acht (goed). Goed. Je hoort: “Je dienst begint donderdag een halfuur eerder: om half acht”. Daarom is “Om half acht” het juiste antwoord.
- **B** Om acht uur (fout). Niet goed. Je hoort: “Je dienst begint donderdag een halfuur eerder: om half acht”. Daarom past “Om acht uur” niet. Het juiste antwoord is “Om half acht”.
- **C** Om half negen (fout). Niet goed. Je hoort: “Je dienst begint donderdag een halfuur eerder: om half acht”. Daarom past “Om half negen” niet. Het juiste antwoord is “Om half acht”.

**Bewijs:** Je dienst begint donderdag een halfuur eerder: om half acht.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-002 | Een product omruilen

**Oefenvorm:** Luister en kies
**Gesproken bron:** U kunt de jas binnen veertien dagen omruilen als u de bon bewaart.
**Vraag:** Wat moet de klant bewaren?

- **A** De verpakking alleen (fout). Niet goed. Je hoort: “U kunt de jas binnen veertien dagen omruilen als u de bon bewaart”. Daarom past “De verpakking alleen” niet. Het juiste antwoord is “De bon”.
- **B** De bankpas (fout). Niet goed. Je hoort: “U kunt de jas binnen veertien dagen omruilen als u de bon bewaart”. Daarom past “De bankpas” niet. Het juiste antwoord is “De bon”.
- **C** De bon (goed). Goed. Je hoort: “U kunt de jas binnen veertien dagen omruilen als u de bon bewaart”. Daarom is “De bon” het juiste antwoord.

**Bewijs:** U kunt de jas binnen veertien dagen omruilen als u de bon bewaart.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-003 | Een aanvraag

**Oefenvorm:** Luister en kies
**Gesproken bron:** Voor de aanvraag moet u uw identiteitsbewijs en een recente loonstrook meenemen.
**Vraag:** Welke documenten zijn nodig?

- **A** Alleen een identiteitsbewijs (fout). Niet goed. Je hoort: “Voor de aanvraag moet u uw identiteitsbewijs en een recente loonstrook meenemen”. Daarom past “Alleen een identiteitsbewijs” niet. Het juiste antwoord is “Identiteitsbewijs en loonstrook”.
- **B** Identiteitsbewijs en loonstrook (goed). Goed. Je hoort: “Voor de aanvraag moet u uw identiteitsbewijs en een recente loonstrook meenemen”. Daarom is “Identiteitsbewijs en loonstrook” het juiste antwoord.
- **C** Pasfoto en treinkaartje (fout). Niet goed. Je hoort: “Voor de aanvraag moet u uw identiteitsbewijs en een recente loonstrook meenemen”. Daarom past “Pasfoto en treinkaartje” niet. Het juiste antwoord is “Identiteitsbewijs en loonstrook”.

**Bewijs:** Voor de aanvraag moet u uw identiteitsbewijs en een recente loonstrook meenemen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-004 | Vertraging door werkzaamheden

**Oefenvorm:** Luister en kies
**Gesproken bron:** Door werkzaamheden rijdt de trein vandaag niet rechtstreeks naar Utrecht.
**Vraag:** Waarom rijdt de trein niet rechtstreeks?

- **A** Door werkzaamheden (goed). Goed. Je hoort: “Door werkzaamheden rijdt de trein vandaag niet rechtstreeks naar Utrecht”. Daarom is “Door werkzaamheden” het juiste antwoord.
- **B** Door een feestdag (fout). Niet goed. Je hoort: “Door werkzaamheden rijdt de trein vandaag niet rechtstreeks naar Utrecht”. Daarom past “Door een feestdag” niet. Het juiste antwoord is “Door werkzaamheden”.
- **C** Door slecht weer (fout). Niet goed. Je hoort: “Door werkzaamheden rijdt de trein vandaag niet rechtstreeks naar Utrecht”. Daarom past “Door slecht weer” niet. Het juiste antwoord is “Door werkzaamheden”.

**Bewijs:** Door werkzaamheden rijdt de trein vandaag niet rechtstreeks naar Utrecht.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-005 | Een klacht melden

**Oefenvorm:** Luister en kies
**Gesproken bron:** De verwarming doet het niet en de verhuurder komt morgen kijken.
**Vraag:** Wat gaat de verhuurder doen?

- **A** Vandaag een nieuwe ketel plaatsen (fout). Niet goed. Je hoort: “De verwarming doet het niet en de verhuurder komt morgen kijken”. Daarom past “Vandaag een nieuwe ketel plaatsen” niet. Het juiste antwoord is “Morgen komen kijken”.
- **B** Volgende week een brief sturen (fout). Niet goed. Je hoort: “De verwarming doet het niet en de verhuurder komt morgen kijken”. Daarom past “Volgende week een brief sturen” niet. Het juiste antwoord is “Morgen komen kijken”.
- **C** Morgen komen kijken (goed). Goed. Je hoort: “De verwarming doet het niet en de verhuurder komt morgen kijken”. Daarom is “Morgen komen kijken” het juiste antwoord.

**Bewijs:** De verwarming doet het niet en de verhuurder komt morgen kijken.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-006 | Een dienst ruilen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Ik kan mijn avonddienst van dinsdag ruilen als ik vrijdag voor mijn collega werk.
**Vraag:** Wat moet de spreker dan doen?

- **A** Dinsdag eerder beginnen (fout). Niet goed. Je hoort: “Ik kan mijn avonddienst van dinsdag ruilen als ik vrijdag voor mijn collega werk”. Daarom past “Dinsdag eerder beginnen” niet. Het juiste antwoord is “Vrijdag voor een collega werken”.
- **B** Vrijdag voor een collega werken (goed). Goed. Je hoort: “Ik kan mijn avonddienst van dinsdag ruilen als ik vrijdag voor mijn collega werk”. Daarom is “Vrijdag voor een collega werken” het juiste antwoord.
- **C** Maandag voor een collega werken (fout). Niet goed. Je hoort: “Ik kan mijn avonddienst van dinsdag ruilen als ik vrijdag voor mijn collega werk”. Daarom past “Maandag voor een collega werken” niet. Het juiste antwoord is “Vrijdag voor een collega werken”.

**Bewijs:** Ik kan mijn avonddienst van dinsdag ruilen als ik vrijdag voor mijn collega werk.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-007 | De afspraak bevestigen

**Oefenvorm:** Luister en kies
**Gesproken bron:** De afspraak staat op woensdag om kwart over twee. Laat vandaag weten of u kunt komen.
**Vraag:** Wat wordt gevraagd?

- **A** Vandaag laten weten of je kunt komen (goed). Goed. Je hoort: “Laat vandaag weten of u kunt komen”. Daarom is “Vandaag laten weten of je kunt komen” het juiste antwoord.
- **B** Woensdag een nieuwe afspraak maken (fout). Niet goed. Je hoort: “Laat vandaag weten of u kunt komen”. Daarom past “Woensdag een nieuwe afspraak maken” niet. Het juiste antwoord is “Vandaag laten weten of je kunt komen”.
- **C** Morgen betalen (fout). Niet goed. Je hoort: “Laat vandaag weten of u kunt komen”. Daarom past “Morgen betalen” niet. Het juiste antwoord is “Vandaag laten weten of je kunt komen”.

**Bewijs:** Laat vandaag weten of u kunt komen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-008 | Een cursus kiezen

**Oefenvorm:** Luister en kies
**Gesproken bron:** De avondcursus duurt tien weken en kost minder dan de cursus op zaterdag.
**Vraag:** Welke cursus kost minder?

- **A** De zaterdagcursus (fout). Niet goed. Je hoort: “De avondcursus duurt tien weken en kost minder dan de cursus op zaterdag”. Daarom past “De zaterdagcursus” niet. Het juiste antwoord is “De avondcursus”.
- **B** Beide cursussen evenveel (fout). Niet goed. Je hoort: “De avondcursus duurt tien weken en kost minder dan de cursus op zaterdag”. Daarom past “Beide cursussen evenveel” niet. Het juiste antwoord is “De avondcursus”.
- **C** De avondcursus (goed). Goed. Je hoort: “De avondcursus duurt tien weken en kost minder dan de cursus op zaterdag”. Daarom is “De avondcursus” het juiste antwoord.

**Bewijs:** De avondcursus duurt tien weken en kost minder dan de cursus op zaterdag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-009 | Bij de apotheek

**Oefenvorm:** Luister en kies
**Gesproken bron:** Volgens het etiket moet u de tabletten twee keer per dag na het eten innemen.
**Vraag:** Wanneer moet de patiënt de tabletten nemen?

- **A** Drie keer per dag bij het slapen (fout). Niet goed. Je hoort: “Volgens het etiket moet u de tabletten twee keer per dag na het eten innemen”. Daarom past “Drie keer per dag bij het slapen” niet. Het juiste antwoord is “Twee keer per dag na het eten”.
- **B** Twee keer per dag na het eten (goed). Goed. Je hoort: “Volgens het etiket moet u de tabletten twee keer per dag na het eten innemen”. Daarom is “Twee keer per dag na het eten” het juiste antwoord.
- **C** Eén keer per dag voor het eten (fout). Niet goed. Je hoort: “Volgens het etiket moet u de tabletten twee keer per dag na het eten innemen”. Daarom past “Eén keer per dag voor het eten” niet. Het juiste antwoord is “Twee keer per dag na het eten”.

**Bewijs:** Volgens het etiket moet u de tabletten twee keer per dag na het eten innemen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-understand-010 | Een bestelling

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het product is niet op voorraad; we kunnen het vrijdag laten bezorgen.
**Vraag:** Wanneer kan het product worden bezorgd?

- **A** Vrijdag (goed). Goed. Je hoort: “Het product is niet op voorraad; we kunnen het vrijdag laten bezorgen”. Daarom is “Vrijdag” het juiste antwoord.
- **B** Donderdag (fout). Niet goed. Je hoort: “Het product is niet op voorraad; we kunnen het vrijdag laten bezorgen”. Daarom past “Donderdag” niet. Het juiste antwoord is “Vrijdag”.
- **C** Maandag (fout). Niet goed. Je hoort: “Het product is niet op voorraad; we kunnen het vrijdag laten bezorgen”. Daarom past “Maandag” niet. Het juiste antwoord is “Vrijdag”.

**Bewijs:** Het product is niet op voorraad; we kunnen het vrijdag laten bezorgen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-001 | Een maat vragen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Elena: Deze laars zit te strak. Hebt u een grotere maat?
Medewerker: Ja. Wilt u hetzelfde model?
Elena: Graag, als dat er nog is.
Medewerker: Ik kijk even in het magazijn.
**Vraag:** Wat wil Elena veranderen?

- **A** Het model. (fout). Niet goed. Je hoort: “Hebt u een grotere maat”. Daarom past “Het model” niet. Het juiste antwoord is “De maat”.
- **B** De maat. (goed). Goed. Je hoort: “Hebt u een grotere maat”. Daarom is “De maat” het juiste antwoord.
- **C** De kleur. (fout). Niet goed. Je hoort: “Hebt u een grotere maat”. Daarom past “De kleur” niet. Het juiste antwoord is “De maat”.

**Bewijs:** Hebt u een grotere maat?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-002 | Bij de kapper

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Youssef: Ik wil mijn haar iets korter, maar niet heel kort.
Kapper: Ongeveer twee centimeter eraf?
Youssef: Ja, dat lijkt me goed.
Kapper: Dan beginnen we daarmee.
**Vraag:** Wat spreken zij af?

- **A** Het haar alleen kammen. (fout). Niet goed. Je hoort: “Ongeveer twee centimeter eraf”. Daarom past “Het haar alleen kammen” niet. Het juiste antwoord is “Ongeveer twee centimeter korter”.
- **B** Ongeveer twee centimeter korter. (goed). Goed. Je hoort: “Ongeveer twee centimeter eraf”. Daarom is “Ongeveer twee centimeter korter” het juiste antwoord.
- **C** Al het haar eraf. (fout). Niet goed. Je hoort: “Ongeveer twee centimeter eraf”. Daarom past “Al het haar eraf” niet. Het juiste antwoord is “Ongeveer twee centimeter korter”.

**Bewijs:** Ongeveer twee centimeter eraf?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-003 | Iets niet begrijpen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: De verpakking van deze pil is anders. Kunt u dat uitleggen?
Apotheekmedewerker: Ja, ik kijk eerst welke verpakking u eerder had.
Nora: Wilt u het daarna rustig uitleggen?
Apotheekmedewerker: Natuurlijk. En u kunt vragen stellen.
**Vraag:** Wat vraagt Nora aan de medewerker?

- **A** Of de medewerker rustig wil uitleggen. (goed). Goed. Je hoort: “Wilt u het daarna rustig uitleggen”. Daarom is “Of de medewerker rustig wil uitleggen” het juiste antwoord.
- **B** Of de medewerker sneller wil praten. (fout). Niet goed. Je hoort: “Wilt u het daarna rustig uitleggen”. Daarom past “Of de medewerker sneller wil praten” niet. Het juiste antwoord is “Of de medewerker rustig wil uitleggen”.
- **C** Of de medewerker niets hoeft uit te leggen. (fout). Niet goed. Je hoort: “Wilt u het daarna rustig uitleggen”. Daarom past “Of de medewerker niets hoeft uit te leggen” niet. Het juiste antwoord is “Of de medewerker rustig wil uitleggen”.

**Bewijs:** Wilt u het daarna rustig uitleggen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-004 | Een plek bij het raam

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Elena: Mag ik hier zitten? Ik wil even in mijn boek lezen.
Nora: Ja. De stoel bij het raam is ook vrij.
Elena: Daar zit ik liever, want daar is meer licht.
Nora: Goed, ik zet mijn tas even opzij.
**Vraag:** Waarom kiest Elena de stoel bij het raam?

- **A** Daar is het warmer. (fout). Niet goed. Je hoort: “Daar zit ik liever, want daar is meer licht”. Daarom past “Daar is het warmer” niet. Het juiste antwoord is “Daar is meer licht”.
- **B** Daar is het stiller. (fout). Niet goed. Je hoort: “Daar zit ik liever, want daar is meer licht”. Daarom past “Daar is het stiller” niet. Het juiste antwoord is “Daar is meer licht”.
- **C** Daar is meer licht. (goed). Goed. Je hoort: “Daar zit ik liever, want daar is meer licht”. Daarom is “Daar is meer licht” het juiste antwoord.

**Bewijs:** Daar zit ik liever, want daar is meer licht.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-005 | Een andere tijd

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Rachid: Woensdag lukt mij niet. Kan onze afspraak een dag later?
Lotte: Donderdag kan ik na zes uur.
Rachid: Zullen we dan om zeven uur afspreken?
Lotte: Ja, ik zet het in mijn agenda.
**Vraag:** Welke nieuwe dag kiezen ze?

- **A** Woensdag. (fout). Niet goed. Je hoort: “Donderdag kan ik na zes uur”. Daarom past “Woensdag” niet. Het juiste antwoord is “Donderdag”.
- **B** Donderdag. (goed). Goed. Je hoort: “Donderdag kan ik na zes uur”. Daarom is “Donderdag” het juiste antwoord.
- **C** Dinsdag. (fout). Niet goed. Je hoort: “Donderdag kan ik na zes uur”. Daarom past “Dinsdag” niet. Het juiste antwoord is “Donderdag”.

**Bewijs:** Donderdag kan ik na zes uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-006 | Een vertraging melden

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Abel: Mijn bus komt later. Ik ben dus ook later bij jou.
Fatima: Weet je ongeveer hoe laat?
Abel: Nog niet. Ik stuur een bericht als de bus er is.
Fatima: Goed, dan wacht ik op je bericht.
**Vraag:** Wanneer stuurt Abel weer een bericht?

- **A** Over een uur. (fout). Niet goed. Je hoort: “Nog niet”. Daarom past “Over een uur” niet. Het juiste antwoord is “Als de bus er is”.
- **B** Als hij thuiskomt. (fout). Niet goed. Je hoort: “Nog niet”. Daarom past “Als hij thuiskomt” niet. Het juiste antwoord is “Als de bus er is”.
- **C** Als de bus er is. (goed). Goed. Je hoort: “Nog niet”. Daarom is “Als de bus er is” het juiste antwoord.

**Bewijs:** Nog niet.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-007 | Een andere ingang

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Sofia: Het hek hier is dicht. Kunnen we wel naar binnen?
Abel: Ja, aan de zijkant is nog een hek.
Sofia: Moeten we links om het gebouw lopen?
Abel: Ja, daar zie je de ingang.
**Vraag:** Waar moeten zij naartoe lopen?

- **A** Links om het gebouw. (goed). Goed. Je hoort: “Moeten we links om het gebouw lopen”. Daarom is “Links om het gebouw” het juiste antwoord.
- **B** Rechts om het gebouw. (fout). Niet goed. Je hoort: “Moeten we links om het gebouw lopen”. Daarom past “Rechts om het gebouw” niet. Het juiste antwoord is “Links om het gebouw”.
- **C** Door het gesloten hek. (fout). Niet goed. Je hoort: “Moeten we links om het gebouw lopen”. Daarom past “Door het gesloten hek” niet. Het juiste antwoord is “Links om het gebouw”.

**Bewijs:** Moeten we links om het gebouw lopen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-008 | Een beschadiging melden

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Kofi: In de kastdeur die ik kreeg zit een deuk.
Winkelmedewerker: Kunt u een foto sturen?
Kofi: Ja. Naar welk adres kan die?
Winkelmedewerker: Ik geef u onze contactgegevens.
**Vraag:** Wat vraagt de medewerker?

- **A** Een foto van de aankoopbon. (fout). Niet goed. Je hoort: “Kunt u een foto sturen”. Daarom past “Een foto van de aankoopbon” niet. Het juiste antwoord is “Een foto van de beschadiging”.
- **B** Een foto van de beschadiging. (goed). Goed. Je hoort: “Kunt u een foto sturen”. Daarom is “Een foto van de beschadiging” het juiste antwoord.
- **C** Een foto van de winkel. (fout). Niet goed. Je hoort: “Kunt u een foto sturen”. Daarom past “Een foto van de winkel” niet. Het juiste antwoord is “Een foto van de beschadiging”.

**Bewijs:** Kunt u een foto sturen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-009 | Hulp bij ophalen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Daan: Mijn afspraak loopt uit. Kun jij mijn kind ophalen?
Zijn moeder: Ja. Hoe laat moet ik er zijn?
Daan: Om drie uur. Ik bel de opvang dat jij komt.
Zijn moeder: Goed, dan ga ik op tijd weg.
**Vraag:** Hoe laat moet Daans moeder bij de opvang zijn?

- **A** Om vier uur. (fout). Niet goed. Je hoort: “Om drie uur”. Daarom past “Om vier uur” niet. Het juiste antwoord is “Om drie uur”.
- **B** Om drie uur. (goed). Goed. Je hoort: “Om drie uur”. Daarom is “Om drie uur” het juiste antwoord.
- **C** Om twee uur. (fout). Niet goed. Je hoort: “Om drie uur”. Daarom past “Om twee uur” niet. Het juiste antwoord is “Om drie uur”.

**Bewijs:** Om drie uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A2-dialogue-question-010 | Een boottocht verzetten

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Eva: De boot gaat later. Kan ik ook een andere tocht kiezen?
Medewerker: Ik kijk welke tochten nog plaats hebben.
Eva: Graag. Ik ben met mijn zoon, dus we hebben twee plaatsen nodig.
Medewerker: Ik controleer dat voor u.
**Vraag:** Hoeveel plaatsen heeft Eva nodig?

- **A** Eén. (fout). Niet goed. Je hoort: “Ik ben met mijn zoon, dus we hebben twee plaatsen nodig”. Daarom past “Eén” niet. Het juiste antwoord is “Twee”.
- **B** Acht. (fout). Niet goed. Je hoort: “Ik ben met mijn zoon, dus we hebben twee plaatsen nodig”. Daarom past “Acht” niet. Het juiste antwoord is “Twee”.
- **C** Twee. (goed). Goed. Je hoort: “Ik ben met mijn zoon, dus we hebben twee plaatsen nodig”. Daarom is “Twee” het juiste antwoord.

**Bewijs:** Ik ben met mijn zoon, dus we hebben twee plaatsen nodig.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
