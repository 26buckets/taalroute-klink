# KLINK LUISTEREN. INTEGRALE REDACTIE EN OPSCHALING v0.4

Datum: 2 november 2026. Canonieke bron voor deze bewerking: productie v0.3, Google Drive, zonder verandering aan de originele bronnen.

## Vastgestelde status
- 200 kandidaatopdrachten in 20 open niveau-/oefenvormcombinaties; 10 per combinatie. 180 nieuw ontwikkelde kandidaten plus 20 hergebruikte A1/A2-vraagkandidaten.
- 200 records zijn in deze reviewronde getoetst aan grammatica, spelling, natuurlijkheid, zinsvloeiendheid, referenties, vraag-antwoordlogica, didactische vorm, feedback bij alle drie opties en voorlopige niveaugeschiktheid. Er zijn 1257 traceerbare inhouds-/uitlegwijzigingen geregistreerd. Een expliciete redactionele check is geen onafhankelijke menselijke review.
- De oorspronkelijke A1/A2-bronopnamen en source-ID's zijn niet aangepast. De transcriptie en antwoordinformatie zijn gecontroleerd op hun schriftelijke vorm, niet auditief beluisterd.
- Niveaubrede verschillen: Alfa A/B moeten via audio en beelden werken zonder verplichte leestest; Alfa C blijft alfabetisering en kan aanvullende woordsteun krijgen; B1 heeft extra behoefte aan realistische voorwaarden en samenhang, niet alleen simpele feitvragen.
- Uitgangsbank met 200 vraagposities is inhoudelijk aanwezig, maar géén 200 publiceerbare audio-oefeningen. Alle media-, onafhankelijk niveau-, leerling- en runtime-poorten blijven HOLD.

## Concreet aangetroffen en hersteld
- Alfa A: "Is dit de bus? Ja, dat is de bus" vervangen door natuurlijke lijn over bus zeven; "Ja, lekker" op appel-aanbod vervangen door "Ja, graag". En een vraag over kopen naar "wil kopen" omdat het gesprek slechts een bestelling bevat.
- Alfa B: "Hoeveel appels koopt Mina?" bij alleen een uitgesproken bestelling veranderd in "wil Mina kopen"; vraag over de tas verduidelijkt.
- Alfa C: "We zijn tien minuten later" als antwoord op bustijd natuurlijker, plasticaanwijzing beter, en de bibliotheekreactie verbeterd. Vooral in de reactieoefeningen zijn afleiders dichter bij de situatie gemaakt.
- A1: natuurlijkere woordvolgorde over de bibliotheek en winkelbestelling. Bestaande A1/A2-dialogen zijn herkenbaar en brongetrouw gebleven.
- A2: natuurlijke instructie voor een etiket, uitsluitend als fictieve oefentekst. Geen echt medisch voorschrift.
- B1: een personage dat alleen in de vraag voorkwam is ook in de bron geïntroduceerd; het verschil tussen bestelbon en daadwerkelijk geleverde dozen is expliciet gemaakt; de telefonische reactie verwijst niet langer onterecht naar "de medewerker" in de derde persoon. Bij tien "Welke reactie past?"-oefeningen zijn 20 willekeurige of overduidelijk ongerelateerde afleiders vervangen door inhoudelijke dichtbijliggende fouten.
- Alle drie uitlegvelden per item zijn aangepast naar korte brongebonden formuleringen op beoogd A2-niveau. Dit is een AI-redactieronde, niet geijkt met taalgebruikers.

## Didactisch belangrijke bevinding
De eerste pilot gebruikt vaak dezelfde tien situaties in vier oefenvormen binnen één niveau. Dit is alleen een zinvolle herhaling als het leerdoel verschilt. Het zijn niet automatisch veertig geheel nieuwe ervaringen. Voor het 100-doel mogen de volgende negentig niet bestaan uit tien scripts met alleen gewijzigde vraagstelling. De vervolgprompts verdelen de productie over negen inhoudelijke thema's, met een expliciete variatie- en anti-duplicatiepoort.

## Schaalberekening
- 20 open combinaties × 100 = 2.000 beoogde oefeningen.
- Er zijn 200 kandidaten. Bij volledige inhoudelijke acceptatie zijn er nog **1.800 nieuwe originele opdrachten** nodig, 90 per open combinatie.
- Per open combinatie zijn 9 batches van 10 gepland, nummers 011 t/m 100. **180 nieuwe batches** van 10 over alle 20 cellen, bovenop de pilot.
- Daarnaast zijn er 10 al gevulde combinaties die NIET in deze open-celtelling zitten: Hoor en kies op zes niveaus en Begrijp het verhaal/Welke reactie past op A1/A2. Als ook elk hiervan 100 moet halen, moet hun bestaande aantal eerst uit de echte app en de Drive-bronnen worden vastgesteld. Het totale doel voor alle vijf luistervormen op zes niveaus is dan 30 × 100 = 3.000 oefenposities, niet automatisch 3.000 nieuwe producties.

## Productievolgorde
1. Laat 200 huidige items een grondige onafhankelijke NT2-/niveau-review krijgen en herstel de gemarkeerde didactische punten; behoud het bronverhaal ongewijzigd bij A1/A2-hergebruik.
2. Maak toestemmings-, versie-, stem-, bestands- en geluidscontroles. Registreer opname alleen als die werkelijk bestaat; controleer de 1.330 geregistreerde luisterposities eerst op uniek bronhergebruik. Geen fictieve WAV/MP3.
3. Check Klink-routes, QA, audio, afbeeldingen (vooral Alfa A/B), duplicaten en voortgang. Houd publicatie HOLD tot alle poorten aantoonbaar PASS zijn.
4. Maak daarna per cel batches 011-020, 021-030 ... 091-100, met een vaste intake en afgebakend thema, gevolgd door volledige review en Drive-opslag.
5. Vergelijk na ieder tiental of er meer variatie nodig is in gesproken intentie, sprekers, context en niveau. Een "kilometers maken"-oefenbank heeft oefendiepte nodig, niet kunstmatig opgehoogde tellerwaarden.

## Documenten in dit pakket
- Zes volledige bronbestanden, elk zowel JSON als leesbare Markdown.
- REVIEW_PER_ITEM_200.csv met 200 afzonderlijke controlebesluiten en open poorten.
- REVIEW_CORRECTIES_V03_NAAR_V04.json met traceerbare wijzigingen.
- DUPLICATIE_EN_VARIATIE_AUDIT.csv en de schaalmatrices.
- 20 combinatieprompts plus 180 zelfstandige batchprompts in PROMPTS_PER_BATCH_180, en de gedeelde masterregels.
- OPEN_PUNTEN_EN_PUBLICATIEPOORTEN.md en een gefaseerd productieregister.

**Vrijgavebesluit: CONTENT REVIEWED CANDIDATE / AUDIO + ERK + VOLLEDIGE DRIVE-DUPLICATEN + RUNTIME = HOLD. Geen nieuwe oefening live gepubliceerd.**
