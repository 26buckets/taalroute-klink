# Nieuwe KLINK-productiechat | Luisteren | B1 | Welke reactie past? | 011-020

Gebruik de verbonden Google Drive-projectmap van **KLINK Luisteren integrale review v0.4, 2 november 2026** als actuele bron van waarheid. Lees eerst `00_START_HIER.md`, `00_MASTERREGELS_PROMPTS_EN_QA.md`, `01_INTEGRAAL_REVIEWVERSLAG.md`, `REVIEW_PER_ITEM_200.csv` en de content voor B1. Controleer of nummers 011-020 al bestaan. Hergebruik geen afgekeurde of al geproduceerde bron als nieuwe opdracht.

**Maak nu exact tien volledige oefeningen**, IDs eindigend op 011-020, in de bestaande ID-structuur van `B1` + `suitable-reply`. Dit is ronde 02 van 10, thema **Wonen, buren en voorzieningen**. Niveau: B1. Type: Welke reactie past?.

**Vereisten:** Eén hoorbare gesprekspartner zegt iets; kies een inhoudelijk passende reactie tegenover twee geloofwaardige maar onjuiste reacties. Meerledige authentieke informatie, voorwaarden, oorzaak, doel, gevolg en gerichte vervolgstap; niet alleen één simpel feit.

Bij ELKE oefening: originele brontekst die Nederlands van volwassenen is, de volledige hoorbare spreekbeurten, bewijsplaats, vraag, drie natuurlijke en plausibele antwoordopties, precies één goed antwoord, een afzonderlijke en inhoudelijke A2-uitleg bij ieder goed/fout antwoord, audio-inspreekscript per beurt/instructie/vraag/keuze, stem- en beeldbehoefte, unieke ID's, bronreferenties, uitspraak-/grammatica-/spelling-/ERK-check, didactische onderbouwing en negatieve antwoordtests.

Controleer **woordkeus, vloeiendheid, spelling, grammatica, spreektaal, logica, leerdoel, niveau, afleiders, A2-feedback en dubbele thema's** grondig. Maak geen antwoord zichtbaar via contextafbeelding vóór de luisterhandeling. Vergelijk met de eerdere 200 en met relevante bestaande Klink-bronnen om duplicaten te vermijden. Leg alle correcties in een before/after-reviewlog vast.

Sla volledig op in de bestaande Google Drive-map, met leesbare Google Doc/Markdown, machineleesbare JSON, QA en status. **Niet publiceren** en niet beweren dat WAV/MP3 of definitieve ERK-acceptatie bestaat zonder toetsbaar bewijs. Behoud huidige media, oude bestanden, links en voortgang.

Eindig met een korte chatstatus, links en de volgende batch 021-030 (of afrondrapport bij 100).
