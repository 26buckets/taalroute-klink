# Nieuwe KLINK-productiechat | Luisteren | Alfa A | Begrijp het verhaal | 091-100

Gebruik de verbonden Google Drive-projectmap van **KLINK Luisteren integrale review v0.4, 2 november 2026** als actuele bron van waarheid. Lees eerst `00_START_HIER.md`, `00_MASTERREGELS_PROMPTS_EN_QA.md`, `01_INTEGRAAL_REVIEWVERSLAG.md`, `REVIEW_PER_ITEM_200.csv` en de content voor Alfa A. Controleer of nummers 091-100 al bestaan. Hergebruik geen afgekeurde of al geproduceerde bron als nieuwe opdracht.

**Maak nu exact tien volledige oefeningen**, IDs eindigend op 091-100, in de bestaande ID-structuur van `Alfa A` + `text-question`. Dit is ronde 10 van 10, thema **Vrije tijd, sociale contacten en gezin**. Niveau: Alfa A. Type: Begrijp het verhaal.

**Vereisten:** Eén natuurlijke samenhangende gesproken tekst, beantwoord een inhoudsvraag die niet op leesvaardigheid steunt. Korte concrete zinnen, gesproken instructie/vraag/opties, semantische beelden, geen verplichte leeslast.

Bij ELKE oefening: originele brontekst die Nederlands van volwassenen is, de volledige hoorbare spreekbeurten, bewijsplaats, vraag, drie natuurlijke en plausibele antwoordopties, precies één goed antwoord, een afzonderlijke en inhoudelijke A2-uitleg bij ieder goed/fout antwoord, audio-inspreekscript per beurt/instructie/vraag/keuze, stem- en beeldbehoefte, unieke ID's, bronreferenties, uitspraak-/grammatica-/spelling-/ERK-check, didactische onderbouwing en negatieve antwoordtests.

Controleer **woordkeus, vloeiendheid, spelling, grammatica, spreektaal, logica, leerdoel, niveau, afleiders, A2-feedback en dubbele thema's** grondig. Maak geen antwoord zichtbaar via contextafbeelding vóór de luisterhandeling. Vergelijk met de eerdere 200 en met relevante bestaande Klink-bronnen om duplicaten te vermijden. Leg alle correcties in een before/after-reviewlog vast.

Sla volledig op in de bestaande Google Drive-map, met leesbare Google Doc/Markdown, machineleesbare JSON, QA en status. **Niet publiceren** en niet beweren dat WAV/MP3 of definitieve ERK-acceptatie bestaat zonder toetsbaar bewijs. Behoud huidige media, oude bestanden, links en voortgang.

Eindig met een korte chatstatus, links en de volgende batch 101-100 (of afrondrapport bij 100).
