# KLINK Luisteren | V0.4 | Alfa A

40 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-AA-understand-001 | Water drinken

**Oefenvorm:** Luister en kies
**Gesproken bron:** Mina drinkt water.
**Vraag:** Wat drinkt Mina?

- **A** Water (goed). Goed. Je hoort: “Mina drinkt water”. Daarom is “Water” het juiste antwoord.
- **B** Melk (fout). Niet goed. Je hoort: “Mina drinkt water”. Daarom past “Melk” niet. Het juiste antwoord is “Water”.
- **C** Thee (fout). Niet goed. Je hoort: “Mina drinkt water”. Daarom past “Thee” niet. Het juiste antwoord is “Water”.

**Bewijs:** Mina drinkt water.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-002 | De rode jas

**Oefenvorm:** Luister en kies
**Gesproken bron:** Ali heeft een rode jas.
**Vraag:** Welke jas heeft Ali?

- **A** De blauwe jas (fout). Niet goed. Je hoort: “Ali heeft een rode jas”. Daarom past “De blauwe jas” niet. Het juiste antwoord is “De rode jas”.
- **B** De groene jas (fout). Niet goed. Je hoort: “Ali heeft een rode jas”. Daarom past “De groene jas” niet. Het juiste antwoord is “De rode jas”.
- **C** De rode jas (goed). Goed. Je hoort: “Ali heeft een rode jas”. Daarom is “De rode jas” het juiste antwoord.

**Bewijs:** Ali heeft een rode jas.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-003 | Een appel

**Oefenvorm:** Luister en kies
**Gesproken bron:** Sara eet een appel.
**Vraag:** Wat eet Sara?

- **A** Een boterham (fout). Niet goed. Je hoort: “Sara eet een appel”. Daarom past “Een boterham” niet. Het juiste antwoord is “Een appel”.
- **B** Een appel (goed). Goed. Je hoort: “Sara eet een appel”. Daarom is “Een appel” het juiste antwoord.
- **C** Een banaan (fout). Niet goed. Je hoort: “Sara eet een appel”. Daarom past “Een banaan” niet. Het juiste antwoord is “Een appel”.

**Bewijs:** Sara eet een appel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-004 | Met de bus

**Oefenvorm:** Luister en kies
**Gesproken bron:** Omar gaat met de bus.
**Vraag:** Hoe reist Omar?

- **A** Met de bus (goed). Goed. Je hoort: “Omar gaat met de bus”. Daarom is “Met de bus” het juiste antwoord.
- **B** Met de fiets (fout). Niet goed. Je hoort: “Omar gaat met de bus”. Daarom past “Met de fiets” niet. Het juiste antwoord is “Met de bus”.
- **C** Met de trein (fout). Niet goed. Je hoort: “Omar gaat met de bus”. Daarom past “Met de trein” niet. Het juiste antwoord is “Met de bus”.

**Bewijs:** Omar gaat met de bus.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-005 | Een boek

**Oefenvorm:** Luister en kies
**Gesproken bron:** Nora leest een boek.
**Vraag:** Wat leest Nora?

- **A** Een krant (fout). Niet goed. Je hoort: “Nora leest een boek”. Daarom past “Een krant” niet. Het juiste antwoord is “Een boek”.
- **B** Een brief (fout). Niet goed. Je hoort: “Nora leest een boek”. Daarom past “Een brief” niet. Het juiste antwoord is “Een boek”.
- **C** Een boek (goed). Goed. Je hoort: “Nora leest een boek”. Daarom is “Een boek” het juiste antwoord.

**Bewijs:** Nora leest een boek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-006 | De deur

**Oefenvorm:** Luister en kies
**Gesproken bron:** Sam doet de deur dicht.
**Vraag:** Wat doet Sam dicht?

- **A** De kast (fout). Niet goed. Je hoort: “Sam doet de deur dicht”. Daarom past “De kast” niet. Het juiste antwoord is “De deur”.
- **B** De deur (goed). Goed. Je hoort: “Sam doet de deur dicht”. Daarom is “De deur” het juiste antwoord.
- **C** Het raam (fout). Niet goed. Je hoort: “Sam doet de deur dicht”. Daarom past “Het raam” niet. Het juiste antwoord is “De deur”.

**Bewijs:** Sam doet de deur dicht.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-007 | Een pen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Elena pakt een pen.
**Vraag:** Wat pakt Elena?

- **A** Een pen (goed). Goed. Je hoort: “Elena pakt een pen”. Daarom is “Een pen” het juiste antwoord.
- **B** Een lepel (fout). Niet goed. Je hoort: “Elena pakt een pen”. Daarom past “Een lepel” niet. Het juiste antwoord is “Een pen”.
- **C** Een sleutel (fout). Niet goed. Je hoort: “Elena pakt een pen”. Daarom past “Een sleutel” niet. Het juiste antwoord is “Een pen”.

**Bewijs:** Elena pakt een pen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-008 | Brood kopen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Youssef koopt brood.
**Vraag:** Wat koopt Youssef?

- **A** Rijst (fout). Niet goed. Je hoort: “Youssef koopt brood”. Daarom past “Rijst” niet. Het juiste antwoord is “Brood”.
- **B** Kaas (fout). Niet goed. Je hoort: “Youssef koopt brood”. Daarom past “Kaas” niet. Het juiste antwoord is “Brood”.
- **C** Brood (goed). Goed. Je hoort: “Youssef koopt brood”. Daarom is “Brood” het juiste antwoord.

**Bewijs:** Youssef koopt brood.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-009 | De sleutel

**Oefenvorm:** Luister en kies
**Gesproken bron:** Lina zoekt haar sleutel.
**Vraag:** Wat zoekt Lina?

- **A** Haar tas (fout). Niet goed. Je hoort: “Lina zoekt haar sleutel”. Daarom past “Haar tas” niet. Het juiste antwoord is “Haar sleutel”.
- **B** Haar sleutel (goed). Goed. Je hoort: “Lina zoekt haar sleutel”. Daarom is “Haar sleutel” het juiste antwoord.
- **C** Haar jas (fout). Niet goed. Je hoort: “Lina zoekt haar sleutel”. Daarom past “Haar jas” niet. Het juiste antwoord is “Haar sleutel”.

**Bewijs:** Lina zoekt haar sleutel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-understand-010 | Een kop thee

**Oefenvorm:** Luister en kies
**Gesproken bron:** Fatima drinkt thee.
**Vraag:** Wat drinkt Fatima?

- **A** Thee (goed). Goed. Je hoort: “Fatima drinkt thee”. Daarom is “Thee” het juiste antwoord.
- **B** Koffie (fout). Niet goed. Je hoort: “Fatima drinkt thee”. Daarom past “Koffie” niet. Het juiste antwoord is “Thee”.
- **C** Water (fout). Niet goed. Je hoort: “Fatima drinkt thee”. Daarom past “Water” niet. Het juiste antwoord is “Thee”.

**Bewijs:** Fatima drinkt thee.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-001 | Water drinken

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Mina heeft dorst. Ze drinkt water.
**Vraag:** Wat drinkt Mina?

- **A** Melk (fout). Niet goed. Je hoort: “Ze drinkt water”. Daarom past “Melk” niet. Het juiste antwoord is “Water”.
- **B** Thee (fout). Niet goed. Je hoort: “Ze drinkt water”. Daarom past “Thee” niet. Het juiste antwoord is “Water”.
- **C** Water (goed). Goed. Je hoort: “Ze drinkt water”. Daarom is “Water” het juiste antwoord.

**Bewijs:** Ze drinkt water.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-002 | De rode jas

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Ali gaat naar buiten. Hij trekt zijn rode jas aan.
**Vraag:** Welke jas heeft Ali?

- **A** De groene jas (fout). Niet goed. Je hoort: “Hij trekt zijn rode jas aan”. Daarom past “De groene jas” niet. Het juiste antwoord is “De rode jas”.
- **B** De rode jas (goed). Goed. Je hoort: “Hij trekt zijn rode jas aan”. Daarom is “De rode jas” het juiste antwoord.
- **C** De blauwe jas (fout). Niet goed. Je hoort: “Hij trekt zijn rode jas aan”. Daarom past “De blauwe jas” niet. Het juiste antwoord is “De rode jas”.

**Bewijs:** Hij trekt zijn rode jas aan.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-003 | Een appel

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Sara zit aan tafel. Ze eet een appel.
**Vraag:** Wat eet Sara?

- **A** Een appel (goed). Goed. Je hoort: “Ze eet een appel”. Daarom is “Een appel” het juiste antwoord.
- **B** Een banaan (fout). Niet goed. Je hoort: “Ze eet een appel”. Daarom past “Een banaan” niet. Het juiste antwoord is “Een appel”.
- **C** Een boterham (fout). Niet goed. Je hoort: “Ze eet een appel”. Daarom past “Een boterham” niet. Het juiste antwoord is “Een appel”.

**Bewijs:** Ze eet een appel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-004 | Met de bus

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Omar staat bij de halte. Hij gaat met de bus.
**Vraag:** Hoe reist Omar?

- **A** Met de fiets (fout). Niet goed. Je hoort: “Hij gaat met de bus”. Daarom past “Met de fiets” niet. Het juiste antwoord is “Met de bus”.
- **B** Met de trein (fout). Niet goed. Je hoort: “Hij gaat met de bus”. Daarom past “Met de trein” niet. Het juiste antwoord is “Met de bus”.
- **C** Met de bus (goed). Goed. Je hoort: “Hij gaat met de bus”. Daarom is “Met de bus” het juiste antwoord.

**Bewijs:** Hij gaat met de bus.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-005 | Een boek

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Nora zit op de bank. Ze leest een boek.
**Vraag:** Wat leest Nora?

- **A** Een brief (fout). Niet goed. Je hoort: “Ze leest een boek”. Daarom past “Een brief” niet. Het juiste antwoord is “Een boek”.
- **B** Een boek (goed). Goed. Je hoort: “Ze leest een boek”. Daarom is “Een boek” het juiste antwoord.
- **C** Een krant (fout). Niet goed. Je hoort: “Ze leest een boek”. Daarom past “Een krant” niet. Het juiste antwoord is “Een boek”.

**Bewijs:** Ze leest een boek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-006 | De deur

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Het is koud. Sam doet de deur dicht.
**Vraag:** Wat doet Sam dicht?

- **A** De deur (goed). Goed. Je hoort: “Sam doet de deur dicht”. Daarom is “De deur” het juiste antwoord.
- **B** Het raam (fout). Niet goed. Je hoort: “Sam doet de deur dicht”. Daarom past “Het raam” niet. Het juiste antwoord is “De deur”.
- **C** De kast (fout). Niet goed. Je hoort: “Sam doet de deur dicht”. Daarom past “De kast” niet. Het juiste antwoord is “De deur”.

**Bewijs:** Sam doet de deur dicht.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-007 | Een pen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Elena wil schrijven. Ze pakt een pen.
**Vraag:** Wat pakt Elena?

- **A** Een lepel (fout). Niet goed. Je hoort: “Ze pakt een pen”. Daarom past “Een lepel” niet. Het juiste antwoord is “Een pen”.
- **B** Een sleutel (fout). Niet goed. Je hoort: “Ze pakt een pen”. Daarom past “Een sleutel” niet. Het juiste antwoord is “Een pen”.
- **C** Een pen (goed). Goed. Je hoort: “Ze pakt een pen”. Daarom is “Een pen” het juiste antwoord.

**Bewijs:** Ze pakt een pen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-008 | Brood kopen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Youssef gaat naar de bakker. Hij koopt brood.
**Vraag:** Wat koopt Youssef?

- **A** Kaas (fout). Niet goed. Je hoort: “Hij koopt brood”. Daarom past “Kaas” niet. Het juiste antwoord is “Brood”.
- **B** Brood (goed). Goed. Je hoort: “Hij koopt brood”. Daarom is “Brood” het juiste antwoord.
- **C** Rijst (fout). Niet goed. Je hoort: “Hij koopt brood”. Daarom past “Rijst” niet. Het juiste antwoord is “Brood”.

**Bewijs:** Hij koopt brood.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-009 | De sleutel

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Lina wil naar binnen. Ze zoekt haar sleutel.
**Vraag:** Wat zoekt Lina?

- **A** Haar sleutel (goed). Goed. Je hoort: “Ze zoekt haar sleutel”. Daarom is “Haar sleutel” het juiste antwoord.
- **B** Haar jas (fout). Niet goed. Je hoort: “Ze zoekt haar sleutel”. Daarom past “Haar jas” niet. Het juiste antwoord is “Haar sleutel”.
- **C** Haar tas (fout). Niet goed. Je hoort: “Ze zoekt haar sleutel”. Daarom past “Haar tas” niet. Het juiste antwoord is “Haar sleutel”.

**Bewijs:** Ze zoekt haar sleutel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-text-question-010 | Een kop thee

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Fatima is thuis. Ze drinkt een kop thee.
**Vraag:** Wat drinkt Fatima?

- **A** Koffie (fout). Niet goed. Je hoort: “Ze drinkt een kop thee”. Daarom past “Koffie” niet. Het juiste antwoord is “Thee”.
- **B** Water (fout). Niet goed. Je hoort: “Ze drinkt een kop thee”. Daarom past “Water” niet. Het juiste antwoord is “Thee”.
- **C** Thee (goed). Goed. Je hoort: “Ze drinkt een kop thee”. Daarom is “Thee” het juiste antwoord.

**Bewijs:** Ze drinkt een kop thee.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-001 | Water drinken

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Wil je water?
Mina: Ja, graag.
**Vraag:** Wat wil Mina drinken?

- **A** Thee (fout). Niet goed. Je hoort: “Wil je water”. Daarom past “Thee” niet. Het juiste antwoord is “Water”.
- **B** Water (goed). Goed. Je hoort: “Wil je water”. Daarom is “Water” het juiste antwoord.
- **C** Melk (fout). Niet goed. Je hoort: “Wil je water”. Daarom past “Melk” niet. Het juiste antwoord is “Water”.

**Bewijs:** Wil je water?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-002 | De rode jas

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Is dat jouw rode jas?
Ali: Ja, dat is mijn jas.
**Vraag:** Welke jas heeft Ali?

- **A** De rode jas (goed). Goed. Je hoort: “Is dat jouw rode jas”. Daarom is “De rode jas” het juiste antwoord.
- **B** De blauwe jas (fout). Niet goed. Je hoort: “Is dat jouw rode jas”. Daarom past “De blauwe jas” niet. Het juiste antwoord is “De rode jas”.
- **C** De groene jas (fout). Niet goed. Je hoort: “Is dat jouw rode jas”. Daarom past “De groene jas” niet. Het juiste antwoord is “De rode jas”.

**Bewijs:** Is dat jouw rode jas?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-003 | Een appel

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Wat eet je?
Sara: Een appel.
**Vraag:** Wat eet Sara?

- **A** Een banaan (fout). Niet goed. Je hoort: “Een appel”. Daarom past “Een banaan” niet. Het juiste antwoord is “Een appel”.
- **B** Een boterham (fout). Niet goed. Je hoort: “Een appel”. Daarom past “Een boterham” niet. Het juiste antwoord is “Een appel”.
- **C** Een appel (goed). Goed. Je hoort: “Een appel”. Daarom is “Een appel” het juiste antwoord.

**Bewijs:** Een appel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-004 | Met de bus

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Ga je met de bus?
Omar: Ja, ik neem de bus.
**Vraag:** Hoe reist Omar?

- **A** Met de trein (fout). Niet goed. Je hoort: “Ga je met de bus”. Daarom past “Met de trein” niet. Het juiste antwoord is “Met de bus”.
- **B** Met de bus (goed). Goed. Je hoort: “Ga je met de bus”. Daarom is “Met de bus” het juiste antwoord.
- **C** Met de fiets (fout). Niet goed. Je hoort: “Ga je met de bus”. Daarom past “Met de fiets” niet. Het juiste antwoord is “Met de bus”.

**Bewijs:** Ga je met de bus?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-005 | Een boek

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Wat lees je?
Nora: Een boek.
**Vraag:** Wat leest Nora?

- **A** Een boek (goed). Goed. Je hoort: “Een boek”. Daarom is “Een boek” het juiste antwoord.
- **B** Een krant (fout). Niet goed. Je hoort: “Een boek”. Daarom past “Een krant” niet. Het juiste antwoord is “Een boek”.
- **C** Een brief (fout). Niet goed. Je hoort: “Een boek”. Daarom past “Een brief” niet. Het juiste antwoord is “Een boek”.

**Bewijs:** Een boek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-006 | De deur

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Doe je de deur dicht?
Sam: Ja, ik doe hem dicht.
**Vraag:** Wat doet Sam dicht?

- **A** Het raam (fout). Niet goed. Je hoort: “Doe je de deur dicht”. Daarom past “Het raam” niet. Het juiste antwoord is “De deur”.
- **B** De kast (fout). Niet goed. Je hoort: “Doe je de deur dicht”. Daarom past “De kast” niet. Het juiste antwoord is “De deur”.
- **C** De deur (goed). Goed. Je hoort: “Doe je de deur dicht”. Daarom is “De deur” het juiste antwoord.

**Bewijs:** Doe je de deur dicht?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-007 | Een pen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Pak je een pen?
Elena: Ja, ik pak een pen.
**Vraag:** Wat pakt Elena?

- **A** Een sleutel (fout). Niet goed. Je hoort: “Pak je een pen”. Daarom past “Een sleutel” niet. Het juiste antwoord is “Een pen”.
- **B** Een pen (goed). Goed. Je hoort: “Pak je een pen”. Daarom is “Een pen” het juiste antwoord.
- **C** Een lepel (fout). Niet goed. Je hoort: “Pak je een pen”. Daarom past “Een lepel” niet. Het juiste antwoord is “Een pen”.

**Bewijs:** Pak je een pen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-008 | Brood kopen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Bakker: Wat wil je?
Youssef: Een brood, graag.
**Vraag:** Wat wil Youssef kopen?

- **A** Brood (goed). Goed. Je hoort: “Een brood, graag”. Daarom is “Brood” het juiste antwoord.
- **B** Rijst (fout). Niet goed. Je hoort: “Een brood, graag”. Daarom past “Rijst” niet. Het juiste antwoord is “Brood”.
- **C** Kaas (fout). Niet goed. Je hoort: “Een brood, graag”. Daarom past “Kaas” niet. Het juiste antwoord is “Brood”.

**Bewijs:** Een brood, graag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-009 | De sleutel

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Wat zoek je?
Lina: Mijn sleutel.
**Vraag:** Wat zoekt Lina?

- **A** Haar jas (fout). Niet goed. Je hoort: “Mijn sleutel”. Daarom past “Haar jas” niet. Het juiste antwoord is “Haar sleutel”.
- **B** Haar tas (fout). Niet goed. Je hoort: “Mijn sleutel”. Daarom past “Haar tas” niet. Het juiste antwoord is “Haar sleutel”.
- **C** Haar sleutel (goed). Goed. Je hoort: “Mijn sleutel”. Daarom is “Haar sleutel” het juiste antwoord.

**Bewijs:** Mijn sleutel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-dialogue-question-010 | Een kop thee

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Wat wil je drinken?
Fatima: Thee, graag.
**Vraag:** Wat wil Fatima drinken?

- **A** Water (fout). Niet goed. Je hoort: “Thee, graag”. Daarom past “Water” niet. Het juiste antwoord is “Thee”.
- **B** Thee (goed). Goed. Je hoort: “Thee, graag”. Daarom is “Thee” het juiste antwoord.
- **C** Koffie (fout). Niet goed. Je hoort: “Thee, graag”. Daarom past “Koffie” niet. Het juiste antwoord is “Thee”.

**Bewijs:** Thee, graag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-001 | Water drinken

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Wil je water?
**Vraag:** Wat is een passende reactie?

- **A** Ja, graag. (goed). Goed. Je hoort: “Wil je water?” Met “Ja, graag” geef je een passend antwoord.
- **B** Ik heet Mina. (fout). Niet goed. Je hoort: “Wil je water?” “Ik heet Mina” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.
- **C** Tot morgen. (fout). Niet goed. Je hoort: “Wil je water?” “Tot morgen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.

**Bewijs:** Wil je water?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-002 | De rode jas

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Is dit jouw jas?
**Vraag:** Wat is een passende reactie?

- **A** Ik wil koffie. (fout). Niet goed. Je hoort: “Is dit jouw jas?” “Ik wil koffie” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat is mijn jas”.
- **B** Ik ga slapen. (fout). Niet goed. Je hoort: “Is dit jouw jas?” “Ik ga slapen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat is mijn jas”.
- **C** Ja, dat is mijn jas. (goed). Goed. Je hoort: “Is dit jouw jas?” Met “Ja, dat is mijn jas” geef je een passend antwoord.

**Bewijs:** Is dit jouw jas?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-003 | Een appel

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Wil je een appel?
**Vraag:** Wat is een passende reactie?

- **A** Het is maandag. (fout). Niet goed. Je hoort: “Wil je een appel?” “Het is maandag” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.
- **B** Ja, graag. (goed). Goed. Je hoort: “Wil je een appel?” Met “Ja, graag” geef je een passend antwoord.
- **C** Ik woon hier. (fout). Niet goed. Je hoort: “Wil je een appel?” “Ik woon hier” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.

**Bewijs:** Wil je een appel?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-004 | Met de bus

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Is dit bus zeven?
**Vraag:** Wat is een passende reactie?

- **A** Ja, dit is bus zeven. (goed). Goed. Je hoort: “Is dit bus zeven?” Met “Ja, dit is bus zeven” geef je een passend antwoord.
- **B** Ik heb een pen. (fout). Niet goed. Je hoort: “Is dit bus zeven?” “Ik heb een pen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dit is bus zeven”.
- **C** Ik ga eten. (fout). Niet goed. Je hoort: “Is dit bus zeven?” “Ik ga eten” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dit is bus zeven”.

**Bewijs:** Is dit bus zeven?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-005 | Een boek

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Mag ik je boek zien?
**Vraag:** Wat is een passende reactie?

- **A** Ik heb dorst. (fout). Niet goed. Je hoort: “Mag ik je boek zien?” “Ik heb dorst” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, natuurlijk”.
- **B** Mijn jas is nat. (fout). Niet goed. Je hoort: “Mag ik je boek zien?” “Mijn jas is nat” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, natuurlijk”.
- **C** Ja, natuurlijk. (goed). Goed. Je hoort: “Mag ik je boek zien?” Met “Ja, natuurlijk” geef je een passend antwoord.

**Bewijs:** Mag ik je boek zien?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-006 | De deur

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Doe je de deur dicht?
**Vraag:** Wat is een passende reactie?

- **A** Ik ga met de trein. (fout). Niet goed. Je hoort: “Doe je de deur dicht?” “Ik ga met de trein” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik doe hem dicht”.
- **B** Ja, ik doe hem dicht. (goed). Goed. Je hoort: “Doe je de deur dicht?” Met “Ja, ik doe hem dicht” geef je een passend antwoord.
- **C** Ik wil twee appels. (fout). Niet goed. Je hoort: “Doe je de deur dicht?” “Ik wil twee appels” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik doe hem dicht”.

**Bewijs:** Doe je de deur dicht?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-007 | Een pen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Mag ik jouw pen even?
**Vraag:** Wat is een passende reactie?

- **A** Ja, alsjeblieft. (goed). Goed. Je hoort: “Mag ik jouw pen even?” Met “Ja, alsjeblieft” geef je een passend antwoord.
- **B** Ik woon in de stad. (fout). Niet goed. Je hoort: “Mag ik jouw pen even?” “Ik woon in de stad” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, alsjeblieft”.
- **C** De bus komt. (fout). Niet goed. Je hoort: “Mag ik jouw pen even?” “De bus komt” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, alsjeblieft”.

**Bewijs:** Mag ik jouw pen even?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-008 | Brood kopen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Bakker: Wat wil je kopen?
**Vraag:** Wat is een passende reactie?

- **A** Ik heb een fiets. (fout). Niet goed. Je hoort: “Wat wil je kopen?” “Ik heb een fiets” past niet bij deze vraag of opdracht. Een passende reactie is: “Een brood, graag”.
- **B** Tot zaterdag. (fout). Niet goed. Je hoort: “Wat wil je kopen?” “Tot zaterdag” past niet bij deze vraag of opdracht. Een passende reactie is: “Een brood, graag”.
- **C** Een brood, graag. (goed). Goed. Je hoort: “Wat wil je kopen?” Met “Een brood, graag” geef je een passend antwoord.

**Bewijs:** Wat wil je kopen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-009 | De sleutel

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Is dit jouw sleutel?
**Vraag:** Wat is een passende reactie?

- **A** Ik ben met de bus. (fout). Niet goed. Je hoort: “Is dit jouw sleutel?” “Ik ben met de bus” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dank je wel”.
- **B** Ja, dank je wel. (goed). Goed. Je hoort: “Is dit jouw sleutel?” Met “Ja, dank je wel” geef je een passend antwoord.
- **C** Ik eet soep. (fout). Niet goed. Je hoort: “Is dit jouw sleutel?” “Ik eet soep” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dank je wel”.

**Bewijs:** Is dit jouw sleutel?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AA-suitable-reply-010 | Een kop thee

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Wil je thee?
**Vraag:** Wat is een passende reactie?

- **A** Ja, graag. (goed). Goed. Je hoort: “Wil je thee?” Met “Ja, graag” geef je een passend antwoord.
- **B** Ik ga naar school. (fout). Niet goed. Je hoort: “Wil je thee?” “Ik ga naar school” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.
- **C** Mijn boek is rood. (fout). Niet goed. Je hoort: “Wil je thee?” “Mijn boek is rood” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag”.

**Bewijs:** Wil je thee?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
