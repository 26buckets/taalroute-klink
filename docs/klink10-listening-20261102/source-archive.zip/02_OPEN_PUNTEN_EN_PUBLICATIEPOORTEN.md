# KLINK LUISTEREN. WAT STAAT NOG OPEN? BESLISREGISTER

Status 2 november 2026. Geen bewering dat de bestaande Klink-liveversie inmiddels is gewijzigd.

## Inhoud, didactiek, niveau
- De 200 inhoudelijke kandidaten hebben een AI-redactiecontrole. Controleer het geheel onafhankelijk met NT2-docent/taalexpert, inclusief 600 A2-feedbackverklaringen, de beklemtoning, spreektaal en begrijpelijkheid.
- Extra aandacht bij B1: echte meerledige boodschappen, intentie, reden, contrast, voorwaarden, vervolgacties; niet elk item alleen één feit. Bij Alfa A/B voorkom schijn-luisteren door verborgen schriftelijke vraag/opties. Bij Alfa C beoordelingsas alfabetisering loshouden van mondeling ERK.
- Dedupe exact tegen alle relevante Drive- en repo-bronnen, content uit Zinnen, In de praktijk, Spreken, Teksten en eerdere luisterbatches. Cross-form scenario is toegestaan mits andere gemeten vaardigheid; niet meetellen als unieke context.

## Audio en beeld
- Opname en goedkeuring van brontekst, instructies, vragen, antwoordopties; speakerbeurtbestanden registreren met vaste voice-ID en werkelijke audiopaden. 1.330 script-/luisterposities in v0.3 is geen aantal bestaande audiobestanden.
- Volledige afspeelcontrole door een mens: verstaanbaarheid, natuurlijk tempo, uitspraak, prosodie, klemtoon, minimale stilte, volume en overeenstemming met definitief transcript.
- Alfa A/B: maak of hergebruik betekenisvolle afbeeldingen voor keuzes; zorg dat de contextfoto het juiste antwoord niet vooraf prijsgeeft.

## Techniek en app
- Behoud het Klink-ontwerp categorie → oefenvorm → lijst → opdracht voor alle niveaus; geen menu- of voortgangsmigratie zonder regressie.
- Zorg voor eigen stabiele oefen-ID en eigen voltooide-resultaatsleutel voor hergebruikte audio. Behoud bron-ID en alle oorspronkelijke audiobestanden en scores.
- Test daadwerkelijk op desktop en mobiel: audioafspeelknop, herhalen, pauzeren, beurtwisseling, antwoordfeedback na inzenden, opnieuw oefenen, toetsenbord/schermlezer, geen dubbele geluidsweergave, netwerkfouten, herladen, oude voortgang, analytics.
- Repository: 26buckets/taalroute-klink. Verbonden toegang was eerder pull=true/push=false; hier is geen push, merge of deploy uitgevoerd. Controleer actuele rechten/branch bij publicatie.

## Schalen naar 100
- Maak per open cel eerst ronde 02 (011-020), dan rondes 03-10 in batches van tien. Gebruik bij elke batch één afgebakend thema, nieuwe contexten en review; houd 100 als minimum en pas extra aan wanneer didactisch nodig.
- Voor 20 open cellen: resterend 1.800 *nieuwe inhoudelijke* kandidaten, minus eventueel later bewezen exact passende al bestaande niet meegetelde opdrachten. Bronverificatie kan dus besparingen opleveren; niet kunstmatig nieuw schrijven.
- Tel andere reeds gevulde 10 cellen apart en bepaal hun echte resterende aantal tot 100. Tel niet dezelfde opgave dubbel wanneer een item op meerdere schermen staat.

## Exacte vrijgavestatus
CONTENT: AI-geredigeerde kandidaat. MEDIA: ontbreekt of niet afspeelbaar geverifieerd. NIVEAU: onafhankelijke toets open. DUPLICATEN: volledig Drive-breed onderzoek open. RUNTIME: niet getest. LIVE: niet gepubliceerd. Geen automatische opdracht om te deployen.
