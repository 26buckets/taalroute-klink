# KLINK Luisteren | V0.4 | A1

20 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-A1-understand-001 | De afspraak verzetten

**Oefenvorm:** Luister en kies
**Gesproken bron:** De afspraak is niet dinsdag, maar donderdag om tien uur.
**Vraag:** Wanneer is de afspraak?

- **A** Donderdag om tien uur (goed). Goed. Je hoort: “De afspraak is niet dinsdag, maar donderdag om tien uur”. Daarom is “Donderdag om tien uur” het juiste antwoord.
- **B** Dinsdag om tien uur (fout). Niet goed. Je hoort: “De afspraak is niet dinsdag, maar donderdag om tien uur”. Daarom past “Dinsdag om tien uur” niet. Het juiste antwoord is “Donderdag om tien uur”.
- **C** Donderdag om twaalf uur (fout). Niet goed. Je hoort: “De afspraak is niet dinsdag, maar donderdag om tien uur”. Daarom past “Donderdag om twaalf uur” niet. Het juiste antwoord is “Donderdag om tien uur”.

**Bewijs:** De afspraak is niet dinsdag, maar donderdag om tien uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-002 | De trein nemen

**Oefenvorm:** Luister en kies
**Gesproken bron:** De trein naar Leiden vertrekt van spoor vier.
**Vraag:** Van welk spoor vertrekt de trein?

- **A** Spoor twee (fout). Niet goed. Je hoort: “De trein naar Leiden vertrekt van spoor vier”. Daarom past “Spoor twee” niet. Het juiste antwoord is “Spoor vier”.
- **B** Spoor zes (fout). Niet goed. Je hoort: “De trein naar Leiden vertrekt van spoor vier”. Daarom past “Spoor zes” niet. Het juiste antwoord is “Spoor vier”.
- **C** Spoor vier (goed). Goed. Je hoort: “De trein naar Leiden vertrekt van spoor vier”. Daarom is “Spoor vier” het juiste antwoord.

**Bewijs:** De trein naar Leiden vertrekt van spoor vier.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-003 | Het huiswerk

**Oefenvorm:** Luister en kies
**Gesproken bron:** Neem morgen je schrift en je huiswerk mee naar de les.
**Vraag:** Wat moet je meenemen?

- **A** Je fiets en je jas (fout). Niet goed. Je hoort: “Neem morgen je schrift en je huiswerk mee naar de les”. Daarom past “Je fiets en je jas” niet. Het juiste antwoord is “Je schrift en je huiswerk”.
- **B** Je schrift en je huiswerk (goed). Goed. Je hoort: “Neem morgen je schrift en je huiswerk mee naar de les”. Daarom is “Je schrift en je huiswerk” het juiste antwoord.
- **C** Alleen je tas (fout). Niet goed. Je hoort: “Neem morgen je schrift en je huiswerk mee naar de les”. Daarom past “Alleen je tas” niet. Het juiste antwoord is “Je schrift en je huiswerk”.

**Bewijs:** Neem morgen je schrift en je huiswerk mee naar de les.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-004 | De broodbestelling

**Oefenvorm:** Luister en kies
**Gesproken bron:** Ik wil graag twee bruine broden en één wit brood.
**Vraag:** Wat bestelt de klant?

- **A** Twee bruine en één wit brood (goed). Goed. Je hoort: “Ik wil graag twee bruine broden en één wit brood”. Daarom is “Twee bruine en één wit brood” het juiste antwoord.
- **B** Twee witte en één bruin brood (fout). Niet goed. Je hoort: “Ik wil graag twee bruine broden en één wit brood”. Daarom past “Twee witte en één bruin brood” niet. Het juiste antwoord is “Twee bruine en één wit brood”.
- **C** Drie bruine broden (fout). Niet goed. Je hoort: “Ik wil graag twee bruine broden en één wit brood”. Daarom past “Drie bruine broden” niet. Het juiste antwoord is “Twee bruine en één wit brood”.

**Bewijs:** Ik wil graag twee bruine broden en één wit brood.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-005 | De huisarts

**Oefenvorm:** Luister en kies
**Gesproken bron:** De huisarts belt je vrijdagmiddag terug.
**Vraag:** Wanneer belt de huisarts terug?

- **A** Donderdagmiddag (fout). Niet goed. Je hoort: “De huisarts belt je vrijdagmiddag terug”. Daarom past “Donderdagmiddag” niet. Het juiste antwoord is “Vrijdagmiddag”.
- **B** Vrijdagochtend (fout). Niet goed. Je hoort: “De huisarts belt je vrijdagmiddag terug”. Daarom past “Vrijdagochtend” niet. Het juiste antwoord is “Vrijdagmiddag”.
- **C** Vrijdagmiddag (goed). Goed. Je hoort: “De huisarts belt je vrijdagmiddag terug”. Daarom is “Vrijdagmiddag” het juiste antwoord.

**Bewijs:** De huisarts belt je vrijdagmiddag terug.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-006 | De bibliotheek

**Oefenvorm:** Luister en kies
**Gesproken bron:** Op maandag is de bibliotheek tot zes uur open.
**Vraag:** Tot hoe laat is de bibliotheek maandag open?

- **A** Tot acht uur (fout). Niet goed. Je hoort: “Op maandag is de bibliotheek tot zes uur open”. Daarom past “Tot acht uur” niet. Het juiste antwoord is “Tot zes uur”.
- **B** Tot zes uur (goed). Goed. Je hoort: “Op maandag is de bibliotheek tot zes uur open”. Daarom is “Tot zes uur” het juiste antwoord.
- **C** Tot vijf uur (fout). Niet goed. Je hoort: “Op maandag is de bibliotheek tot zes uur open”. Daarom past “Tot vijf uur” niet. Het juiste antwoord is “Tot zes uur”.

**Bewijs:** Op maandag is de bibliotheek tot zes uur open.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-007 | Het werkrooster

**Oefenvorm:** Luister en kies
**Gesproken bron:** Deze week werk ik woensdag, donderdag en vrijdag.
**Vraag:** Op welke dagen werkt de spreker?

- **A** Woensdag, donderdag en vrijdag (goed). Goed. Je hoort: “Deze week werk ik woensdag, donderdag en vrijdag”. Daarom is “Woensdag, donderdag en vrijdag” het juiste antwoord.
- **B** Maandag, dinsdag en woensdag (fout). Niet goed. Je hoort: “Deze week werk ik woensdag, donderdag en vrijdag”. Daarom past “Maandag, dinsdag en woensdag” niet. Het juiste antwoord is “Woensdag, donderdag en vrijdag”.
- **C** Dinsdag, donderdag en zaterdag (fout). Niet goed. Je hoort: “Deze week werk ik woensdag, donderdag en vrijdag”. Daarom past “Dinsdag, donderdag en zaterdag” niet. Het juiste antwoord is “Woensdag, donderdag en vrijdag”.

**Bewijs:** Deze week werk ik woensdag, donderdag en vrijdag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-008 | Fietsen repareren

**Oefenvorm:** Luister en kies
**Gesproken bron:** Mijn fiets is morgen klaar. Ik kan hem na drie uur ophalen.
**Vraag:** Wanneer kan de fiets worden opgehaald?

- **A** Vandaag na drie uur (fout). Niet goed. Je hoort: “Mijn fiets is morgen klaar”. Daarom past “Vandaag na drie uur” niet. Het juiste antwoord is “Morgen na drie uur”.
- **B** Morgen voor twaalf uur (fout). Niet goed. Je hoort: “Mijn fiets is morgen klaar”. Daarom past “Morgen voor twaalf uur” niet. Het juiste antwoord is “Morgen na drie uur”.
- **C** Morgen na drie uur (goed). Goed. Je hoort: “Mijn fiets is morgen klaar”. Daarom is “Morgen na drie uur” het juiste antwoord.

**Bewijs:** Mijn fiets is morgen klaar.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-009 | De cursus

**Oefenvorm:** Luister en kies
**Gesproken bron:** De Nederlandse les begint om half negen in lokaal twaalf.
**Vraag:** Waar is de les?

- **A** In de bibliotheek (fout). Niet goed. Je hoort: “De Nederlandse les begint om half negen in lokaal twaalf”. Daarom past “In de bibliotheek” niet. Het juiste antwoord is “In lokaal twaalf”.
- **B** In lokaal twaalf (goed). Goed. Je hoort: “De Nederlandse les begint om half negen in lokaal twaalf”. Daarom is “In lokaal twaalf” het juiste antwoord.
- **C** In lokaal tien (fout). Niet goed. Je hoort: “De Nederlandse les begint om half negen in lokaal twaalf”. Daarom past “In lokaal tien” niet. Het juiste antwoord is “In lokaal twaalf”.

**Bewijs:** De Nederlandse les begint om half negen in lokaal twaalf.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-understand-010 | Het pakket

**Oefenvorm:** Luister en kies
**Gesproken bron:** Je pakket ligt bij de buren op nummer achttien.
**Vraag:** Waar ligt het pakket?

- **A** Bij de buren op nummer achttien (goed). Goed. Je hoort: “Je pakket ligt bij de buren op nummer achttien”. Daarom is “Bij de buren op nummer achttien” het juiste antwoord.
- **B** In de winkel op nummer acht (fout). Niet goed. Je hoort: “Je pakket ligt bij de buren op nummer achttien”. Daarom past “In de winkel op nummer acht” niet. Het juiste antwoord is “Bij de buren op nummer achttien”.
- **C** Op school bij de receptie (fout). Niet goed. Je hoort: “Je pakket ligt bij de buren op nummer achttien”. Daarom past “Op school bij de receptie” niet. Het juiste antwoord is “Bij de buren op nummer achttien”.

**Bewijs:** Je pakket ligt bij de buren op nummer achttien.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-001 | Een boek lenen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Mag ik jouw boek lenen?
Elena: Ja, dat mag.
Nora: Wanneer wil je het terug?
Elena: Morgen na de les.
**Vraag:** Wanneer wil Elena het boek terug?

- **A** Morgen na de les. (goed). Goed. Je hoort: “Morgen na de les”. Daarom is “Morgen na de les” het juiste antwoord.
- **B** Vanavond voor het eten. (fout). Niet goed. Je hoort: “Morgen na de les”. Daarom past “Vanavond voor het eten” niet. Het juiste antwoord is “Morgen na de les”.
- **C** Volgende week. (fout). Niet goed. Je hoort: “Morgen na de les”. Daarom past “Volgende week” niet. Het juiste antwoord is “Morgen na de les”.

**Bewijs:** Morgen na de les.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-002 | Samen aan tafel

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Youssef: Wil je een kom soep?
Nora: Ja, graag.
Youssef: Wil je er brood met kaas bij?
Nora: Nee, alleen soep, dank je.
**Vraag:** Wat wil Nora eten?

- **A** Soep en een koek. (fout). Niet goed. Je hoort: “Nee, alleen soep, dank je”. Daarom past “Soep en een koek” niet. Het juiste antwoord is “Alleen soep”.
- **B** Alleen soep. (goed). Goed. Je hoort: “Nee, alleen soep, dank je”. Daarom is “Alleen soep” het juiste antwoord.
- **C** Alleen brood met kaas. (fout). Niet goed. Je hoort: “Nee, alleen soep, dank je”. Daarom past “Alleen brood met kaas” niet. Het juiste antwoord is “Alleen soep”.

**Bewijs:** Nee, alleen soep, dank je.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-003 | Kennismaken

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Elena: Hallo, wat is jouw naam?
Youssef: Mijn naam is Youssef. En jij?
Elena: Ik ben Elena. Is deze stoel vrij?
Youssef: Ja, kom maar naast mij zitten.
**Vraag:** Waar kan Elena zitten?

- **A** Op een stoel bij het raam. (fout). Niet goed. Je hoort: “Mijn naam is Youssef”. Daarom past “Op een stoel bij het raam” niet. Het juiste antwoord is “Naast Youssef”.
- **B** Naast Youssef. (goed). Goed. Je hoort: “Mijn naam is Youssef”. Daarom is “Naast Youssef” het juiste antwoord.
- **C** Bij de docent. (fout). Niet goed. Je hoort: “Mijn naam is Youssef”. Daarom past “Bij de docent” niet. Het juiste antwoord is “Naast Youssef”.

**Bewijs:** Mijn naam is Youssef.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-004 | Een laars zoeken

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Ik zie maar één laars. Waar is de andere?
Youssef: Kijk eens onder de stoel.
Nora: Ja, daar staat hij. Dank je.
Youssef: Graag gedaan.
**Vraag:** Waar staat de andere laars?

- **A** Onder de stoel. (goed). Goed. Je hoort: “Kijk eens onder de stoel”. Daarom is “Onder de stoel” het juiste antwoord.
- **B** Aan de haak. (fout). Niet goed. Je hoort: “Kijk eens onder de stoel”. Daarom past “Aan de haak” niet. Het juiste antwoord is “Onder de stoel”.
- **C** Op tafel. (fout). Niet goed. Je hoort: “Kijk eens onder de stoel”. Daarom past “Op tafel” niet. Het juiste antwoord is “Onder de stoel”.

**Bewijs:** Kijk eens onder de stoel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-005 | Thee drinken

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Lotte: Wil je thee?
Rachid: Ja, graag. Een kleine kop.
Lotte: Met suiker?
Rachid: Nee, zonder suiker, dank je.
**Vraag:** Welke kop wil Rachid?

- **A** Geen kop. (fout). Niet goed. Je hoort: “Een kleine kop”. Daarom past “Geen kop” niet. Het juiste antwoord is “Een kleine kop”.
- **B** Een kleine kop. (goed). Goed. Je hoort: “Een kleine kop”. Daarom is “Een kleine kop” het juiste antwoord.
- **C** Een grote kop. (fout). Niet goed. Je hoort: “Een kleine kop”. Daarom past “Een grote kop” niet. Het juiste antwoord is “Een kleine kop”.

**Bewijs:** Een kleine kop.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-006 | Een bon vragen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Lotte: Ik neem deze rok.
Medewerker: Dat is goed.
Lotte: Mag ik de bon erbij?
Medewerker: Natuurlijk. Hier is de bon.
**Vraag:** Wat vraagt Lotte bij de rok?

- **A** De bon. (goed). Goed. Je hoort: “Natuurlijk”. Daarom is “De bon” het juiste antwoord.
- **B** Een tasje. (fout). Niet goed. Je hoort: “Natuurlijk”. Daarom past “Een tasje” niet. Het juiste antwoord is “De bon”.
- **C** Een prijskaartje. (fout). Niet goed. Je hoort: “Natuurlijk”. Daarom past “Een prijskaartje” niet. Het juiste antwoord is “De bon”.

**Bewijs:** Natuurlijk.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-007 | Bij de buur

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Minh: Kom je deze week langs?
Lotte: Ja. Is dinsdag goed?
Minh: Ja, om acht uur?
Lotte: Goed, tot dinsdag om acht uur.
**Vraag:** Wanneer spreken ze af?

- **A** Dinsdag om acht uur. (goed). Goed. Je hoort: “Goed, tot dinsdag om acht uur”. Daarom is “Dinsdag om acht uur” het juiste antwoord.
- **B** Donderdag om acht uur. (fout). Niet goed. Je hoort: “Goed, tot dinsdag om acht uur”. Daarom past “Donderdag om acht uur” niet. Het juiste antwoord is “Dinsdag om acht uur”.
- **C** Dinsdag om zes uur. (fout). Niet goed. Je hoort: “Goed, tot dinsdag om acht uur”. Daarom past “Dinsdag om zes uur” niet. Het juiste antwoord is “Dinsdag om acht uur”.

**Bewijs:** Goed, tot dinsdag om acht uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-008 | De juiste bus

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Abel: Gaat deze bus naar het station?
Chauffeur: Ja, stap maar in.
Abel: Dank u wel.
Chauffeur: Graag gedaan.
**Vraag:** Waar gaat de bus naartoe?

- **A** Naar de markt. (fout). Niet goed. Je hoort: “Gaat deze bus naar het station”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar het station”.
- **B** Naar het station. (goed). Goed. Je hoort: “Gaat deze bus naar het station”. Daarom is “Naar het station” het juiste antwoord.
- **C** Naar het centrum. (fout). Niet goed. Je hoort: “Gaat deze bus naar het station”. Daarom past “Naar het centrum” niet. Het juiste antwoord is “Naar het station”.

**Bewijs:** Gaat deze bus naar het station?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-009 | Een pet teruggeven

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Sofia: Is deze pet van jouw kind?
Fatima: Ja, die zochten we.
Sofia: Hij lag op de stoel.
Fatima: Dank je wel voor het meenemen.
**Vraag:** Waar lag de pet?

- **A** Op de stoel. (goed). Goed. Je hoort: “Hij lag op de stoel”. Daarom is “Op de stoel” het juiste antwoord.
- **B** In de tas. (fout). Niet goed. Je hoort: “Hij lag op de stoel”. Daarom past “In de tas” niet. Het juiste antwoord is “Op de stoel”.
- **C** Onder de bank. (fout). Niet goed. Je hoort: “Hij lag op de stoel”. Daarom past “Onder de bank” niet. Het juiste antwoord is “Op de stoel”.

**Bewijs:** Hij lag op de stoel.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-A1-dialogue-question-010 | Een pakje ophalen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Amina: Er ligt een pakje voor jou bij mij.
Kofi: Dank je. Kan ik het vanavond ophalen?
Amina: Ja, na zeven uur ben ik thuis.
Kofi: Dan kom ik rond half acht.
**Vraag:** Vanaf hoe laat is Amina thuis?

- **A** Na vijf uur. (fout). Niet goed. Je hoort: “Ja, na zeven uur ben ik thuis”. Daarom past “Na vijf uur” niet. Het juiste antwoord is “Na zeven uur”.
- **B** Pas morgen. (fout). Niet goed. Je hoort: “Ja, na zeven uur ben ik thuis”. Daarom past “Pas morgen” niet. Het juiste antwoord is “Na zeven uur”.
- **C** Na zeven uur. (goed). Goed. Je hoort: “Ja, na zeven uur ben ik thuis”. Daarom is “Na zeven uur” het juiste antwoord.

**Bewijs:** Ja, na zeven uur ben ik thuis.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
