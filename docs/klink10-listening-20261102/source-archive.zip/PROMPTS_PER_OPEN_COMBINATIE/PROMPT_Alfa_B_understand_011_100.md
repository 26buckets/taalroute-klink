# KLINK vervolgproductie: Alfa B. Luister en kies

Nu kandidaatbron: exact 10 opdrachten, IDs KLINK-LUI-P01-AB-understand-001 t/m KLINK-LUI-P01-AB-understand-010. Doel: 100 inhoudelijk unieke opdrachten in deze cel.
Nog te produceren: 90 opdrachten, in 9 batches van exact 10.

## Opdracht voor een nieuwe ChatGPT-chat

Gebruik de vaste masterregels van KLINK Luisteren v0.4 en de bestaande bronbestanden op Google Drive. Controleer eerst of de huidige tien brondossiers en eerdere batches al zijn opgeslagen, zodat niets dubbel wordt gemaakt.

**Niveau:** Alfa B. **Oefenvorm:** Luister en kies (`understand`).
**Doeltaak:** Korte uitspraak met voldoende context, vraag over details of de boodschap. Niet alleen woordherkenning.
**Niveauafspraak:** Eén of twee korte spreekbeurten of korte boodschap; gesproken vragen en keuzes, concrete tijd, plaats, aantal. Maximale steun.

### Productieritme en complete themawissel

**Ronde 02, opdracht 011-020.** Thema: Wonen, buren, voorzieningen. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 03, opdracht 021-030.** Thema: Winkel, geld, bestellen. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 04, opdracht 031-040.** Thema: School, leren, cursus. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 05, opdracht 041-050.** Thema: Gezondheid en afspraak. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 06, opdracht 051-060.** Thema: Werk, collega's, werkplek. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 07, opdracht 061-070.** Thema: Reizen, openbaar vervoer. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 08, opdracht 071-080.** Thema: Gemeente, brieven, loketten. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 09, opdracht 081-090.** Thema: Digitale communicatie en veiligheid. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.
**Ronde 10, opdracht 091-100.** Thema: Vrije tijd, familie en sociale contacten. Nieuwe, zelfstandige uitwerkingen. Houd de hele ronde betekenisvol maar divers qua perspectief, personen, handeling, vraagtype en woordenschat. Bewaak niveau, bronbewijs, feedback en overlap.

### Uitvoeropdracht voor de volgende chat

Begin uitsluitend met de eerstvolgende werkelijk ontbrekende batch voor **Alfa B / Luister en kies**. Lever precies tien volledige items, ieder met één uniek ID in de bestaande ID-structuur, exact transcript, sprekerbeurten, benodigde audio- en beeldmetadata, vraag, A/B/C, sleutel, afzonderlijke natuurlijke A2-uitleg bij alle opties, expliciet bewijs, taalreview- en negatieve-testlog. Bewaar alles in dezelfde Drive-projectmap, incl. JSON, leesversie, QA, hash en overdracht. Herhaal na akkoord per volgende batch t/m 100.

Niet vooruitlopen op audio, niveauvalidatie of publicatie. Vraag in volgende chats geen informatie opnieuw die in de master en bronmap vastligt.
