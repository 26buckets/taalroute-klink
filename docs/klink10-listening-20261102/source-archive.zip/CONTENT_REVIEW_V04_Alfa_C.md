# KLINK Luisteren | V0.4 | Alfa C

40 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-AC-understand-001 | De afspraak bij de tandarts

**Oefenvorm:** Luister en kies
**Gesproken bron:** De afspraak bij de tandarts is donderdag om half elf.
**Vraag:** Hoe laat is de afspraak?

- **A** Om half elf (goed). Goed. Je hoort: “De afspraak bij de tandarts is donderdag om half elf”. Daarom is “Om half elf” het juiste antwoord.
- **B** Om half tien (fout). Niet goed. Je hoort: “De afspraak bij de tandarts is donderdag om half elf”. Daarom past “Om half tien” niet. Het juiste antwoord is “Om half elf”.
- **C** Om elf uur (fout). Niet goed. Je hoort: “De afspraak bij de tandarts is donderdag om half elf”. Daarom past “Om elf uur” niet. Het juiste antwoord is “Om half elf”.

**Bewijs:** De afspraak bij de tandarts is donderdag om half elf.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-002 | De bus is te laat

**Oefenvorm:** Luister en kies
**Gesproken bron:** De bus komt tien minuten later.
**Vraag:** Hoeveel vertraging heeft de bus?

- **A** Vijf minuten (fout). Niet goed. Je hoort: “De bus komt tien minuten later”. Daarom past “Vijf minuten” niet. Het juiste antwoord is “Tien minuten”.
- **B** Twintig minuten (fout). Niet goed. Je hoort: “De bus komt tien minuten later”. Daarom past “Twintig minuten” niet. Het juiste antwoord is “Tien minuten”.
- **C** Tien minuten (goed). Goed. Je hoort: “De bus komt tien minuten later”. Daarom is “Tien minuten” het juiste antwoord.

**Bewijs:** De bus komt tien minuten later.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-003 | De verkeerde maat

**Oefenvorm:** Luister en kies
**Gesproken bron:** De schoenen zijn te klein.
**Vraag:** Wat is er met de schoenen?

- **A** Ze zijn kapot (fout). Niet goed. Je hoort: “De schoenen zijn te klein”. Daarom past “Ze zijn kapot” niet. Het juiste antwoord is “Ze zijn te klein”.
- **B** Ze zijn te klein (goed). Goed. Je hoort: “De schoenen zijn te klein”. Daarom is “Ze zijn te klein” het juiste antwoord.
- **C** Ze zijn te groot (fout). Niet goed. Je hoort: “De schoenen zijn te klein”. Daarom past “Ze zijn te groot” niet. Het juiste antwoord is “Ze zijn te klein”.

**Bewijs:** De schoenen zijn te klein.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-004 | Het formulier

**Oefenvorm:** Luister en kies
**Gesproken bron:** Mina moet haar adres invullen.
**Vraag:** Wat moet Mina invullen?

- **A** Haar adres (goed). Goed. Je hoort: “Mina moet haar adres invullen”. Daarom is “Haar adres” het juiste antwoord.
- **B** Haar schoenmaat (fout). Niet goed. Je hoort: “Mina moet haar adres invullen”. Daarom past “Haar schoenmaat” niet. Het juiste antwoord is “Haar adres”.
- **C** Haar lievelingseten (fout). Niet goed. Je hoort: “Mina moet haar adres invullen”. Daarom past “Haar lievelingseten” niet. Het juiste antwoord is “Haar adres”.

**Bewijs:** Mina moet haar adres invullen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-005 | De klas gaat naar buiten

**Oefenvorm:** Luister en kies
**Gesproken bron:** De klas gaat naar de bibliotheek.
**Vraag:** Waar gaat de klas naartoe?

- **A** Naar de markt (fout). Niet goed. Je hoort: “De klas gaat naar de bibliotheek”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar de bibliotheek”.
- **B** Naar het zwembad (fout). Niet goed. Je hoort: “De klas gaat naar de bibliotheek”. Daarom past “Naar het zwembad” niet. Het juiste antwoord is “Naar de bibliotheek”.
- **C** Naar de bibliotheek (goed). Goed. Je hoort: “De klas gaat naar de bibliotheek”. Daarom is “Naar de bibliotheek” het juiste antwoord.

**Bewijs:** De klas gaat naar de bibliotheek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-006 | De kraan lekt

**Oefenvorm:** Luister en kies
**Gesproken bron:** De kraan in de keuken lekt.
**Vraag:** Wat lekt er?

- **A** De verwarming (fout). Niet goed. Je hoort: “De kraan in de keuken lekt”. Daarom past “De verwarming” niet. Het juiste antwoord is “De kraan in de keuken”.
- **B** De kraan in de keuken (goed). Goed. Je hoort: “De kraan in de keuken lekt”. Daarom is “De kraan in de keuken” het juiste antwoord.
- **C** De douchekop (fout). Niet goed. Je hoort: “De kraan in de keuken lekt”. Daarom past “De douchekop” niet. Het juiste antwoord is “De kraan in de keuken”.

**Bewijs:** De kraan in de keuken lekt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-007 | Een dienst ruilen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Sara’s collega kan dinsdag haar dienst overnemen.
**Vraag:** Welke dag kan de collega wel?

- **A** Dinsdag (goed). Goed. Je hoort: “Sara’s collega kan dinsdag haar dienst overnemen”. Daarom is “Dinsdag” het juiste antwoord.
- **B** Maandag (fout). Niet goed. Je hoort: “Sara’s collega kan dinsdag haar dienst overnemen”. Daarom past “Maandag” niet. Het juiste antwoord is “Dinsdag”.
- **C** Vrijdag (fout). Niet goed. Je hoort: “Sara’s collega kan dinsdag haar dienst overnemen”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Dinsdag”.

**Bewijs:** Sara’s collega kan dinsdag haar dienst overnemen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-008 | Het boek verlengen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het bibliotheekboek moet morgen terug.
**Vraag:** Wanneer moet het boek terug zonder verlenging?

- **A** Vandaag (fout). Niet goed. Je hoort: “Het bibliotheekboek moet morgen terug”. Daarom past “Vandaag” niet. Het juiste antwoord is “Morgen”.
- **B** Volgende week (fout). Niet goed. Je hoort: “Het bibliotheekboek moet morgen terug”. Daarom past “Volgende week” niet. Het juiste antwoord is “Morgen”.
- **C** Morgen (goed). Goed. Je hoort: “Het bibliotheekboek moet morgen terug”. Daarom is “Morgen” het juiste antwoord.

**Bewijs:** Het bibliotheekboek moet morgen terug.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-009 | De bestelling ophalen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het pakket ligt bij het afhaalpunt.
**Vraag:** Waar ligt het pakket?

- **A** Op school (fout). Niet goed. Je hoort: “Het pakket ligt bij het afhaalpunt”. Daarom past “Op school” niet. Het juiste antwoord is “Bij het afhaalpunt”.
- **B** Bij het afhaalpunt (goed). Goed. Je hoort: “Het pakket ligt bij het afhaalpunt”. Daarom is “Bij het afhaalpunt” het juiste antwoord.
- **C** Bij de buren (fout). Niet goed. Je hoort: “Het pakket ligt bij het afhaalpunt”. Daarom past “Bij de buren” niet. Het juiste antwoord is “Bij het afhaalpunt”.

**Bewijs:** Het pakket ligt bij het afhaalpunt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-understand-010 | Afval scheiden

**Oefenvorm:** Luister en kies
**Gesproken bron:** De lege fles hoort bij het plastic afval.
**Vraag:** Waar hoort de fles?

- **A** Bij het plastic afval (goed). Goed. Je hoort: “De lege fles hoort bij het plastic afval”. Daarom is “Bij het plastic afval” het juiste antwoord.
- **B** Bij het papier (fout). Niet goed. Je hoort: “De lege fles hoort bij het plastic afval”. Daarom past “Bij het papier” niet. Het juiste antwoord is “Bij het plastic afval”.
- **C** Bij het glas (fout). Niet goed. Je hoort: “De lege fles hoort bij het plastic afval”. Daarom past “Bij het glas” niet. Het juiste antwoord is “Bij het plastic afval”.

**Bewijs:** De lege fles hoort bij het plastic afval.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-001 | De afspraak bij de tandarts

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Nora heeft donderdag om half elf een afspraak bij de tandarts. Ze schrijft de tijd op een kaartje. Op donderdag vertrekt ze op tijd.
**Vraag:** Hoe laat is de afspraak?

- **A** Om half tien (fout). Niet goed. Je hoort: “Nora heeft donderdag om half elf een afspraak bij de tandarts”. Daarom past “Om half tien” niet. Het juiste antwoord is “Om half elf”.
- **B** Om elf uur (fout). Niet goed. Je hoort: “Nora heeft donderdag om half elf een afspraak bij de tandarts”. Daarom past “Om elf uur” niet. Het juiste antwoord is “Om half elf”.
- **C** Om half elf (goed). Goed. Je hoort: “Nora heeft donderdag om half elf een afspraak bij de tandarts”. Daarom is “Om half elf” het juiste antwoord.

**Bewijs:** Nora heeft donderdag om half elf een afspraak bij de tandarts.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-002 | De bus is te laat

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Omar staat bij de bushalte. Op het bord staat dat de bus tien minuten later komt. Hij stuurt een bericht naar zijn collega.
**Vraag:** Hoeveel vertraging heeft de bus?

- **A** Twintig minuten (fout). Niet goed. Je hoort: “Op het bord staat dat de bus tien minuten later komt”. Daarom past “Twintig minuten” niet. Het juiste antwoord is “Tien minuten”.
- **B** Tien minuten (goed). Goed. Je hoort: “Op het bord staat dat de bus tien minuten later komt”. Daarom is “Tien minuten” het juiste antwoord.
- **C** Vijf minuten (fout). Niet goed. Je hoort: “Op het bord staat dat de bus tien minuten later komt”. Daarom past “Vijf minuten” niet. Het juiste antwoord is “Tien minuten”.

**Bewijs:** Op het bord staat dat de bus tien minuten later komt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-003 | De verkeerde maat

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Fatima past nieuwe schoenen. Ze zijn te klein. Ze vraagt de verkoper om een grotere maat.
**Vraag:** Wat is er met de schoenen?

- **A** Ze zijn te klein (goed). Goed. Je hoort: “Ze zijn te klein”. Daarom is “Ze zijn te klein” het juiste antwoord.
- **B** Ze zijn te groot (fout). Niet goed. Je hoort: “Ze zijn te klein”. Daarom past “Ze zijn te groot” niet. Het juiste antwoord is “Ze zijn te klein”.
- **C** Ze zijn kapot (fout). Niet goed. Je hoort: “Ze zijn te klein”. Daarom past “Ze zijn kapot” niet. Het juiste antwoord is “Ze zijn te klein”.

**Bewijs:** Ze zijn te klein.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-004 | Het formulier

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Mina krijgt een formulier van de gemeente. Ze moet haar naam en adres invullen. Daarna geeft ze het formulier af.
**Vraag:** Wat moet Mina naast haar naam invullen?

- **A** Haar schoenmaat (fout). Niet goed. Je hoort: “Ze moet haar naam en adres invullen”. Daarom past “Haar schoenmaat” niet. Het juiste antwoord is “Haar adres”.
- **B** Haar lievelingseten (fout). Niet goed. Je hoort: “Ze moet haar naam en adres invullen”. Daarom past “Haar lievelingseten” niet. Het juiste antwoord is “Haar adres”.
- **C** Haar adres (goed). Goed. Je hoort: “Ze moet haar naam en adres invullen”. Daarom is “Haar adres” het juiste antwoord.

**Bewijs:** Ze moet haar naam en adres invullen.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-005 | De klas gaat naar buiten

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** De docent vertelt dat de klas morgen naar de bibliotheek gaat. Iedereen neemt een bibliotheekpas mee. Ze verzamelen om negen uur bij school.
**Vraag:** Waar gaat de klas naartoe?

- **A** Naar het zwembad (fout). Niet goed. Je hoort: “De docent vertelt dat de klas morgen naar de bibliotheek gaat”. Daarom past “Naar het zwembad” niet. Het juiste antwoord is “Naar de bibliotheek”.
- **B** Naar de bibliotheek (goed). Goed. Je hoort: “De docent vertelt dat de klas morgen naar de bibliotheek gaat”. Daarom is “Naar de bibliotheek” het juiste antwoord.
- **C** Naar de markt (fout). Niet goed. Je hoort: “De docent vertelt dat de klas morgen naar de bibliotheek gaat”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar de bibliotheek”.

**Bewijs:** De docent vertelt dat de klas morgen naar de bibliotheek gaat.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-006 | De kraan lekt

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Ali ziet water onder de kraan in de keuken. Hij draait de kraan dicht. Daarna meldt hij het probleem bij de verhuurder.
**Vraag:** Wat lekt er?

- **A** De kraan in de keuken (goed). Goed. Je hoort: “Ali ziet water onder de kraan in de keuken”. Daarom is “De kraan in de keuken” het juiste antwoord.
- **B** De douchekop (fout). Niet goed. Je hoort: “Ali ziet water onder de kraan in de keuken”. Daarom past “De douchekop” niet. Het juiste antwoord is “De kraan in de keuken”.
- **C** De verwarming (fout). Niet goed. Je hoort: “Ali ziet water onder de kraan in de keuken”. Daarom past “De verwarming” niet. Het juiste antwoord is “De kraan in de keuken”.

**Bewijs:** Ali ziet water onder de kraan in de keuken.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-007 | Een dienst ruilen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Sara werkt dinsdagmiddag, maar ze heeft dan een afspraak. Ze vraagt haar collega om dinsdag voor haar te werken. De collega wil dat wel, als Sara haar maandagdienst overneemt.
**Vraag:** Welke dag kan de collega wel?

- **A** Maandag (fout). Niet goed. Je hoort: “Ze vraagt haar collega om dinsdag voor haar te werken”. Daarom past “Maandag” niet. Het juiste antwoord is “Dinsdag”.
- **B** Vrijdag (fout). Niet goed. Je hoort: “Ze vraagt haar collega om dinsdag voor haar te werken”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Dinsdag”.
- **C** Dinsdag (goed). Goed. Je hoort: “Ze vraagt haar collega om dinsdag voor haar te werken”. Daarom is “Dinsdag” het juiste antwoord.

**Bewijs:** Ze vraagt haar collega om dinsdag voor haar te werken.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-008 | Het boek verlengen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Nora heeft een boek van de bibliotheek. Ze moet het morgen terugbrengen, maar ze is nog niet klaar. Ze vraagt of ze het boek mag verlengen.
**Vraag:** Wanneer moet het boek terug zonder verlenging?

- **A** Volgende week (fout). Niet goed. Je hoort: “Ze moet het morgen terugbrengen, maar ze is nog niet klaar”. Daarom past “Volgende week” niet. Het juiste antwoord is “Morgen”.
- **B** Morgen (goed). Goed. Je hoort: “Ze moet het morgen terugbrengen, maar ze is nog niet klaar”. Daarom is “Morgen” het juiste antwoord.
- **C** Vandaag (fout). Niet goed. Je hoort: “Ze moet het morgen terugbrengen, maar ze is nog niet klaar”. Daarom past “Vandaag” niet. Het juiste antwoord is “Morgen”.

**Bewijs:** Ze moet het morgen terugbrengen, maar ze is nog niet klaar.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-009 | De bestelling ophalen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Elena krijgt een bericht dat haar pakket bij het afhaalpunt ligt. Ze neemt haar identiteitsbewijs mee. Na haar werk haalt ze het pakket op.
**Vraag:** Waar ligt het pakket?

- **A** Bij het afhaalpunt (goed). Goed. Je hoort: “Elena krijgt een bericht dat haar pakket bij het afhaalpunt ligt”. Daarom is “Bij het afhaalpunt” het juiste antwoord.
- **B** Bij de buren (fout). Niet goed. Je hoort: “Elena krijgt een bericht dat haar pakket bij het afhaalpunt ligt”. Daarom past “Bij de buren” niet. Het juiste antwoord is “Bij het afhaalpunt”.
- **C** Op school (fout). Niet goed. Je hoort: “Elena krijgt een bericht dat haar pakket bij het afhaalpunt ligt”. Daarom past “Op school” niet. Het juiste antwoord is “Bij het afhaalpunt”.

**Bewijs:** Elena krijgt een bericht dat haar pakket bij het afhaalpunt ligt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-text-question-010 | Afval scheiden

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Youssef ruimt de keuken op. Hij heeft een lege plastic fles. Hij doet de fles in de bak voor plastic afval.
**Vraag:** Waar hoort de fles?

- **A** Bij het papier (fout). Niet goed. Je hoort: “Hij doet de fles in de bak voor plastic afval”. Daarom past “Bij het papier” niet. Het juiste antwoord is “Bij het plastic afval”.
- **B** Bij het glas (fout). Niet goed. Je hoort: “Hij doet de fles in de bak voor plastic afval”. Daarom past “Bij het glas” niet. Het juiste antwoord is “Bij het plastic afval”.
- **C** Bij het plastic afval (goed). Goed. Je hoort: “Hij doet de fles in de bak voor plastic afval”. Daarom is “Bij het plastic afval” het juiste antwoord.

**Bewijs:** Hij doet de fles in de bak voor plastic afval.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-001 | De afspraak bij de tandarts

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Hoe laat ben ik donderdag aan de beurt?
Assistent: Om half elf.
Nora: Dank u, ik schrijf het op.
**Vraag:** Hoe laat is de afspraak?

- **A** Om elf uur (fout). Niet goed. Je hoort: “Om half elf”. Daarom past “Om elf uur” niet. Het juiste antwoord is “Om half elf”.
- **B** Om half elf (goed). Goed. Je hoort: “Om half elf”. Daarom is “Om half elf” het juiste antwoord.
- **C** Om half tien (fout). Niet goed. Je hoort: “Om half elf”. Daarom past “Om half tien” niet. Het juiste antwoord is “Om half elf”.

**Bewijs:** Om half elf.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-002 | De bus is te laat

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Omar: Komt de bus op tijd?
Chauffeur: Nee, we hebben tien minuten vertraging.
Omar: Dan bel ik mijn werk.
**Vraag:** Hoeveel vertraging heeft de bus?

- **A** Tien minuten (goed). Goed. Je hoort: “Nee, we hebben tien minuten vertraging”. Daarom is “Tien minuten” het juiste antwoord.
- **B** Vijf minuten (fout). Niet goed. Je hoort: “Nee, we hebben tien minuten vertraging”. Daarom past “Vijf minuten” niet. Het juiste antwoord is “Tien minuten”.
- **C** Twintig minuten (fout). Niet goed. Je hoort: “Nee, we hebben tien minuten vertraging”. Daarom past “Twintig minuten” niet. Het juiste antwoord is “Tien minuten”.

**Bewijs:** Nee, we hebben tien minuten vertraging.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-003 | De verkeerde maat

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Verkoper: Zitten de schoenen goed?
Fatima: Nee, ze zijn te klein.
Verkoper: Ik pak een grotere maat.
**Vraag:** Wat is er met de schoenen?

- **A** Ze zijn te groot (fout). Niet goed. Je hoort: “Nee, ze zijn te klein”. Daarom past “Ze zijn te groot” niet. Het juiste antwoord is “Ze zijn te klein”.
- **B** Ze zijn kapot (fout). Niet goed. Je hoort: “Nee, ze zijn te klein”. Daarom past “Ze zijn kapot” niet. Het juiste antwoord is “Ze zijn te klein”.
- **C** Ze zijn te klein (goed). Goed. Je hoort: “Nee, ze zijn te klein”. Daarom is “Ze zijn te klein” het juiste antwoord.

**Bewijs:** Nee, ze zijn te klein.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-004 | Het formulier

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Medewerker: Heeft u uw adres ingevuld?
Mina: Nog niet. Waar moet dat?
Medewerker: Hier, onder uw naam.
**Vraag:** Wat moet Mina nog invullen?

- **A** Haar lievelingseten (fout). Niet goed. Je hoort: “Heeft u uw adres ingevuld”. Daarom past “Haar lievelingseten” niet. Het juiste antwoord is “Haar adres”.
- **B** Haar adres (goed). Goed. Je hoort: “Heeft u uw adres ingevuld”. Daarom is “Haar adres” het juiste antwoord.
- **C** Haar schoenmaat (fout). Niet goed. Je hoort: “Heeft u uw adres ingevuld”. Daarom past “Haar schoenmaat” niet. Het juiste antwoord is “Haar adres”.

**Bewijs:** Heeft u uw adres ingevuld?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-005 | De klas gaat naar buiten

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Cursist: Waar gaan we morgen naartoe?
Docent: Naar de bibliotheek.
Cursist: Ik neem mijn pas mee.
**Vraag:** Waar gaat de klas naartoe?

- **A** Naar de bibliotheek (goed). Goed. Je hoort: “Naar de bibliotheek”. Daarom is “Naar de bibliotheek” het juiste antwoord.
- **B** Naar de markt (fout). Niet goed. Je hoort: “Naar de bibliotheek”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar de bibliotheek”.
- **C** Naar het zwembad (fout). Niet goed. Je hoort: “Naar de bibliotheek”. Daarom past “Naar het zwembad” niet. Het juiste antwoord is “Naar de bibliotheek”.

**Bewijs:** Naar de bibliotheek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-006 | De kraan lekt

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: De kraan in de keuken lekt.
Verhuurder: Heeft u hem dichtgedraaid?
Ali: Ja, maar er ligt nog water.
**Vraag:** Wat lekt er?

- **A** De douchekop (fout). Niet goed. Je hoort: “De kraan in de keuken lekt”. Daarom past “De douchekop” niet. Het juiste antwoord is “De kraan in de keuken”.
- **B** De verwarming (fout). Niet goed. Je hoort: “De kraan in de keuken lekt”. Daarom past “De verwarming” niet. Het juiste antwoord is “De kraan in de keuken”.
- **C** De kraan in de keuken (goed). Goed. Je hoort: “De kraan in de keuken lekt”. Daarom is “De kraan in de keuken” het juiste antwoord.

**Bewijs:** De kraan in de keuken lekt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-007 | Een dienst ruilen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Sara: Kun jij dinsdag voor mij werken?
Collega: Ja, als jij maandag mijn dienst overneemt.
Sara: Dat kan. Dank je.
**Vraag:** Welke dag kan de collega wel?

- **A** Vrijdag (fout). Niet goed. Je hoort: “Kun jij dinsdag voor mij werken”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Dinsdag”.
- **B** Dinsdag (goed). Goed. Je hoort: “Kun jij dinsdag voor mij werken”. Daarom is “Dinsdag” het juiste antwoord.
- **C** Maandag (fout). Niet goed. Je hoort: “Kun jij dinsdag voor mij werken”. Daarom past “Maandag” niet. Het juiste antwoord is “Dinsdag”.

**Bewijs:** Kun jij dinsdag voor mij werken?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-008 | Het boek verlengen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Mijn boek moet morgen terug. Kan ik het verlengen?
Medewerker: Ja, u kunt het nog een week houden.
Nora: Dat is fijn.
**Vraag:** Wanneer moet het boek terug zonder verlenging?

- **A** Morgen (goed). Goed. Je hoort: “Mijn boek moet morgen terug”. Daarom is “Morgen” het juiste antwoord.
- **B** Vandaag (fout). Niet goed. Je hoort: “Mijn boek moet morgen terug”. Daarom past “Vandaag” niet. Het juiste antwoord is “Morgen”.
- **C** Volgende week (fout). Niet goed. Je hoort: “Mijn boek moet morgen terug”. Daarom past “Volgende week” niet. Het juiste antwoord is “Morgen”.

**Bewijs:** Mijn boek moet morgen terug.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-009 | De bestelling ophalen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Elena: Waar kan ik mijn pakket ophalen?
Medewerker: Bij het afhaalpunt aan de Marktstraat.
Elena: Ik neem mijn identiteitsbewijs mee.
**Vraag:** Waar ligt het pakket?

- **A** Bij de buren (fout). Niet goed. Je hoort: “Bij het afhaalpunt aan de Marktstraat”. Daarom past “Bij de buren” niet. Het juiste antwoord is “Bij het afhaalpunt”.
- **B** Op school (fout). Niet goed. Je hoort: “Bij het afhaalpunt aan de Marktstraat”. Daarom past “Op school” niet. Het juiste antwoord is “Bij het afhaalpunt”.
- **C** Bij het afhaalpunt (goed). Goed. Je hoort: “Bij het afhaalpunt aan de Marktstraat”. Daarom is “Bij het afhaalpunt” het juiste antwoord.

**Bewijs:** Bij het afhaalpunt aan de Marktstraat.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-dialogue-question-010 | Afval scheiden

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Youssef: Waar moet deze plastic fles?
Collega: In de bak voor plastic afval.
Youssef: Goed, ik doe hem daar.
**Vraag:** Waar hoort de fles?

- **A** Bij het glas (fout). Niet goed. Je hoort: “In de bak voor plastic afval”. Daarom past “Bij het glas” niet. Het juiste antwoord is “Bij het plastic afval”.
- **B** Bij het plastic afval (goed). Goed. Je hoort: “In de bak voor plastic afval”. Daarom is “Bij het plastic afval” het juiste antwoord.
- **C** Bij het papier (fout). Niet goed. Je hoort: “In de bak voor plastic afval”. Daarom past “Bij het papier” niet. Het juiste antwoord is “Bij het plastic afval”.

**Bewijs:** In de bak voor plastic afval.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-001 | De afspraak bij de tandarts

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Assistent: Uw afspraak is donderdag om half elf.
**Vraag:** Wat is een passende reactie?

- **A** Dank u, ik kom op tijd. (goed). Goed. Je hoort: “Uw afspraak is donderdag om half elf.” Met “Dank u, ik kom op tijd” geef je een passend antwoord.
- **B** Dan kom ik vrijdag om half elf. (fout). Niet goed. Je hoort: “Uw afspraak is donderdag om half elf.” “Dan kom ik vrijdag om half elf” past niet bij deze vraag of opdracht. Een passende reactie is: “Dank u, ik kom op tijd”.
- **C** Kan ik donderdag om elf uur komen zonder het te melden? (fout). Niet goed. Je hoort: “Uw afspraak is donderdag om half elf.” “Kan ik donderdag om elf uur komen zonder het te melden?” past niet bij deze vraag of opdracht. Een passende reactie is: “Dank u, ik kom op tijd”.

**Bewijs:** Uw afspraak is donderdag om half elf.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-002 | De bus is te laat

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Collega: Kom je door de vertraging van de bus later op je werk?
**Vraag:** Wat is een passende reactie?

- **A** Nee, de bus komt vandaag precies op tijd. (fout). Niet goed. Je hoort: “Kom je door de vertraging van de bus later op je werk?” “Nee, de bus komt vandaag precies op tijd” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, de bus heeft vertraging”.
- **B** Ja, maar ik hoef mijn werk niet te laten weten dat ik later ben. (fout). Niet goed. Je hoort: “Kom je door de vertraging van de bus later op je werk?” “Ja, maar ik hoef mijn werk niet te laten weten dat ik later ben” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, de bus heeft vertraging”.
- **C** Ja, de bus heeft vertraging. (goed). Goed. Je hoort: “Kom je door de vertraging van de bus later op je werk?” Met “Ja, de bus heeft vertraging” geef je een passend antwoord.

**Bewijs:** Kom je door de vertraging van de bus later op je werk?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-003 | De verkeerde maat

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Verkoper: Wilt u een grotere maat passen?
**Vraag:** Wat is een passende reactie?

- **A** Nee, ik houd deze te kleine schoenen. (fout). Niet goed. Je hoort: “Wilt u een grotere maat passen?” “Nee, ik houd deze te kleine schoenen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag. Deze zijn te klein”.
- **B** Ja, graag. Deze zijn te klein. (goed). Goed. Je hoort: “Wilt u een grotere maat passen?” Met “Ja, graag. Deze zijn te klein” geef je een passend antwoord.
- **C** Nee, deze schoenen zijn te groot; ik wil een kleinere maat. (fout). Niet goed. Je hoort: “Wilt u een grotere maat passen?” “Nee, deze schoenen zijn te groot; ik wil een kleinere maat” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, graag. Deze zijn te klein”.

**Bewijs:** Wilt u een grotere maat passen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-004 | Het formulier

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Medewerker: Kunt u uw adres hier invullen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, ik vul het hier in. (goed). Goed. Je hoort: “Kunt u uw adres hier invullen?” Met “Ja, ik vul het hier in” geef je een passend antwoord.
- **B** Nee, mijn adres hoeft niet op dit formulier. (fout). Niet goed. Je hoort: “Kunt u uw adres hier invullen?” “Nee, mijn adres hoeft niet op dit formulier” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik vul het hier in”.
- **C** Ja, ik vul hier mijn telefoonnummer in plaats van mijn adres in. (fout). Niet goed. Je hoort: “Kunt u uw adres hier invullen?” “Ja, ik vul hier mijn telefoonnummer in plaats van mijn adres in” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik vul het hier in”.

**Bewijs:** Kunt u uw adres hier invullen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-005 | De klas gaat naar buiten

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Docent: Neem morgen je bibliotheekpas mee.
**Vraag:** Wat is een passende reactie?

- **A** Goed, ik neem alleen mijn bankpas mee. (fout). Niet goed. Je hoort: “Neem morgen je bibliotheekpas mee.” “Goed, ik neem alleen mijn bankpas mee” past niet bij deze vraag of opdracht. Een passende reactie is: “Goed, ik stop hem in mijn tas”.
- **B** Ik hoef geen pas mee te nemen naar de bibliotheek. (fout). Niet goed. Je hoort: “Neem morgen je bibliotheekpas mee.” “Ik hoef geen pas mee te nemen naar de bibliotheek” past niet bij deze vraag of opdracht. Een passende reactie is: “Goed, ik stop hem in mijn tas”.
- **C** Goed, ik stop hem in mijn tas. (goed). Goed. Je hoort: “Neem morgen je bibliotheekpas mee.” Met “Goed, ik stop hem in mijn tas” geef je een passend antwoord.

**Bewijs:** Neem morgen je bibliotheekpas mee.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-006 | De kraan lekt

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Verhuurder: Kunt u vertellen wat er kapot is?
**Vraag:** Wat is een passende reactie?

- **A** De kraan werkt goed; er lekt niets. (fout). Niet goed. Je hoort: “Kunt u vertellen wat er kapot is?” “De kraan werkt goed; er lekt niets” past niet bij deze vraag of opdracht. Een passende reactie is: “De kraan in de keuken lekt”.
- **B** De kraan in de keuken lekt. (goed). Goed. Je hoort: “Kunt u vertellen wat er kapot is?” Met “De kraan in de keuken lekt” geef je een passend antwoord.
- **C** Ik weet het niet, maar u hoeft niet te komen kijken. (fout). Niet goed. Je hoort: “Kunt u vertellen wat er kapot is?” “Ik weet het niet, maar u hoeft niet te komen kijken” past niet bij deze vraag of opdracht. Een passende reactie is: “De kraan in de keuken lekt”.

**Bewijs:** Kunt u vertellen wat er kapot is?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-007 | Een dienst ruilen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Collega: Ik werk dinsdag voor jou als jij maandag voor mij werkt.
**Vraag:** Wat is een passende reactie?

- **A** Goed, ik werk maandag. (goed). Goed. Je hoort: “Ik werk dinsdag voor jou als jij maandag voor mij werkt.” Met “Goed, ik werk maandag” geef je een passend antwoord.
- **B** Ik kan alleen op dinsdag voor jou werken. (fout). Niet goed. Je hoort: “Ik werk dinsdag voor jou als jij maandag voor mij werkt.” “Ik kan alleen op dinsdag voor jou werken” past niet bij deze vraag of opdracht. Een passende reactie is: “Goed, ik werk maandag”.
- **C** Ik neem je maandagdienst niet over, maar wil de ruil wel. (fout). Niet goed. Je hoort: “Ik werk dinsdag voor jou als jij maandag voor mij werkt.” “Ik neem je maandagdienst niet over, maar wil de ruil wel” past niet bij deze vraag of opdracht. Een passende reactie is: “Goed, ik werk maandag”.

**Bewijs:** Ik werk dinsdag voor jou als jij maandag voor mij werkt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-008 | Het boek verlengen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Medewerker: U kunt het boek één week langer houden.
**Vraag:** Wat is een passende reactie?

- **A** Dan moet ik het boek toch morgen terugbrengen. (fout). Niet goed. Je hoort: “U kunt het boek één week langer houden.” “Dan moet ik het boek toch morgen terugbrengen” past niet bij deze vraag of opdracht. Een passende reactie is: “Dank u, dat helpt mij”.
- **B** Dan hoef ik het boek helemaal niet meer terug te brengen. (fout). Niet goed. Je hoort: “U kunt het boek één week langer houden.” “Dan hoef ik het boek helemaal niet meer terug te brengen” past niet bij deze vraag of opdracht. Een passende reactie is: “Dank u, dat helpt mij”.
- **C** Dank u, dat helpt mij. (goed). Goed. Je hoort: “U kunt het boek één week langer houden.” Met “Dank u, dat helpt mij” geef je een passend antwoord.

**Bewijs:** U kunt het boek één week langer houden.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-009 | De bestelling ophalen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Medewerker: Neemt u een identiteitsbewijs mee?
**Vraag:** Wat is een passende reactie?

- **A** Nee, ik neem alleen een boodschappentas mee. (fout). Niet goed. Je hoort: “Neemt u een identiteitsbewijs mee?” “Nee, ik neem alleen een boodschappentas mee” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik heb het bij me”.
- **B** Ja, ik heb het bij me. (goed). Goed. Je hoort: “Neemt u een identiteitsbewijs mee?” Met “Ja, ik heb het bij me” geef je een passend antwoord.
- **C** Ik heb geen identiteitsbewijs nodig om het pakket op te halen. (fout). Niet goed. Je hoort: “Neemt u een identiteitsbewijs mee?” “Ik heb geen identiteitsbewijs nodig om het pakket op te halen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik heb het bij me”.

**Bewijs:** Neemt u een identiteitsbewijs mee?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AC-suitable-reply-010 | Afval scheiden

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Collega: Wilt u de plastic fles in de juiste bak doen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, ik doe hem in de bak voor plastic afval. (goed). Goed. Je hoort: “Wilt u de plastic fles in de juiste bak doen?” Met “Ja, ik doe hem in de bak voor plastic afval” geef je een passend antwoord.
- **B** Nee, deze fles hoort bij papier. (fout). Niet goed. Je hoort: “Wilt u de plastic fles in de juiste bak doen?” “Nee, deze fles hoort bij papier” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik doe hem in de bak voor plastic afval”.
- **C** Ja, ik leg de fles naast de afvalbak. (fout). Niet goed. Je hoort: “Wilt u de plastic fles in de juiste bak doen?” “Ja, ik leg de fles naast de afvalbak” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik doe hem in de bak voor plastic afval”.

**Bewijs:** Wilt u de plastic fles in de juiste bak doen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
