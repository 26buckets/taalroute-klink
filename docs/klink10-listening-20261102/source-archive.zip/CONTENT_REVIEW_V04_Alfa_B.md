# KLINK Luisteren | V0.4 | Alfa B

40 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-AB-understand-001 | De afspraak morgen

**Oefenvorm:** Luister en kies
**Gesproken bron:** De afspraak is morgen om tien uur.
**Vraag:** Wanneer is de afspraak?

- **A** Morgen om tien uur (goed). Goed. Je hoort: “De afspraak is morgen om tien uur”. Daarom is “Morgen om tien uur” het juiste antwoord.
- **B** Vandaag om tien uur (fout). Niet goed. Je hoort: “De afspraak is morgen om tien uur”. Daarom past “Vandaag om tien uur” niet. Het juiste antwoord is “Morgen om tien uur”.
- **C** Morgen om twee uur (fout). Niet goed. Je hoort: “De afspraak is morgen om tien uur”. Daarom past “Morgen om twee uur” niet. Het juiste antwoord is “Morgen om tien uur”.

**Bewijs:** De afspraak is morgen om tien uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-002 | De blauwe trui

**Oefenvorm:** Luister en kies
**Gesproken bron:** Omar koopt een blauwe trui.
**Vraag:** Welke trui kiest Omar?

- **A** De rode trui (fout). Niet goed. Je hoort: “Omar koopt een blauwe trui”. Daarom past “De rode trui” niet. Het juiste antwoord is “De blauwe trui”.
- **B** De zwarte trui (fout). Niet goed. Je hoort: “Omar koopt een blauwe trui”. Daarom past “De zwarte trui” niet. Het juiste antwoord is “De blauwe trui”.
- **C** De blauwe trui (goed). Goed. Je hoort: “Omar koopt een blauwe trui”. Daarom is “De blauwe trui” het juiste antwoord.

**Bewijs:** Omar koopt een blauwe trui.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-003 | De regen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het regent. Sara neemt een paraplu mee.
**Vraag:** Wat neemt Sara mee?

- **A** Een boek (fout). Niet goed. Je hoort: “Sara neemt een paraplu mee”. Daarom past “Een boek” niet. Het juiste antwoord is “Een paraplu”.
- **B** Een paraplu (goed). Goed. Je hoort: “Sara neemt een paraplu mee”. Daarom is “Een paraplu” het juiste antwoord.
- **C** Een zonnebril (fout). Niet goed. Je hoort: “Sara neemt een paraplu mee”. Daarom past “Een zonnebril” niet. Het juiste antwoord is “Een paraplu”.

**Bewijs:** Sara neemt een paraplu mee.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-004 | De bus naar het station

**Oefenvorm:** Luister en kies
**Gesproken bron:** Bus 7 gaat naar het station.
**Vraag:** Waar gaat bus 7 naartoe?

- **A** Naar het station (goed). Goed. Je hoort: “Bus 7 gaat naar het station”. Daarom is “Naar het station” het juiste antwoord.
- **B** Naar het ziekenhuis (fout). Niet goed. Je hoort: “Bus 7 gaat naar het station”. Daarom past “Naar het ziekenhuis” niet. Het juiste antwoord is “Naar het station”.
- **C** Naar de markt (fout). Niet goed. Je hoort: “Bus 7 gaat naar het station”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar het station”.

**Bewijs:** Bus 7 gaat naar het station.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-005 | Twee kilo appels

**Oefenvorm:** Luister en kies
**Gesproken bron:** Mina koopt twee kilo appels.
**Vraag:** Hoeveel appels koopt Mina?

- **A** Een kilo (fout). Niet goed. Je hoort: “Mina koopt twee kilo appels”. Daarom past “Een kilo” niet. Het juiste antwoord is “Twee kilo”.
- **B** Drie kilo (fout). Niet goed. Je hoort: “Mina koopt twee kilo appels”. Daarom past “Drie kilo” niet. Het juiste antwoord is “Twee kilo”.
- **C** Twee kilo (goed). Goed. Je hoort: “Mina koopt twee kilo appels”. Daarom is “Twee kilo” het juiste antwoord.

**Bewijs:** Mina koopt twee kilo appels.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-006 | De les begint

**Oefenvorm:** Luister en kies
**Gesproken bron:** De les begint om negen uur.
**Vraag:** Hoe laat begint de les?

- **A** Om tien uur (fout). Niet goed. Je hoort: “De les begint om negen uur”. Daarom past “Om tien uur” niet. Het juiste antwoord is “Om negen uur”.
- **B** Om negen uur (goed). Goed. Je hoort: “De les begint om negen uur”. Daarom is “Om negen uur” het juiste antwoord.
- **C** Om acht uur (fout). Niet goed. Je hoort: “De les begint om negen uur”. Daarom past “Om acht uur” niet. Het juiste antwoord is “Om negen uur”.

**Bewijs:** De les begint om negen uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-007 | Het brood is op

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het brood is op. Ali koopt nieuw brood.
**Vraag:** Wat gaat Ali kopen?

- **A** Brood (goed). Goed. Je hoort: “Het brood is op”. Daarom is “Brood” het juiste antwoord.
- **B** Eieren (fout). Niet goed. Je hoort: “Het brood is op”. Daarom past “Eieren” niet. Het juiste antwoord is “Brood”.
- **C** Melk (fout). Niet goed. Je hoort: “Het brood is op”. Daarom past “Melk” niet. Het juiste antwoord is “Brood”.

**Bewijs:** Het brood is op.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-008 | Een fietsband

**Oefenvorm:** Luister en kies
**Gesproken bron:** De achterband van Lina's fiets is lek.
**Vraag:** Wat is kapot?

- **A** Het zadel (fout). Niet goed. Je hoort: “De achterband van Lina's fiets is lek”. Daarom past “Het zadel” niet. Het juiste antwoord is “De achterband”.
- **B** Het stuur (fout). Niet goed. Je hoort: “De achterband van Lina's fiets is lek”. Daarom past “Het stuur” niet. Het juiste antwoord is “De achterband”.
- **C** De achterband (goed). Goed. Je hoort: “De achterband van Lina's fiets is lek”. Daarom is “De achterband” het juiste antwoord.

**Bewijs:** De achterband van Lina's fiets is lek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-009 | Een bericht van school

**Oefenvorm:** Luister en kies
**Gesproken bron:** De school stuurt een bericht: vrijdag is er geen les.
**Vraag:** Wanneer is er geen les?

- **A** Woensdag (fout). Niet goed. Je hoort: “vrijdag is er geen les”. Daarom past “Woensdag” niet. Het juiste antwoord is “Vrijdag”.
- **B** Vrijdag (goed). Goed. Je hoort: “vrijdag is er geen les”. Daarom is “Vrijdag” het juiste antwoord.
- **C** Maandag (fout). Niet goed. Je hoort: “vrijdag is er geen les”. Daarom past “Maandag” niet. Het juiste antwoord is “Vrijdag”.

**Bewijs:** vrijdag is er geen les.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-understand-010 | De tas in de kast

**Oefenvorm:** Luister en kies
**Gesproken bron:** Elena zet de tas in de kast.
**Vraag:** Waar staat de tas?

- **A** In de kast (goed). Goed. Je hoort: “Elena zet de tas in de kast”. Daarom is “In de kast” het juiste antwoord.
- **B** Onder de tafel (fout). Niet goed. Je hoort: “Elena zet de tas in de kast”. Daarom past “Onder de tafel” niet. Het juiste antwoord is “In de kast”.
- **C** Naast de deur (fout). Niet goed. Je hoort: “Elena zet de tas in de kast”. Daarom past “Naast de deur” niet. Het juiste antwoord is “In de kast”.

**Bewijs:** Elena zet de tas in de kast.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-001 | De afspraak morgen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Mina heeft een afspraak. Ze gaat morgen om tien uur naar de dokter. Ze zet de tijd in haar telefoon.
**Vraag:** Wanneer is de afspraak?

- **A** Vandaag om tien uur (fout). Niet goed. Je hoort: “Ze gaat morgen om tien uur naar de dokter”. Daarom past “Vandaag om tien uur” niet. Het juiste antwoord is “Morgen om tien uur”.
- **B** Morgen om twee uur (fout). Niet goed. Je hoort: “Ze gaat morgen om tien uur naar de dokter”. Daarom past “Morgen om twee uur” niet. Het juiste antwoord is “Morgen om tien uur”.
- **C** Morgen om tien uur (goed). Goed. Je hoort: “Ze gaat morgen om tien uur naar de dokter”. Daarom is “Morgen om tien uur” het juiste antwoord.

**Bewijs:** Ze gaat morgen om tien uur naar de dokter.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-002 | De blauwe trui

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Omar is in de kledingwinkel. Hij past een blauwe trui. De trui past goed.
**Vraag:** Welke trui kiest Omar?

- **A** De zwarte trui (fout). Niet goed. Je hoort: “Hij past een blauwe trui”. Daarom past “De zwarte trui” niet. Het juiste antwoord is “De blauwe trui”.
- **B** De blauwe trui (goed). Goed. Je hoort: “Hij past een blauwe trui”. Daarom is “De blauwe trui” het juiste antwoord.
- **C** De rode trui (fout). Niet goed. Je hoort: “Hij past een blauwe trui”. Daarom past “De rode trui” niet. Het juiste antwoord is “De blauwe trui”.

**Bewijs:** Hij past een blauwe trui.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-003 | De regen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Sara kijkt naar buiten. Het regent. Ze neemt haar paraplu mee naar het werk.
**Vraag:** Wat neemt Sara mee?

- **A** Een paraplu (goed). Goed. Je hoort: “Ze neemt haar paraplu mee naar het werk”. Daarom is “Een paraplu” het juiste antwoord.
- **B** Een zonnebril (fout). Niet goed. Je hoort: “Ze neemt haar paraplu mee naar het werk”. Daarom past “Een zonnebril” niet. Het juiste antwoord is “Een paraplu”.
- **C** Een boek (fout). Niet goed. Je hoort: “Ze neemt haar paraplu mee naar het werk”. Daarom past “Een boek” niet. Het juiste antwoord is “Een paraplu”.

**Bewijs:** Ze neemt haar paraplu mee naar het werk.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-004 | De bus naar het station

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Youssef wacht bij de halte. Bus 7 komt eraan. Die bus gaat naar het station.
**Vraag:** Waar gaat bus 7 naartoe?

- **A** Naar het ziekenhuis (fout). Niet goed. Je hoort: “Die bus gaat naar het station”. Daarom past “Naar het ziekenhuis” niet. Het juiste antwoord is “Naar het station”.
- **B** Naar de markt (fout). Niet goed. Je hoort: “Die bus gaat naar het station”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar het station”.
- **C** Naar het station (goed). Goed. Je hoort: “Die bus gaat naar het station”. Daarom is “Naar het station” het juiste antwoord.

**Bewijs:** Die bus gaat naar het station.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-005 | Twee kilo appels

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Mina staat op de markt. Ze koopt twee kilo appels. Daarna gaat ze naar huis.
**Vraag:** Hoeveel appels koopt Mina?

- **A** Drie kilo (fout). Niet goed. Je hoort: “Ze koopt twee kilo appels”. Daarom past “Drie kilo” niet. Het juiste antwoord is “Twee kilo”.
- **B** Twee kilo (goed). Goed. Je hoort: “Ze koopt twee kilo appels”. Daarom is “Twee kilo” het juiste antwoord.
- **C** Een kilo (fout). Niet goed. Je hoort: “Ze koopt twee kilo appels”. Daarom past “Een kilo” niet. Het juiste antwoord is “Twee kilo”.

**Bewijs:** Ze koopt twee kilo appels.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-006 | De les begint

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Nora gaat naar school. De les begint om negen uur. Ze is vijf minuten te vroeg.
**Vraag:** Hoe laat begint de les?

- **A** Om negen uur (goed). Goed. Je hoort: “De les begint om negen uur”. Daarom is “Om negen uur” het juiste antwoord.
- **B** Om acht uur (fout). Niet goed. Je hoort: “De les begint om negen uur”. Daarom past “Om acht uur” niet. Het juiste antwoord is “Om negen uur”.
- **C** Om tien uur (fout). Niet goed. Je hoort: “De les begint om negen uur”. Daarom past “Om tien uur” niet. Het juiste antwoord is “Om negen uur”.

**Bewijs:** De les begint om negen uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-007 | Het brood is op

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Ali wil ontbijten. Het brood is op. Hij loopt naar de bakker.
**Vraag:** Wat gaat Ali kopen?

- **A** Eieren (fout). Niet goed. Je hoort: “Het brood is op”. Daarom past “Eieren” niet. Het juiste antwoord is “Brood”.
- **B** Melk (fout). Niet goed. Je hoort: “Het brood is op”. Daarom past “Melk” niet. Het juiste antwoord is “Brood”.
- **C** Brood (goed). Goed. Je hoort: “Het brood is op”. Daarom is “Brood” het juiste antwoord.

**Bewijs:** Het brood is op.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-008 | Een fietsband

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Lina wil fietsen. Haar achterband is lek. Ze loopt met haar fiets naar de fietsenmaker.
**Vraag:** Wat is kapot?

- **A** Het stuur (fout). Niet goed. Je hoort: “Haar achterband is lek”. Daarom past “Het stuur” niet. Het juiste antwoord is “De achterband”.
- **B** De achterband (goed). Goed. Je hoort: “Haar achterband is lek”. Daarom is “De achterband” het juiste antwoord.
- **C** Het zadel (fout). Niet goed. Je hoort: “Haar achterband is lek”. Daarom past “Het zadel” niet. Het juiste antwoord is “De achterband”.

**Bewijs:** Haar achterband is lek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-009 | Een bericht van school

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Sam krijgt een bericht van school. Vrijdag is er geen les. Sam blijft die dag thuis.
**Vraag:** Wanneer is er geen les?

- **A** Vrijdag (goed). Goed. Je hoort: “Vrijdag is er geen les”. Daarom is “Vrijdag” het juiste antwoord.
- **B** Maandag (fout). Niet goed. Je hoort: “Vrijdag is er geen les”. Daarom past “Maandag” niet. Het juiste antwoord is “Vrijdag”.
- **C** Woensdag (fout). Niet goed. Je hoort: “Vrijdag is er geen les”. Daarom past “Woensdag” niet. Het juiste antwoord is “Vrijdag”.

**Bewijs:** Vrijdag is er geen les.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-text-question-010 | De tas in de kast

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Elena komt binnen. Ze zet haar tas in de kast. Daarna gaat ze aan tafel zitten.
**Vraag:** Waar staat de tas?

- **A** Onder de tafel (fout). Niet goed. Je hoort: “Ze zet haar tas in de kast”. Daarom past “Onder de tafel” niet. Het juiste antwoord is “In de kast”.
- **B** Naast de deur (fout). Niet goed. Je hoort: “Ze zet haar tas in de kast”. Daarom past “Naast de deur” niet. Het juiste antwoord is “In de kast”.
- **C** In de kast (goed). Goed. Je hoort: “Ze zet haar tas in de kast”. Daarom is “In de kast” het juiste antwoord.

**Bewijs:** Ze zet haar tas in de kast.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-001 | De afspraak morgen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Wanneer moet ik komen?
Assistent: Morgen om tien uur.
**Vraag:** Wanneer is de afspraak?

- **A** Morgen om twee uur (fout). Niet goed. Je hoort: “Morgen om tien uur”. Daarom past “Morgen om twee uur” niet. Het juiste antwoord is “Morgen om tien uur”.
- **B** Morgen om tien uur (goed). Goed. Je hoort: “Morgen om tien uur”. Daarom is “Morgen om tien uur” het juiste antwoord.
- **C** Vandaag om tien uur (fout). Niet goed. Je hoort: “Morgen om tien uur”. Daarom past “Vandaag om tien uur” niet. Het juiste antwoord is “Morgen om tien uur”.

**Bewijs:** Morgen om tien uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-002 | De blauwe trui

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Verkoper: Welke trui wil je?
Omar: De blauwe trui, graag.
**Vraag:** Welke trui kiest Omar?

- **A** De blauwe trui (goed). Goed. Je hoort: “De blauwe trui, graag”. Daarom is “De blauwe trui” het juiste antwoord.
- **B** De rode trui (fout). Niet goed. Je hoort: “De blauwe trui, graag”. Daarom past “De rode trui” niet. Het juiste antwoord is “De blauwe trui”.
- **C** De zwarte trui (fout). Niet goed. Je hoort: “De blauwe trui, graag”. Daarom past “De zwarte trui” niet. Het juiste antwoord is “De blauwe trui”.

**Bewijs:** De blauwe trui, graag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-003 | De regen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Ali: Regent het buiten?
Sara: Ja. Ik neem mijn paraplu mee.
**Vraag:** Wat neemt Sara mee?

- **A** Een zonnebril (fout). Niet goed. Je hoort: “Ik neem mijn paraplu mee”. Daarom past “Een zonnebril” niet. Het juiste antwoord is “Een paraplu”.
- **B** Een boek (fout). Niet goed. Je hoort: “Ik neem mijn paraplu mee”. Daarom past “Een boek” niet. Het juiste antwoord is “Een paraplu”.
- **C** Een paraplu (goed). Goed. Je hoort: “Ik neem mijn paraplu mee”. Daarom is “Een paraplu” het juiste antwoord.

**Bewijs:** Ik neem mijn paraplu mee.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-004 | De bus naar het station

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Youssef: Gaat bus 7 naar het station?
Chauffeur: Ja, dat klopt.
**Vraag:** Waar gaat bus 7 naartoe?

- **A** Naar de markt (fout). Niet goed. Je hoort: “Gaat bus 7 naar het station”. Daarom past “Naar de markt” niet. Het juiste antwoord is “Naar het station”.
- **B** Naar het station (goed). Goed. Je hoort: “Gaat bus 7 naar het station”. Daarom is “Naar het station” het juiste antwoord.
- **C** Naar het ziekenhuis (fout). Niet goed. Je hoort: “Gaat bus 7 naar het station”. Daarom past “Naar het ziekenhuis” niet. Het juiste antwoord is “Naar het station”.

**Bewijs:** Gaat bus 7 naar het station?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-005 | Twee kilo appels

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Verkoper: Hoeveel appels wilt u?
Mina: Twee kilo, graag.
**Vraag:** Hoeveel appels wil Mina kopen?

- **A** Twee kilo (goed). Goed. Je hoort: “Twee kilo, graag”. Daarom is “Twee kilo” het juiste antwoord.
- **B** Een kilo (fout). Niet goed. Je hoort: “Twee kilo, graag”. Daarom past “Een kilo” niet. Het juiste antwoord is “Twee kilo”.
- **C** Drie kilo (fout). Niet goed. Je hoort: “Twee kilo, graag”. Daarom past “Drie kilo” niet. Het juiste antwoord is “Twee kilo”.

**Bewijs:** Twee kilo, graag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-006 | De les begint

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Hoe laat begint de les?
Docent: Om negen uur.
**Vraag:** Hoe laat begint de les?

- **A** Om acht uur (fout). Niet goed. Je hoort: “Om negen uur”. Daarom past “Om acht uur” niet. Het juiste antwoord is “Om negen uur”.
- **B** Om tien uur (fout). Niet goed. Je hoort: “Om negen uur”. Daarom past “Om tien uur” niet. Het juiste antwoord is “Om negen uur”.
- **C** Om negen uur (goed). Goed. Je hoort: “Om negen uur”. Daarom is “Om negen uur” het juiste antwoord.

**Bewijs:** Om negen uur.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-007 | Het brood is op

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Is er nog brood?
Ali: Nee, ik ga brood kopen.
**Vraag:** Wat gaat Ali kopen?

- **A** Melk (fout). Niet goed. Je hoort: “Is er nog brood”. Daarom past “Melk” niet. Het juiste antwoord is “Brood”.
- **B** Brood (goed). Goed. Je hoort: “Is er nog brood”. Daarom is “Brood” het juiste antwoord.
- **C** Eieren (fout). Niet goed. Je hoort: “Is er nog brood”. Daarom past “Eieren” niet. Het juiste antwoord is “Brood”.

**Bewijs:** Is er nog brood?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-008 | Een fietsband

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Fietsenmaker: Wat is er kapot?
Lina: Mijn achterband is lek.
**Vraag:** Wat is kapot?

- **A** De achterband (goed). Goed. Je hoort: “Mijn achterband is lek”. Daarom is “De achterband” het juiste antwoord.
- **B** Het zadel (fout). Niet goed. Je hoort: “Mijn achterband is lek”. Daarom past “Het zadel” niet. Het juiste antwoord is “De achterband”.
- **C** Het stuur (fout). Niet goed. Je hoort: “Mijn achterband is lek”. Daarom past “Het stuur” niet. Het juiste antwoord is “De achterband”.

**Bewijs:** Mijn achterband is lek.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-009 | Een bericht van school

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Sam: Is er vrijdag les?
Docent: Nee, vrijdag is er geen les.
**Vraag:** Wanneer is er geen les?

- **A** Maandag (fout). Niet goed. Je hoort: “Is er vrijdag les”. Daarom past “Maandag” niet. Het juiste antwoord is “Vrijdag”.
- **B** Woensdag (fout). Niet goed. Je hoort: “Is er vrijdag les”. Daarom past “Woensdag” niet. Het juiste antwoord is “Vrijdag”.
- **C** Vrijdag (goed). Goed. Je hoort: “Is er vrijdag les”. Daarom is “Vrijdag” het juiste antwoord.

**Bewijs:** Is er vrijdag les?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-dialogue-question-010 | De tas in de kast

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Mina: Waar is je tas?
Elena: In de kast.
**Vraag:** Waar is de tas?

- **A** Naast de deur (fout). Niet goed. Je hoort: “In de kast”. Daarom past “Naast de deur” niet. Het juiste antwoord is “In de kast”.
- **B** In de kast (goed). Goed. Je hoort: “In de kast”. Daarom is “In de kast” het juiste antwoord.
- **C** Onder de tafel (fout). Niet goed. Je hoort: “In de kast”. Daarom past “Onder de tafel” niet. Het juiste antwoord is “In de kast”.

**Bewijs:** In de kast.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-001 | De afspraak morgen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Assistent: Kun je morgen om tien uur komen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, dat kan. (goed). Goed. Je hoort: “Kun je morgen om tien uur komen?” Met “Ja, dat kan” geef je een passend antwoord.
- **B** Ik heb nieuwe schoenen. (fout). Niet goed. Je hoort: “Kun je morgen om tien uur komen?” “Ik heb nieuwe schoenen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat kan”.
- **C** De winkel is groot. (fout). Niet goed. Je hoort: “Kun je morgen om tien uur komen?” “De winkel is groot” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat kan”.

**Bewijs:** Kun je morgen om tien uur komen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-002 | De blauwe trui

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Verkoper: Past de trui goed?
**Vraag:** Wat is een passende reactie?

- **A** Ik wil een brood. (fout). Niet goed. Je hoort: “Past de trui goed?” “Ik wil een brood” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, hij past goed”.
- **B** Het is dinsdag. (fout). Niet goed. Je hoort: “Past de trui goed?” “Het is dinsdag” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, hij past goed”.
- **C** Ja, hij past goed. (goed). Goed. Je hoort: “Past de trui goed?” Met “Ja, hij past goed” geef je een passend antwoord.

**Bewijs:** Past de trui goed?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-003 | De regen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Ali: Het regent hard. Heb je een paraplu?
**Vraag:** Wat is een passende reactie?

- **A** Dat is mijn stoel. (fout). Niet goed. Je hoort: “Heb je een paraplu?” “Dat is mijn stoel” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, die heb ik bij me”.
- **B** Ja, die heb ik bij me. (goed). Goed. Je hoort: “Heb je een paraplu?” Met “Ja, die heb ik bij me” geef je een passend antwoord.
- **C** Ik heb gisteren brood gekocht. (fout). Niet goed. Je hoort: “Heb je een paraplu?” “Ik heb gisteren brood gekocht” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, die heb ik bij me”.

**Bewijs:** Heb je een paraplu?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-004 | De bus naar het station

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Youssef: Gaat deze bus naar het station?
**Vraag:** Wat is een passende reactie?

- **A** Ja, stap maar in. (goed). Goed. Je hoort: “Gaat deze bus naar het station?” Met “Ja, stap maar in” geef je een passend antwoord.
- **B** Ik drink nu water. (fout). Niet goed. Je hoort: “Gaat deze bus naar het station?” “Ik drink nu water” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, stap maar in”.
- **C** Dat is een rode jas. (fout). Niet goed. Je hoort: “Gaat deze bus naar het station?” “Dat is een rode jas” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, stap maar in”.

**Bewijs:** Gaat deze bus naar het station?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-005 | Twee kilo appels

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Verkoper: Hoeveel appels wilt u?
**Vraag:** Wat is een passende reactie?

- **A** Ik kom met de bus. (fout). Niet goed. Je hoort: “Hoeveel appels wilt u?” “Ik kom met de bus” past niet bij deze vraag of opdracht. Een passende reactie is: “Twee kilo, graag”.
- **B** Mijn sleutel ligt thuis. (fout). Niet goed. Je hoort: “Hoeveel appels wilt u?” “Mijn sleutel ligt thuis” past niet bij deze vraag of opdracht. Een passende reactie is: “Twee kilo, graag”.
- **C** Twee kilo, graag. (goed). Goed. Je hoort: “Hoeveel appels wilt u?” Met “Twee kilo, graag” geef je een passend antwoord.

**Bewijs:** Hoeveel appels wilt u?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-006 | De les begint

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Docent: De les begint om negen uur. Kom je op tijd?
**Vraag:** Wat is een passende reactie?

- **A** Ik eet vandaag rijst. (fout). Niet goed. Je hoort: “Kom je op tijd?” “Ik eet vandaag rijst” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik ben er om negen uur”.
- **B** Ja, ik ben er om negen uur. (goed). Goed. Je hoort: “Kom je op tijd?” Met “Ja, ik ben er om negen uur” geef je een passend antwoord.
- **C** Mijn broek is blauw. (fout). Niet goed. Je hoort: “Kom je op tijd?” “Mijn broek is blauw” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik ben er om negen uur”.

**Bewijs:** Kom je op tijd?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-007 | Het brood is op

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Wil jij brood kopen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, dat doe ik. (goed). Goed. Je hoort: “Wil jij brood kopen?” Met “Ja, dat doe ik” geef je een passend antwoord.
- **B** Ik ga naar bed. (fout). Niet goed. Je hoort: “Wil jij brood kopen?” “Ik ga naar bed” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat doe ik”.
- **C** Mijn stoel is rood. (fout). Niet goed. Je hoort: “Wil jij brood kopen?” “Mijn stoel is rood” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dat doe ik”.

**Bewijs:** Wil jij brood kopen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-008 | Een fietsband

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Fietsenmaker: Kan ik je helpen?
**Vraag:** Wat is een passende reactie?

- **A** Mijn zus woont ver weg. (fout). Niet goed. Je hoort: “Kan ik je helpen?” “Mijn zus woont ver weg” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, mijn band is lek”.
- **B** Vandaag eet ik soep. (fout). Niet goed. Je hoort: “Kan ik je helpen?” “Vandaag eet ik soep” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, mijn band is lek”.
- **C** Ja, mijn band is lek. (goed). Goed. Je hoort: “Kan ik je helpen?” Met “Ja, mijn band is lek” geef je een passend antwoord.

**Bewijs:** Kan ik je helpen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-009 | Een bericht van school

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Docent: Vrijdag is er geen les. Heb je dat gelezen?
**Vraag:** Wat is een passende reactie?

- **A** Ik heb nieuwe schoenen. (fout). Niet goed. Je hoort: “Heb je dat gelezen?” “Ik heb nieuwe schoenen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik heb het bericht gezien”.
- **B** Ja, ik heb het bericht gezien. (goed). Goed. Je hoort: “Heb je dat gelezen?” Met “Ja, ik heb het bericht gezien” geef je een passend antwoord.
- **C** Ik zoek een appel. (fout). Niet goed. Je hoort: “Heb je dat gelezen?” “Ik zoek een appel” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik heb het bericht gezien”.

**Bewijs:** Heb je dat gelezen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-AB-suitable-reply-010 | De tas in de kast

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Mina: Waar heb je de tas gezet?
**Vraag:** Wat is een passende reactie?

- **A** In de kast. (goed). Goed. Je hoort: “Waar heb je de tas gezet?” Met “In de kast” geef je een passend antwoord.
- **B** Ik ga om tien uur. (fout). Niet goed. Je hoort: “Waar heb je de tas gezet?” “Ik ga om tien uur” past niet bij deze vraag of opdracht. Een passende reactie is: “In de kast”.
- **C** Het is mooi weer. (fout). Niet goed. Je hoort: “Waar heb je de tas gezet?” “Het is mooi weer” past niet bij deze vraag of opdracht. Een passende reactie is: “In de kast”.

**Bewijs:** Waar heb je de tas gezet?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
