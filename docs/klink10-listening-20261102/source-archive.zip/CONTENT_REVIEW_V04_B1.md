# KLINK Luisteren | V0.4 | B1

40 AI-gereviewde kandidaatopdrachten. Status AUDIO/ERK/RUNTIME: HOLD.

## KLINK-LUI-P01-B1-understand-001 | Wijziging bij een sollicitatie

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het sollicitatiegesprek van dinsdag is verplaatst naar donderdag omdat de leidinggevende ziek is.
**Vraag:** Op welke dag vindt het gesprek nu plaats?

- **A** Donderdag (goed). Goed. Je hoort: “Het sollicitatiegesprek van dinsdag is verplaatst naar donderdag omdat de leidinggevende ziek is”. Daarom is “Donderdag” het juiste antwoord.
- **B** Dinsdag (fout). Niet goed. Je hoort: “Het sollicitatiegesprek van dinsdag is verplaatst naar donderdag omdat de leidinggevende ziek is”. Daarom past “Dinsdag” niet. Het juiste antwoord is “Donderdag”.
- **C** Vrijdag (fout). Niet goed. Je hoort: “Het sollicitatiegesprek van dinsdag is verplaatst naar donderdag omdat de leidinggevende ziek is”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Donderdag”.

**Bewijs:** Het sollicitatiegesprek van dinsdag is verplaatst naar donderdag omdat de leidinggevende ziek is.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-002 | Een storing melden

**Oefenvorm:** Luister en kies
**Gesproken bron:** Het bestelsysteem heeft een storing. Daarom noteren we aanvragen voorlopig op papier.
**Vraag:** Waarom worden aanvragen op papier genoteerd?

- **A** Omdat de printer kapot is (fout). Niet goed. Je hoort: “Het bestelsysteem heeft een storing”. Daarom past “Omdat de printer kapot is” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.
- **B** Omdat er geen klanten zijn (fout). Niet goed. Je hoort: “Het bestelsysteem heeft een storing”. Daarom past “Omdat er geen klanten zijn” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.
- **C** Omdat het systeem een storing heeft (goed). Goed. Je hoort: “Het bestelsysteem heeft een storing”. Daarom is “Omdat het systeem een storing heeft” het juiste antwoord.

**Bewijs:** Het bestelsysteem heeft een storing.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-003 | De woninginspectie

**Oefenvorm:** Luister en kies
**Gesproken bron:** De verhuurder onderzoekt eerst waar het vocht vandaan komt. Daarna beslist hij of de muur gerepareerd moet worden.
**Vraag:** Wat gebeurt er eerst?

- **A** De vloer vervangen (fout). Niet goed. Je hoort: “De verhuurder onderzoekt eerst waar het vocht vandaan komt”. Daarom past “De vloer vervangen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.
- **B** Onderzoeken waar het vocht vandaan komt (goed). Goed. Je hoort: “De verhuurder onderzoekt eerst waar het vocht vandaan komt”. Daarom is “Onderzoeken waar het vocht vandaan komt” het juiste antwoord.
- **C** De muur meteen schilderen (fout). Niet goed. Je hoort: “De verhuurder onderzoekt eerst waar het vocht vandaan komt”. Daarom past “De muur meteen schilderen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.

**Bewijs:** De verhuurder onderzoekt eerst waar het vocht vandaan komt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-004 | De verkeerde levering

**Oefenvorm:** Luister en kies
**Gesproken bron:** De winkel had vier grote dozen besteld, maar er zijn zes kleine dozen geleverd.
**Vraag:** Wat is er mis met de levering?

- **A** Er zijn zes kleine dozen geleverd in plaats van vier grote (goed). Goed. Je hoort: “De winkel had vier grote dozen besteld, maar er zijn zes kleine dozen geleverd”. Daarom is “Er zijn zes kleine dozen geleverd in plaats van vier grote” het juiste antwoord.
- **B** Er ontbreken zes grote dozen bij een bestelling van vier kleine (fout). Niet goed. Je hoort: “De winkel had vier grote dozen besteld, maar er zijn zes kleine dozen geleverd”. Daarom past “Er ontbreken zes grote dozen bij een bestelling van vier kleine” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.
- **C** De dozen zijn allemaal beschadigd (fout). Niet goed. Je hoort: “De winkel had vier grote dozen besteld, maar er zijn zes kleine dozen geleverd”. Daarom past “De dozen zijn allemaal beschadigd” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.

**Bewijs:** De winkel had vier grote dozen besteld, maar er zijn zes kleine dozen geleverd.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-005 | De aangepaste busroute

**Oefenvorm:** Luister en kies
**Gesproken bron:** Door wegwerkzaamheden stopt bus 23 deze week niet bij het ziekenhuis, maar bij het plein ernaast.
**Vraag:** Waar moeten reizigers deze week uitstappen?

- **A** Bij de gewone halte voor het ziekenhuis (fout). Niet goed. Je hoort: “Door wegwerkzaamheden stopt bus 23 deze week niet bij het ziekenhuis, maar bij het plein ernaast”. Daarom past “Bij de gewone halte voor het ziekenhuis” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.
- **B** Bij het station (fout). Niet goed. Je hoort: “Door wegwerkzaamheden stopt bus 23 deze week niet bij het ziekenhuis, maar bij het plein ernaast”. Daarom past “Bij het station” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.
- **C** Bij het plein naast het ziekenhuis (goed). Goed. Je hoort: “Door wegwerkzaamheden stopt bus 23 deze week niet bij het ziekenhuis, maar bij het plein ernaast”. Daarom is “Bij het plein naast het ziekenhuis” het juiste antwoord.

**Bewijs:** Door wegwerkzaamheden stopt bus 23 deze week niet bij het ziekenhuis, maar bij het plein ernaast.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-006 | Een taak verdelen

**Oefenvorm:** Luister en kies
**Gesproken bron:** Omdat de levering later komt, begint het team eerst met het controleren van de voorraad.
**Vraag:** Wat doet het team eerst?

- **A** Het magazijn afsluiten (fout). Niet goed. Je hoort: “Omdat de levering later komt, begint het team eerst met het controleren van de voorraad”. Daarom past “Het magazijn afsluiten” niet. Het juiste antwoord is “De voorraad controleren”.
- **B** De voorraad controleren (goed). Goed. Je hoort: “Omdat de levering later komt, begint het team eerst met het controleren van de voorraad”. Daarom is “De voorraad controleren” het juiste antwoord.
- **C** De vrachtwagen uitladen (fout). Niet goed. Je hoort: “Omdat de levering later komt, begint het team eerst met het controleren van de voorraad”. Daarom past “De vrachtwagen uitladen” niet. Het juiste antwoord is “De voorraad controleren”.

**Bewijs:** Omdat de levering later komt, begint het team eerst met het controleren van de voorraad.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-007 | De cursusvoorwaarden

**Oefenvorm:** Luister en kies
**Gesproken bron:** Je krijgt het lesgeld alleen terug als je je minstens een week voor de eerste les afmeldt.
**Vraag:** Wanneer krijg je volgens de voorwaarden het lesgeld terug?

- **A** Als je je minstens een week voor de start afmeldt (goed). Goed. Je hoort: “Je krijgt het lesgeld alleen terug als je je minstens een week voor de eerste les afmeldt”. Daarom is “Als je je minstens een week voor de start afmeldt” het juiste antwoord.
- **B** Als je je drie dagen voor de start afmeldt (fout). Niet goed. Je hoort: “Je krijgt het lesgeld alleen terug als je je minstens een week voor de eerste les afmeldt”. Daarom past “Als je je drie dagen voor de start afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.
- **C** Als je na de eerste les afmeldt (fout). Niet goed. Je hoort: “Je krijgt het lesgeld alleen terug als je je minstens een week voor de eerste les afmeldt”. Daarom past “Als je na de eerste les afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.

**Bewijs:** Je krijgt het lesgeld alleen terug als je je minstens een week voor de eerste les afmeldt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-008 | Een afspraak bij de gemeente

**Oefenvorm:** Luister en kies
**Gesproken bron:** Youssef wil zijn document ophalen. Daarom moet hij eerst online een afspraak maken. Zonder afspraak wordt hij niet geholpen.
**Vraag:** Wat moet Youssef eerst doen?

- **A** Zonder afspraak naar het loket gaan (fout). Niet goed. Je hoort: “Daarom moet hij eerst online een afspraak maken”. Daarom past “Zonder afspraak naar het loket gaan” niet. Het juiste antwoord is “Online een afspraak maken”.
- **B** Een nieuw document aanvragen (fout). Niet goed. Je hoort: “Daarom moet hij eerst online een afspraak maken”. Daarom past “Een nieuw document aanvragen” niet. Het juiste antwoord is “Online een afspraak maken”.
- **C** Online een afspraak maken (goed). Goed. Je hoort: “Daarom moet hij eerst online een afspraak maken”. Daarom is “Online een afspraak maken” het juiste antwoord.

**Bewijs:** Daarom moet hij eerst online een afspraak maken.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-009 | Samenwerken na een fout

**Oefenvorm:** Luister en kies
**Gesproken bron:** Na een verkeerde bestelling spreekt het team af om zowel het ordernummer als het product te controleren.
**Vraag:** Wat spreekt het team af?

- **A** Voortaan geen bestellingen meer aannemen (fout). Niet goed. Je hoort: “Na een verkeerde bestelling spreekt het team af om zowel het ordernummer als het product te controleren”. Daarom past “Voortaan geen bestellingen meer aannemen” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.
- **B** Zowel ordernummer als product controleren (goed). Goed. Je hoort: “Na een verkeerde bestelling spreekt het team af om zowel het ordernummer als het product te controleren”. Daarom is “Zowel ordernummer als product controleren” het juiste antwoord.
- **C** Alleen de verpakking controleren (fout). Niet goed. Je hoort: “Na een verkeerde bestelling spreekt het team af om zowel het ordernummer als het product te controleren”. Daarom past “Alleen de verpakking controleren” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.

**Bewijs:** Na een verkeerde bestelling spreekt het team af om zowel het ordernummer als het product te controleren.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-understand-010 | Een medische afspraak aanpassen

**Oefenvorm:** Luister en kies
**Gesproken bron:** De arts beslist of de controle telefonisch kan plaatsvinden, nadat hij heeft bekeken of lichamelijk onderzoek nodig is.
**Vraag:** Wie beslist of de afspraak telefonisch kan?

- **A** De arts (goed). Goed. Je hoort: “De arts beslist of de controle telefonisch kan plaatsvinden, nadat hij heeft bekeken of lichamelijk onderzoek nodig is”. Daarom is “De arts” het juiste antwoord.
- **B** De receptionist alleen (fout). Niet goed. Je hoort: “De arts beslist of de controle telefonisch kan plaatsvinden, nadat hij heeft bekeken of lichamelijk onderzoek nodig is”. Daarom past “De receptionist alleen” niet. Het juiste antwoord is “De arts”.
- **C** De patiënt zonder overleg (fout). Niet goed. Je hoort: “De arts beslist of de controle telefonisch kan plaatsvinden, nadat hij heeft bekeken of lichamelijk onderzoek nodig is”. Daarom past “De patiënt zonder overleg” niet. Het juiste antwoord is “De arts”.

**Bewijs:** De arts beslist of de controle telefonisch kan plaatsvinden, nadat hij heeft bekeken of lichamelijk onderzoek nodig is.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-001 | Wijziging bij een sollicitatie

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Samira heeft dinsdag een sollicitatiegesprek. Op maandag ontvangt ze een bericht: de leidinggevende is ziek. Het gesprek wordt verplaatst naar donderdag. Samira past haar agenda aan.
**Vraag:** Op welke dag vindt het gesprek nu plaats?

- **A** Dinsdag (fout). Niet goed. Je hoort: “Het gesprek wordt verplaatst naar donderdag”. Daarom past “Dinsdag” niet. Het juiste antwoord is “Donderdag”.
- **B** Vrijdag (fout). Niet goed. Je hoort: “Het gesprek wordt verplaatst naar donderdag”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Donderdag”.
- **C** Donderdag (goed). Goed. Je hoort: “Het gesprek wordt verplaatst naar donderdag”. Daarom is “Donderdag” het juiste antwoord.

**Bewijs:** Het gesprek wordt verplaatst naar donderdag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-002 | Een storing melden

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Bij een bedrijf valt het bestelsysteem uit. De medewerkers kunnen de bestellingen niet verwerken. De technische dienst onderzoekt het probleem. Tot het systeem werkt, schrijven de medewerkers de aanvragen op papier.
**Vraag:** Waarom worden aanvragen op papier genoteerd?

- **A** Omdat er geen klanten zijn (fout). Niet goed. Je hoort: “Tot het systeem werkt, schrijven de medewerkers de aanvragen op papier”. Daarom past “Omdat er geen klanten zijn” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.
- **B** Omdat het systeem een storing heeft (goed). Goed. Je hoort: “Tot het systeem werkt, schrijven de medewerkers de aanvragen op papier”. Daarom is “Omdat het systeem een storing heeft” het juiste antwoord.
- **C** Omdat de printer kapot is (fout). Niet goed. Je hoort: “Tot het systeem werkt, schrijven de medewerkers de aanvragen op papier”. Daarom past “Omdat de printer kapot is” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.

**Bewijs:** Tot het systeem werkt, schrijven de medewerkers de aanvragen op papier.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-003 | De woninginspectie

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Nora ziet een vochtplek in de slaapkamer en meldt dat bij de verhuurder. Er komt eerst een medewerker kijken waar het vocht vandaan komt. Daarna beslist de verhuurder welke reparatie nodig is. Nora krijgt later een bericht over de vervolgstappen.
**Vraag:** Wat gebeurt er eerst?

- **A** Onderzoeken waar het vocht vandaan komt (goed). Goed. Je hoort: “Er komt eerst een medewerker kijken waar het vocht vandaan komt”. Daarom is “Onderzoeken waar het vocht vandaan komt” het juiste antwoord.
- **B** De muur meteen schilderen (fout). Niet goed. Je hoort: “Er komt eerst een medewerker kijken waar het vocht vandaan komt”. Daarom past “De muur meteen schilderen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.
- **C** De vloer vervangen (fout). Niet goed. Je hoort: “Er komt eerst een medewerker kijken waar het vocht vandaan komt”. Daarom past “De vloer vervangen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.

**Bewijs:** Er komt eerst een medewerker kijken waar het vocht vandaan komt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-004 | De verkeerde levering

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Een winkel ontvangt zes kleine dozen, maar had vier grote dozen besteld. De medewerker controleert de afleverbon, maakt foto’s en neemt contact op met de leverancier. Tot er duidelijkheid is, zet ze de levering apart.
**Vraag:** Wat is er mis met de levering?

- **A** Er ontbreken zes grote dozen bij een bestelling van vier kleine (fout). Niet goed. Je hoort: “Een winkel ontvangt zes kleine dozen, maar had vier grote dozen besteld”. Daarom past “Er ontbreken zes grote dozen bij een bestelling van vier kleine” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.
- **B** De dozen zijn allemaal beschadigd (fout). Niet goed. Je hoort: “Een winkel ontvangt zes kleine dozen, maar had vier grote dozen besteld”. Daarom past “De dozen zijn allemaal beschadigd” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.
- **C** Er zijn zes kleine dozen geleverd in plaats van vier grote (goed). Goed. Je hoort: “Een winkel ontvangt zes kleine dozen, maar had vier grote dozen besteld”. Daarom is “Er zijn zes kleine dozen geleverd in plaats van vier grote” het juiste antwoord.

**Bewijs:** Een winkel ontvangt zes kleine dozen, maar had vier grote dozen besteld.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-005 | De aangepaste busroute

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Door wegwerkzaamheden verandert de route van bus 23 tijdelijk. Deze week rijdt de bus niet langs de halte bij het ziekenhuis. Reizigers moeten uitstappen op het plein ernaast en vijf minuten lopen. Volgende week wordt de oude route hervat.
**Vraag:** Waar moeten reizigers deze week uitstappen?

- **A** Bij het station (fout). Niet goed. Je hoort: “Deze week rijdt de bus niet langs de halte bij het ziekenhuis”. Daarom past “Bij het station” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.
- **B** Bij het plein naast het ziekenhuis (goed). Goed. Je hoort: “Deze week rijdt de bus niet langs de halte bij het ziekenhuis”. Daarom is “Bij het plein naast het ziekenhuis” het juiste antwoord.
- **C** Bij de gewone halte voor het ziekenhuis (fout). Niet goed. Je hoort: “Deze week rijdt de bus niet langs de halte bij het ziekenhuis”. Daarom past “Bij de gewone halte voor het ziekenhuis” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.

**Bewijs:** Deze week rijdt de bus niet langs de halte bij het ziekenhuis.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-006 | Een taak verdelen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Het magazijn verwacht om negen uur een levering, maar de vrachtwagen komt pas om elf uur. De teamleider verandert de planning. Twee medewerkers controleren eerst de voorraad. Wanneer de vrachtwagen aankomt, helpen ze bij het uitladen.
**Vraag:** Wat doet het team eerst?

- **A** De voorraad controleren (goed). Goed. Je hoort: “Twee medewerkers controleren eerst de voorraad”. Daarom is “De voorraad controleren” het juiste antwoord.
- **B** De vrachtwagen uitladen (fout). Niet goed. Je hoort: “Twee medewerkers controleren eerst de voorraad”. Daarom past “De vrachtwagen uitladen” niet. Het juiste antwoord is “De voorraad controleren”.
- **C** Het magazijn afsluiten (fout). Niet goed. Je hoort: “Twee medewerkers controleren eerst de voorraad”. Daarom past “Het magazijn afsluiten” niet. Het juiste antwoord is “De voorraad controleren”.

**Bewijs:** Twee medewerkers controleren eerst de voorraad.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-007 | De cursusvoorwaarden

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Elena schrijft zich in voor een cursus. In de voorwaarden staat dat zij het lesgeld terugkrijgt als zij zich minstens een week voor de start afmeldt. Drie dagen voor de start wil ze toch stoppen. Ze belt de administratie om te vragen wat mogelijk is.
**Vraag:** Wanneer krijg je volgens de voorwaarden het lesgeld terug?

- **A** Als je je drie dagen voor de start afmeldt (fout). Niet goed. Je hoort: “In de voorwaarden staat dat zij het lesgeld terugkrijgt als zij zich minstens een week voor de start afmeldt”. Daarom past “Als je je drie dagen voor de start afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.
- **B** Als je na de eerste les afmeldt (fout). Niet goed. Je hoort: “In de voorwaarden staat dat zij het lesgeld terugkrijgt als zij zich minstens een week voor de start afmeldt”. Daarom past “Als je na de eerste les afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.
- **C** Als je je minstens een week voor de start afmeldt (goed). Goed. Je hoort: “In de voorwaarden staat dat zij het lesgeld terugkrijgt als zij zich minstens een week voor de start afmeldt”. Daarom is “Als je je minstens een week voor de start afmeldt” het juiste antwoord.

**Bewijs:** In de voorwaarden staat dat zij het lesgeld terugkrijgt als zij zich minstens een week voor de start afmeldt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-008 | Een afspraak bij de gemeente

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Youssef heeft bericht gekregen dat zijn document klaar is. Hij wil het meteen ophalen, maar op de website staat dat een afspraak verplicht is. Hij kiest online een tijdstip voor vrijdag. Daarna ontvangt hij een bevestiging per e-mail.
**Vraag:** Wat moet Youssef eerst doen?

- **A** Een nieuw document aanvragen (fout). Niet goed. Je hoort: “Hij kiest online een tijdstip voor vrijdag”. Daarom past “Een nieuw document aanvragen” niet. Het juiste antwoord is “Online een afspraak maken”.
- **B** Online een afspraak maken (goed). Goed. Je hoort: “Hij kiest online een tijdstip voor vrijdag”. Daarom is “Online een afspraak maken” het juiste antwoord.
- **C** Zonder afspraak naar het loket gaan (fout). Niet goed. Je hoort: “Hij kiest online een tijdstip voor vrijdag”. Daarom past “Zonder afspraak naar het loket gaan” niet. Het juiste antwoord is “Online een afspraak maken”.

**Bewijs:** Hij kiest online een tijdstip voor vrijdag.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-009 | Samenwerken na een fout

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Een klant krijgt een verkeerd product. De medewerkers onderzoeken hoe dat kon gebeuren. Ze ontdekken dat het ordernummer niet is gecontroleerd. Het team spreekt af om bij volgende bestellingen zowel het nummer als het product te controleren.
**Vraag:** Wat spreekt het team af?

- **A** Zowel ordernummer als product controleren (goed). Goed. Je hoort: “Het team spreekt af om bij volgende bestellingen zowel het nummer als het product te controleren”. Daarom is “Zowel ordernummer als product controleren” het juiste antwoord.
- **B** Alleen de verpakking controleren (fout). Niet goed. Je hoort: “Het team spreekt af om bij volgende bestellingen zowel het nummer als het product te controleren”. Daarom past “Alleen de verpakking controleren” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.
- **C** Voortaan geen bestellingen meer aannemen (fout). Niet goed. Je hoort: “Het team spreekt af om bij volgende bestellingen zowel het nummer als het product te controleren”. Daarom past “Voortaan geen bestellingen meer aannemen” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.

**Bewijs:** Het team spreekt af om bij volgende bestellingen zowel het nummer als het product te controleren.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-text-question-010 | Een medische afspraak aanpassen

**Oefenvorm:** Begrijp het verhaal
**Gesproken bron:** Fatima heeft een controleafspraak in het ziekenhuis. Ze vraagt of ze daarvoor moet reizen. De medewerker legt uit dat een telefonisch gesprek mogelijk is wanneer lichamelijk onderzoek niet nodig is. De arts moet eerst beoordelen of dat voor haar geldt.
**Vraag:** Wie beslist of de afspraak telefonisch kan?

- **A** De receptionist alleen (fout). Niet goed. Je hoort: “De arts moet eerst beoordelen of dat voor haar geldt”. Daarom past “De receptionist alleen” niet. Het juiste antwoord is “De arts”.
- **B** De patiënt zonder overleg (fout). Niet goed. Je hoort: “De arts moet eerst beoordelen of dat voor haar geldt”. Daarom past “De patiënt zonder overleg” niet. Het juiste antwoord is “De arts”.
- **C** De arts (goed). Goed. Je hoort: “De arts moet eerst beoordelen of dat voor haar geldt”. Daarom is “De arts” het juiste antwoord.

**Bewijs:** De arts moet eerst beoordelen of dat voor haar geldt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-001 | Wijziging bij een sollicitatie

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Samira: Ik had dinsdag een gesprek, maar ik kreeg een wijziging.
Medewerker: Dat klopt. De leidinggevende is ziek.
Samira: Dus ik kom donderdag?
Medewerker: Ja, op hetzelfde tijdstip.
**Vraag:** Op welke dag vindt het gesprek nu plaats?

- **A** Vrijdag (fout). Niet goed. Je hoort: “Dus ik kom donderdag”. Daarom past “Vrijdag” niet. Het juiste antwoord is “Donderdag”.
- **B** Donderdag (goed). Goed. Je hoort: “Dus ik kom donderdag”. Daarom is “Donderdag” het juiste antwoord.
- **C** Dinsdag (fout). Niet goed. Je hoort: “Dus ik kom donderdag”. Daarom past “Dinsdag” niet. Het juiste antwoord is “Donderdag”.

**Bewijs:** Dus ik kom donderdag?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-002 | Een storing melden

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Medewerker: De bestellingen komen niet meer binnen.
Teamleider: Het systeem heeft een storing.
Medewerker: Wat doen we voorlopig?
Teamleider: We noteren de aanvragen op papier.
**Vraag:** Waarom worden aanvragen op papier genoteerd?

- **A** Omdat het systeem een storing heeft (goed). Goed. Je hoort: “Het systeem heeft een storing”. Daarom is “Omdat het systeem een storing heeft” het juiste antwoord.
- **B** Omdat de printer kapot is (fout). Niet goed. Je hoort: “Het systeem heeft een storing”. Daarom past “Omdat de printer kapot is” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.
- **C** Omdat er geen klanten zijn (fout). Niet goed. Je hoort: “Het systeem heeft een storing”. Daarom past “Omdat er geen klanten zijn” niet. Het juiste antwoord is “Omdat het systeem een storing heeft”.

**Bewijs:** Het systeem heeft een storing.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-003 | De woninginspectie

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Nora: Wanneer wordt de muur gerepareerd?
Verhuurder: Eerst onderzoeken we waar het vocht vandaan komt.
Nora: En daarna?
Verhuurder: Daarna plannen we zo nodig een reparatie.
**Vraag:** Wat gebeurt er eerst?

- **A** De muur meteen schilderen (fout). Niet goed. Je hoort: “Eerst onderzoeken we waar het vocht vandaan komt”. Daarom past “De muur meteen schilderen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.
- **B** De vloer vervangen (fout). Niet goed. Je hoort: “Eerst onderzoeken we waar het vocht vandaan komt”. Daarom past “De vloer vervangen” niet. Het juiste antwoord is “Onderzoeken waar het vocht vandaan komt”.
- **C** Onderzoeken waar het vocht vandaan komt (goed). Goed. Je hoort: “Eerst onderzoeken we waar het vocht vandaan komt”. Daarom is “Onderzoeken waar het vocht vandaan komt” het juiste antwoord.

**Bewijs:** Eerst onderzoeken we waar het vocht vandaan komt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-004 | De verkeerde levering

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Medewerker: We hebben niet gekregen wat we besteld hebben.
Leverancier: Wat is er anders?
Medewerker: Zes kleine dozen in plaats van vier grote.
Leverancier: Stuur alstublieft de foto’s mee.
**Vraag:** Wat is er mis met de levering?

- **A** De dozen zijn allemaal beschadigd (fout). Niet goed. Je hoort: “Zes kleine dozen in plaats van vier grote”. Daarom past “De dozen zijn allemaal beschadigd” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.
- **B** Er zijn zes kleine dozen geleverd in plaats van vier grote (goed). Goed. Je hoort: “Zes kleine dozen in plaats van vier grote”. Daarom is “Er zijn zes kleine dozen geleverd in plaats van vier grote” het juiste antwoord.
- **C** Er ontbreken zes grote dozen bij een bestelling van vier kleine (fout). Niet goed. Je hoort: “Zes kleine dozen in plaats van vier grote”. Daarom past “Er ontbreken zes grote dozen bij een bestelling van vier kleine” niet. Het juiste antwoord is “Er zijn zes kleine dozen geleverd in plaats van vier grote”.

**Bewijs:** Zes kleine dozen in plaats van vier grote.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-005 | De aangepaste busroute

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Reiziger: Stopt bus 23 nog bij het ziekenhuis?
Chauffeur: Deze week niet, door werkzaamheden.
Reiziger: Waar kan ik uitstappen?
Chauffeur: Bij het plein ernaast.
**Vraag:** Waar moeten reizigers deze week uitstappen?

- **A** Bij het plein naast het ziekenhuis (goed). Goed. Je hoort: “Bij het plein ernaast”. Daarom is “Bij het plein naast het ziekenhuis” het juiste antwoord.
- **B** Bij de gewone halte voor het ziekenhuis (fout). Niet goed. Je hoort: “Bij het plein ernaast”. Daarom past “Bij de gewone halte voor het ziekenhuis” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.
- **C** Bij het station (fout). Niet goed. Je hoort: “Bij het plein ernaast”. Daarom past “Bij het station” niet. Het juiste antwoord is “Bij het plein naast het ziekenhuis”.

**Bewijs:** Bij het plein ernaast.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-006 | Een taak verdelen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Teamleider: De vrachtwagen komt twee uur later.
Medewerker: Wat zullen we nu doen?
Teamleider: Controleer eerst de voorraad.
Medewerker: Daarna help ik met uitladen.
**Vraag:** Wat doet het team eerst?

- **A** De vrachtwagen uitladen (fout). Niet goed. Je hoort: “Controleer eerst de voorraad”. Daarom past “De vrachtwagen uitladen” niet. Het juiste antwoord is “De voorraad controleren”.
- **B** Het magazijn afsluiten (fout). Niet goed. Je hoort: “Controleer eerst de voorraad”. Daarom past “Het magazijn afsluiten” niet. Het juiste antwoord is “De voorraad controleren”.
- **C** De voorraad controleren (goed). Goed. Je hoort: “Controleer eerst de voorraad”. Daarom is “De voorraad controleren” het juiste antwoord.

**Bewijs:** Controleer eerst de voorraad.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-007 | De cursusvoorwaarden

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Elena: Ik wil me afmelden. Krijg ik mijn lesgeld terug?
Medewerker: Alleen als u zich minstens een week voor de start afmeldt.
Elena: De cursus begint over drie dagen.
Medewerker: Dan bent u helaas te laat voor terugbetaling.
**Vraag:** Wanneer krijg je volgens de voorwaarden het lesgeld terug?

- **A** Als je na de eerste les afmeldt (fout). Niet goed. Je hoort: “Alleen als u zich minstens een week voor de start afmeldt”. Daarom past “Als je na de eerste les afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.
- **B** Als je je minstens een week voor de start afmeldt (goed). Goed. Je hoort: “Alleen als u zich minstens een week voor de start afmeldt”. Daarom is “Als je je minstens een week voor de start afmeldt” het juiste antwoord.
- **C** Als je je drie dagen voor de start afmeldt (fout). Niet goed. Je hoort: “Alleen als u zich minstens een week voor de start afmeldt”. Daarom past “Als je je drie dagen voor de start afmeldt” niet. Het juiste antwoord is “Als je je minstens een week voor de start afmeldt”.

**Bewijs:** Alleen als u zich minstens een week voor de start afmeldt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-008 | Een afspraak bij de gemeente

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Youssef: Mijn document is klaar. Kan ik het vandaag ophalen?
Medewerker: Alleen als u een afspraak heeft.
Youssef: Dan reserveer ik online een tijd.
Medewerker: Neem de bevestiging mee.
**Vraag:** Wat moet Youssef eerst doen?

- **A** Online een afspraak maken (goed). Goed. Je hoort: “Alleen als u een afspraak heeft”. Daarom is “Online een afspraak maken” het juiste antwoord.
- **B** Zonder afspraak naar het loket gaan (fout). Niet goed. Je hoort: “Alleen als u een afspraak heeft”. Daarom past “Zonder afspraak naar het loket gaan” niet. Het juiste antwoord is “Online een afspraak maken”.
- **C** Een nieuw document aanvragen (fout). Niet goed. Je hoort: “Alleen als u een afspraak heeft”. Daarom past “Een nieuw document aanvragen” niet. Het juiste antwoord is “Online een afspraak maken”.

**Bewijs:** Alleen als u een afspraak heeft.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-009 | Samenwerken na een fout

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Teamleider: De klant kreeg het verkeerde product.
Medewerker: Het ordernummer is niet gecontroleerd.
Teamleider: Hoe voorkomen we dit?
Medewerker: We controleren voortaan nummer én product.
**Vraag:** Wat spreekt het team af?

- **A** Alleen de verpakking controleren (fout). Niet goed. Je hoort: “We controleren voortaan nummer én product”. Daarom past “Alleen de verpakking controleren” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.
- **B** Voortaan geen bestellingen meer aannemen (fout). Niet goed. Je hoort: “We controleren voortaan nummer én product”. Daarom past “Voortaan geen bestellingen meer aannemen” niet. Het juiste antwoord is “Zowel ordernummer als product controleren”.
- **C** Zowel ordernummer als product controleren (goed). Goed. Je hoort: “We controleren voortaan nummer én product”. Daarom is “Zowel ordernummer als product controleren” het juiste antwoord.

**Bewijs:** We controleren voortaan nummer én product.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-dialogue-question-010 | Een medische afspraak aanpassen

**Oefenvorm:** Begrijp het gesprek
**Gesproken bron:** Fatima: Moet ik voor de controle naar het ziekenhuis komen?
Medewerker: Misschien niet. Een telefonisch gesprek kan soms ook.
Fatima: Wie beslist dat?
Medewerker: De arts beoordeelt of onderzoek nodig is.
**Vraag:** Wie beslist of de afspraak telefonisch kan?

- **A** De patiënt zonder overleg (fout). Niet goed. Je hoort: “De arts beoordeelt of onderzoek nodig is”. Daarom past “De patiënt zonder overleg” niet. Het juiste antwoord is “De arts”.
- **B** De arts (goed). Goed. Je hoort: “De arts beoordeelt of onderzoek nodig is”. Daarom is “De arts” het juiste antwoord.
- **C** De receptionist alleen (fout). Niet goed. Je hoort: “De arts beoordeelt of onderzoek nodig is”. Daarom past “De receptionist alleen” niet. Het juiste antwoord is “De arts”.

**Bewijs:** De arts beoordeelt of onderzoek nodig is.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-001 | Wijziging bij een sollicitatie

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Medewerker: Het gesprek is nu donderdag. Kunt u dan komen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, donderdag kan ik. Dank u voor het bericht. (goed). Goed. Je hoort: “Kunt u dan komen?” Met “Ja, donderdag kan ik. Dank u voor het bericht” geef je een passend antwoord.
- **B** Ik kom dinsdag zoals eerder afgesproken. (fout). Niet goed. Je hoort: “Kunt u dan komen?” “Ik kom dinsdag zoals eerder afgesproken” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, donderdag kan ik. Dank u voor het bericht”.
- **C** Ik kom donderdag, maar ik weet nog niet hoe laat. (fout). Niet goed. Je hoort: “Kunt u dan komen?” “Ik kom donderdag, maar ik weet nog niet hoe laat” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, donderdag kan ik. Dank u voor het bericht”.

**Bewijs:** Kunt u dan komen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-002 | Een storing melden

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Teamleider: Het systeem werkt niet. Noteer de aanvragen voorlopig op papier.
**Vraag:** Wat is een passende reactie?

- **A** Dan stuur ik alle aanvragen zonder registratie door. (fout). Niet goed. Je hoort: “Noteer de aanvragen voorlopig op papier.” “Dan stuur ik alle aanvragen zonder registratie door” past niet bij deze vraag of opdracht. Een passende reactie is: “Dat doe ik. Ik bewaar ze totdat het systeem werkt”.
- **B** Ik wacht met alle aanvragen tot morgen, zonder ze te noteren. (fout). Niet goed. Je hoort: “Noteer de aanvragen voorlopig op papier.” “Ik wacht met alle aanvragen tot morgen, zonder ze te noteren” past niet bij deze vraag of opdracht. Een passende reactie is: “Dat doe ik. Ik bewaar ze totdat het systeem werkt”.
- **C** Dat doe ik. Ik bewaar ze totdat het systeem werkt. (goed). Goed. Je hoort: “Noteer de aanvragen voorlopig op papier.” Met “Dat doe ik. Ik bewaar ze totdat het systeem werkt” geef je een passend antwoord.

**Bewijs:** Noteer de aanvragen voorlopig op papier.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-003 | De woninginspectie

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Verhuurder: We onderzoeken eerst de vochtplek en laten daarna meer weten.
**Vraag:** Wat is een passende reactie?

- **A** Dan laat ik de muur alvast schilderen. (fout). Niet goed. Je hoort: “We onderzoeken eerst de vochtplek en laten daarna meer weten.” “Dan laat ik de muur alvast schilderen” past niet bij deze vraag of opdracht. Een passende reactie is: “Prima. Ik zorg dat de medewerker binnen kan”.
- **B** Prima. Ik zorg dat de medewerker binnen kan. (goed). Goed. Je hoort: “We onderzoeken eerst de vochtplek en laten daarna meer weten.” Met “Prima. Ik zorg dat de medewerker binnen kan” geef je een passend antwoord.
- **C** Dan ga ik ervan uit dat het probleem nu opgelost is. (fout). Niet goed. Je hoort: “We onderzoeken eerst de vochtplek en laten daarna meer weten.” “Dan ga ik ervan uit dat het probleem nu opgelost is” past niet bij deze vraag of opdracht. Een passende reactie is: “Prima. Ik zorg dat de medewerker binnen kan”.

**Bewijs:** We onderzoeken eerst de vochtplek en laten daarna meer weten.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-004 | De verkeerde levering

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Leverancier: Kunt u foto’s van de verkeerde levering sturen?
**Vraag:** Wat is een passende reactie?

- **A** Ja, ik stuur ze mee met het ordernummer. (goed). Goed. Je hoort: “Kunt u foto’s van de verkeerde levering sturen?” Met “Ja, ik stuur ze mee met het ordernummer” geef je een passend antwoord.
- **B** Ik kan de foto’s pas sturen nadat u nieuwe dozen levert. (fout). Niet goed. Je hoort: “Kunt u foto’s van de verkeerde levering sturen?” “Ik kan de foto’s pas sturen nadat u nieuwe dozen levert” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik stuur ze mee met het ordernummer”.
- **C** Ik stuur alleen een foto van de juiste bestelling. (fout). Niet goed. Je hoort: “Kunt u foto’s van de verkeerde levering sturen?” “Ik stuur alleen een foto van de juiste bestelling” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, ik stuur ze mee met het ordernummer”.

**Bewijs:** Kunt u foto’s van de verkeerde levering sturen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-005 | De aangepaste busroute

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Reiziger: Ik moet naar het ziekenhuis. Waar stap ik nu uit?
**Vraag:** Wat is een passende reactie?

- **A** Stap uit bij de oude halte voor het ziekenhuis. (fout). Niet goed. Je hoort: “Waar stap ik nu uit?” “Stap uit bij de oude halte voor het ziekenhuis” past niet bij deze vraag of opdracht. Een passende reactie is: “Bij het plein. Vanaf daar is het vijf minuten lopen”.
- **B** U moet uitstappen bij het station, niet bij het plein. (fout). Niet goed. Je hoort: “Waar stap ik nu uit?” “U moet uitstappen bij het station, niet bij het plein” past niet bij deze vraag of opdracht. Een passende reactie is: “Bij het plein. Vanaf daar is het vijf minuten lopen”.
- **C** Bij het plein. Vanaf daar is het vijf minuten lopen. (goed). Goed. Je hoort: “Waar stap ik nu uit?” Met “Bij het plein. Vanaf daar is het vijf minuten lopen” geef je een passend antwoord.

**Bewijs:** Waar stap ik nu uit?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-006 | Een taak verdelen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Teamleider: De levering komt later. Willen jullie eerst de voorraad controleren?
**Vraag:** Wat is een passende reactie?

- **A** Nee, we wachten eerst tot de levering binnen is. (fout). Niet goed. Je hoort: “Willen jullie eerst de voorraad controleren?” “Nee, we wachten eerst tot de levering binnen is” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dan gebruiken we de wachttijd goed”.
- **B** Ja, dan gebruiken we de wachttijd goed. (goed). Goed. Je hoort: “Willen jullie eerst de voorraad controleren?” Met “Ja, dan gebruiken we de wachttijd goed” geef je een passend antwoord.
- **C** We beginnen meteen met uitladen, ook zonder vrachtwagen. (fout). Niet goed. Je hoort: “Willen jullie eerst de voorraad controleren?” “We beginnen meteen met uitladen, ook zonder vrachtwagen” past niet bij deze vraag of opdracht. Een passende reactie is: “Ja, dan gebruiken we de wachttijd goed”.

**Bewijs:** Willen jullie eerst de voorraad controleren?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-007 | De cursusvoorwaarden

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Elena: Ik ben te laat met afmelden. Kunt u uitleggen wat de mogelijkheden zijn?
**Vraag:** Wat is een passende reactie?

- **A** Natuurlijk. Ik kijk welke regeling van toepassing is. (goed). Goed. Je hoort: “Kunt u uitleggen wat de mogelijkheden zijn?” Met “Natuurlijk. Ik kijk welke regeling van toepassing is” geef je een passend antwoord.
- **B** U krijgt het lesgeld altijd volledig terug. (fout). Niet goed. Je hoort: “Kunt u uitleggen wat de mogelijkheden zijn?” “U krijgt het lesgeld altijd volledig terug” past niet bij deze vraag of opdracht. Een passende reactie is: “Natuurlijk. Ik kijk welke regeling van toepassing is”.
- **C** U kunt zich alleen nog telefonisch aanmelden voor de cursus. (fout). Niet goed. Je hoort: “Kunt u uitleggen wat de mogelijkheden zijn?” “U kunt zich alleen nog telefonisch aanmelden voor de cursus” past niet bij deze vraag of opdracht. Een passende reactie is: “Natuurlijk. Ik kijk welke regeling van toepassing is”.

**Bewijs:** Kunt u uitleggen wat de mogelijkheden zijn?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-008 | Een afspraak bij de gemeente

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Medewerker: U kunt uw document ophalen nadat u een afspraak heeft gemaakt.
**Vraag:** Wat is een passende reactie?

- **A** Ga zonder afspraak naar het loket. (fout). Niet goed. Je hoort: “U kunt uw document ophalen nadat u een afspraak heeft gemaakt.” “Ga zonder afspraak naar het loket” past niet bij deze vraag of opdracht. Een passende reactie is: “Dan reserveer ik eerst online een tijd”.
- **B** Vraag morgen eerst telefonisch een nieuw document aan. (fout). Niet goed. Je hoort: “U kunt uw document ophalen nadat u een afspraak heeft gemaakt.” “Vraag morgen eerst telefonisch een nieuw document aan” past niet bij deze vraag of opdracht. Een passende reactie is: “Dan reserveer ik eerst online een tijd”.
- **C** Dan reserveer ik eerst online een tijd. (goed). Goed. Je hoort: “U kunt uw document ophalen nadat u een afspraak heeft gemaakt.” Met “Dan reserveer ik eerst online een tijd” geef je een passend antwoord.

**Bewijs:** U kunt uw document ophalen nadat u een afspraak heeft gemaakt.
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-009 | Samenwerken na een fout

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Teamleider: Hoe kunnen we deze fout de volgende keer voorkomen?
**Vraag:** Wat is een passende reactie?

- **A** We stoppen tijdelijk met alle bestellingen. (fout). Niet goed. Je hoort: “Hoe kunnen we deze fout de volgende keer voorkomen?” “We stoppen tijdelijk met alle bestellingen” past niet bij deze vraag of opdracht. Een passende reactie is: “We controleren voortaan het ordernummer en het product”.
- **B** We controleren voortaan het ordernummer en het product. (goed). Goed. Je hoort: “Hoe kunnen we deze fout de volgende keer voorkomen?” Met “We controleren voortaan het ordernummer en het product” geef je een passend antwoord.
- **C** We controleren voortaan alleen de verpakking. (fout). Niet goed. Je hoort: “Hoe kunnen we deze fout de volgende keer voorkomen?” “We controleren voortaan alleen de verpakking” past niet bij deze vraag of opdracht. Een passende reactie is: “We controleren voortaan het ordernummer en het product”.

**Bewijs:** Hoe kunnen we deze fout de volgende keer voorkomen?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.

## KLINK-LUI-P01-B1-suitable-reply-010 | Een medische afspraak aanpassen

**Oefenvorm:** Welke reactie past?
**Gesproken bron:** Fatima: Kan mijn controle telefonisch plaatsvinden?
**Vraag:** Wat is een passende reactie?

- **A** Ik overleg het met de arts. U hoort daarna wat mogelijk is. (goed). Goed. Je hoort: “Kan mijn controle telefonisch plaatsvinden?” Met “Ik overleg het met de arts. U hoort daarna wat mogelijk is” geef je een passend antwoord.
- **B** Ja, u kunt de controle zelf telefonisch omzetten. (fout). Niet goed. Je hoort: “Kan mijn controle telefonisch plaatsvinden?” “Ja, u kunt de controle zelf telefonisch omzetten” past niet bij deze vraag of opdracht. Een passende reactie is: “Ik overleg het met de arts. U hoort daarna wat mogelijk is”.
- **C** Nee, elke controle moet altijd in het ziekenhuis plaatsvinden. (fout). Niet goed. Je hoort: “Kan mijn controle telefonisch plaatsvinden?” “Nee, elke controle moet altijd in het ziekenhuis plaatsvinden” past niet bij deze vraag of opdracht. Een passende reactie is: “Ik overleg het met de arts. U hoort daarna wat mogelijk is”.

**Bewijs:** Kan mijn controle telefonisch plaatsvinden?
**Status:** AI_REVIEWED_CANDIDATE_AUDIO_HOLD. Onafhankelijke ERK-, menselijke audio- en livecontrole niet uitgevoerd.
