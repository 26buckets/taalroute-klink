# START HIER. KLINK Luisteren v0.4. 200 gereviewde kandidaten en groei naar 100 per onderdeel

Werkmap: 2 november 2026. Aanvullend op oorspronkelijke Drive-projectmap, zonder de eerdere v0.3 te overschrijven.

**Eerst lezen:** `01_INTEGRAAL_REVIEWVERSLAG.md`, `02_OPEN_PUNTEN_EN_PUBLICATIEPOORTEN.md`, `00_MASTERREGELS_PROMPTS_EN_QA.md` en `OPSCHALING_20_OPEN_CELLEN.csv`.

**Cijfers:** 20 open combinaties; 10 kandidaten per combinatie; 200 in totaal, 180 oorspronkelijk nieuw en 20 bestaande A1/A2-dialogen hergebruikt. Groeidoel 100/cel = 2.000; op basis van deze startbank nog 1.800 kandidaten in 180 batches van tien (9 batches per cel). Daarnaast 10 gevulde combinaties met niet-geverifieerde actuele aantallen: apart auditen.

**Reviewstatus:** de 200 items hebben een nieuwe AI-taal- en didactiekronde, 1257 inhoudelijke veldupdates met bronhistorie. Daarmee is geen onafhankelijke kwaliteitskeur en geen audio- of ERK-acceptatie uitgevoerd. Alle publicatieblokkades zijn expliciet beschreven.

**Nieuwe chats:** open één zelfstandige prompt in `PROMPTS_PER_BATCH_180/` (180 bestanden). Je kunt ook het combinatiedossier openen: `PROMPTS_PER_OPEN_COMBINATIE/PROMPT_<niveau>_<oefenvorm>_011_100.md` en plak de opdracht in een nieuwe chat, met `00_MASTERREGELS_PROMPTS_EN_QA.md` als vast contract. Vraag per chat slechts de volgende tien taken, sla volledige reviewde brondata op Google Drive, en voer pas daarna een nieuwe batch uit.

**Eerst volledige audio-/beeld- en runtimeacceptatie voor pilot:** Klink hoeft nu niet live; de code/repo is niet gewijzigd en er is niet gedeployed.
